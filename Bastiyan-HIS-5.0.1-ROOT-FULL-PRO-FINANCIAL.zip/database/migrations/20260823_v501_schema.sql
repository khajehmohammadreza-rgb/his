-- Bastiyan HIS Migration v5.0.1 (Build 501)
-- Execution Date: 2026-08-23
CREATE TABLE IF NOT EXISTS system_migrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    migration_id VARCHAR(100) NOT NULL UNIQUE,
    version VARCHAR(20) NOT NULL,
    executed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    checksum VARCHAR(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO system_migrations (migration_id, version, checksum)
VALUES ('20260823_v501_core_init', '5.0.1', 'INIT_CORE_MIGRATION');
