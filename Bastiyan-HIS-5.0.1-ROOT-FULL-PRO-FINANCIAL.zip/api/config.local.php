<?php
// تولیدشده توسط Bastiyan HIS Setup — 2026-09-10 13:19:06
define('BASTIAN_DB_HOST',                 'localhost');
define('BASTIAN_DB_PORT',                 3306);
define('BASTIAN_DB_NAME',                 'bastiyan_his');
define('BASTIAN_DB_USER',                 'bastiyan_his');
define('BASTIAN_DB_PASS',                 'Mamal@332211');
define('KAVENEGAR_API_KEY',               '');
define('GEMINI_API_KEY',                  '');
define('IDENTITY_PROVIDER_URL',           '');
define('IDENTITY_PROVIDER_API_KEY',       '');
define('BASTIAN_SUPERADMIN_USERNAME',     'admin');
define('BASTIAN_SUPERADMIN_PASSWORD_HASH','$2y$10$yHO5Rm123Fvfn94lTOG3lO9hCPZkyU92TLtnCDcSFyYoQeFJwf/9C');
define('BASTIAN_BACKUP_KEY',              '476a5295aa46debabf2d4f1a535f7c7792535aaea37f941da8ebcec5c8b7a227');
define('BASTIAN_DATA_ENCRYPTION_KEY',     'SKwZnBCYBiW/bQ1lkOtV1WroadQJSDeONu2ZtRn2jWI=');
