<?php
/** Automatic database disaster-recovery backup.
 * DirectAdmin Cron example: php /full/path/public_html/api/cron_backup.php
 */
require_once __DIR__.'/config.php';
require_once __DIR__.'/recovery_lib.php';
$cli = PHP_SAPI === 'cli';
$keyHeader = $_SERVER['HTTP_X_BACKUP_KEY'] ?? ($_GET['key'] ?? '');
if (!$cli && (!defined('BASTIAN_BACKUP_KEY') || !BASTIAN_BACKUP_KEY || !hash_equals((string)BASTIAN_BACKUP_KEY,(string)$keyHeader))) { http_response_code(403); exit('Forbidden'); }
if (!bastianDbEnabled()) { http_response_code(503); exit('Database not configured'); }
try {
    $snap = bastianRecoveryCreateSnapshot('scheduled', ['runtime'=>false,'database'=>true]);
    $dbPath = bastianRecoverySnapshotsDir().$snap['id'].'/database.bastiyanbak';
    if (is_file($dbPath) && defined('FULL_BACKUPS_DIR')) {
        $compat = FULL_BACKUPS_DIR.'bastiyan_full_'.date('Ymd_His').'.bastianbak';
        @copy($dbPath,$compat); @chmod($compat,0640);
        $files=glob(FULL_BACKUPS_DIR.'bastiyan_full_*.bastianbak')?:[]; rsort($files);
        $ret=defined('BASTIAN_FULL_BACKUP_RETENTION')?(int)BASTIAN_FULL_BACKUP_RETENTION:30;
        foreach(array_slice($files,max(1,$ret)) as $old)@unlink($old);
    }
    if (function_exists('bastianAudit')) bastianAudit('backup.full',null,'system','cron','backup',(string)$snap['id'],['bytes'=>$snap['database']['bytes']??0,'tables'=>$snap['database']['tables']??0]);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success'=>true,'snapshotId'=>$snap['id'],'createdAt'=>$snap['createdAt'],'tables'=>$snap['database']['tables']??0,'bytes'=>$snap['database']['bytes']??0],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
} catch(Throwable $e) {
    http_response_code(500); echo json_encode(['success'=>false,'error'=>$e->getMessage()],JSON_UNESCAPED_UNICODE);
}
