<?php
/**
 * Bastiyan HIS Professional — Setup & Maintenance Wizard
 * -------------------------------------------------------
 * - راه‌اندازی اولیه (نوشتن config.local.php + ساخت جداول)
 * - فرمت دیتابیس  (حذف کامل تمام جداول bastian_ و شروع از صفر)
 * - بازنشانی تنظیمات (حذف config.local.php برای ورود مجدد اطلاعات)
 * - تست اتصال پیش از نوشتن هر فایل
 *
 * Bugs fixed vs previous version:
 * [B1] گزینه فرمت/پاک‌کردن دیتابیس وجود نداشت
 * [B2] وقتی config موجود بود ولی DB قطع بود، راهی برای تغییر credentials نبود
 * [B3] define(BASTIAN_DATA_ENCRYPTION_KEY) قبل از require db.php صدا می‌شد → تداخل
 * [B4] bastianCreateSchema بدون db.php در مسیر config-exists صدا می‌شد
 * [B5] اتصال پیش از نوشتن config تست نمی‌شد
 * [B6] بررسی افزونه‌های PHP قبل از نمایش فرم انجام نمی‌شد
 * [B7] فرمت DB باید همه جداول bastian_ را DROP + recreate کند
 * [B8] reset فقط با GET پارامتر → CSRF risk
 * [B9] خطای "config موجود اما DB قطع" بدون دکمه تغییر credential نمایش داده می‌شد
 */

date_default_timezone_set('Asia/Tehran');
$configFile = __DIR__ . '/config.local.php';
$configExists = file_exists($configFile);
$maintenanceUnlock = trim((string)(getenv('BASTIAN_SETUP_UNLOCK') ?: ''));

if ($configExists && $maintenanceUnlock === '' && $_SERVER['REQUEST_METHOD'] === 'POST'
  && in_array((string)($_POST['_action'] ?? ''), ['reset_request', 'reset_confirm', 'format_request', 'format_execute'], true)) {
  http_response_code(403);
  exit('Setup maintenance is disabled after installation.');
}

// ── توابع کمکی ───────────────────────────────────────────────────────────────
function h(mixed $v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function setupNow(): string { return date('Y-m-d H:i:s'); }

/** اتصال PDO مستقل از config.php — فقط برای setup استفاده می‌شود */
function setupPdo(string $host, int $port, string $db, string $user, string $pass): PDO {
    $dsn = "mysql:host={$host};port={$port};dbname={$db};charset=utf8mb4";
    return new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
    ]);
}

/** [B7] حذف کامل همه جداول bastian_ — فرمت/پاک‌کردن دیتابیس */
function dropAllBastianTables(PDO $pdo): array {
    $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
    $st = $pdo->query("SHOW TABLES LIKE 'bastian\\_%'");
    $tables = $st->fetchAll(PDO::FETCH_COLUMN);
    $dropped = [];
    foreach ($tables as $table) {
        // اعتبارسنجی نام جدول — فقط حروف، اعداد، خط‌تیره
        if (!preg_match('/^[a-zA-Z0-9_]+$/', (string)$table)) continue;
        $pdo->exec("DROP TABLE IF EXISTS `{$table}`");
        $dropped[] = $table;
    }
    $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
    return $dropped;
}

/** بررسی افزونه‌های ضروری PHP [B6] */
function checkPhpRequirements(): array {
    $errors = [];
    if (!extension_loaded('pdo'))       $errors[] = 'افزونه PDO فعال نیست.';
    if (!extension_loaded('pdo_mysql')) $errors[] = 'افزونه PDO_MySQL فعال نیست.';
    if (!extension_loaded('openssl'))   $errors[] = 'افزونه OpenSSL فعال نیست (برای رمزگذاری داده لازم است).';
    if (!extension_loaded('json'))      $errors[] = 'افزونه JSON فعال نیست.';
    if (version_compare(PHP_VERSION, '8.0.0', '<'))
        $errors[] = 'نسخه PHP باید ۸.۰ یا بالاتر باشد (نسخه فعلی: ' . PHP_VERSION . ').';
    return $errors;
}

/** مهاجرت داده‌های قدیمی (JSON-based) به MySQL */
function migrateLegacyData(PDO $pdo): array {
    $result = ['centers' => 0, 'users' => 0, 'states' => 0];
    $storePath = __DIR__ . '/data/bastian_cloud_store.json';
    if (!file_exists($storePath)) return $result;
    $store = json_decode((string)@file_get_contents($storePath), true);
    if (!is_array($store)) return $result;
    $now = setupNow();
    foreach (($store['centers'] ?? []) as $c) {
        $id = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)($c['id'] ?? ''));
        if ($id === '') continue;
        try {
            $st = $pdo->prepare(
                "INSERT IGNORE INTO bastian_centers
                 (id,code,name,city,phone,address,center_type,plan_name,
                  start_date,end_date,active,archived,notes,version,
                  last_sync,created_at,updated_at,archived_at)
                 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            );
            $st->execute([
                $id,
                $c['code'] ?? ('CNT-' . substr(md5($id), 0, 8)),
                $c['name'] ?? 'مرکز درمانی',
                $c['city'] ?? '', $c['phone'] ?? '', $c['address'] ?? '',
                $c['centerType'] ?? 'clinic', $c['planName'] ?? 'standard',
                $c['startDate'] ?? '', $c['endDate'] ?? '',
                !empty($c['active']) ? 1 : 0, !empty($c['archived']) ? 1 : 0,
                $c['notes'] ?? '', '4.5.4',
                !empty($c['lastSync'])   ? date('Y-m-d H:i:s', strtotime($c['lastSync']))   : null,
                !empty($c['createdAt']) ? date('Y-m-d H:i:s', strtotime($c['createdAt'])) : $now,
                !empty($c['updatedAt']) ? date('Y-m-d H:i:s', strtotime($c['updatedAt'])) : $now,
                !empty($c['archivedAt'])? date('Y-m-d H:i:s', strtotime($c['archivedAt'])): null,
            ]);
            $result['centers'] += $st->rowCount() > 0 ? 1 : 0;
        } catch (Throwable) {}

        $adminUsername = trim((string)($c['adminUsername'] ?? ''));
        if ($adminUsername !== '') {
            $hash = (string)($c['adminPasswordHash'] ?? '');
            if ($hash === '' && !empty($c['adminPassword']))
                $hash = password_hash((string)$c['adminPassword'], PASSWORD_DEFAULT);
            if ($hash === '')
                $hash = password_hash(bin2hex(random_bytes(16)), PASSWORD_DEFAULT);
            try {
                $u = $pdo->prepare(
                    "INSERT IGNORE INTO bastian_users
                     (id,center_id,name,username,password_hash,role,department,active,is_primary_admin,created_at,updated_at)
                     VALUES(?,?,?,?,?,'admin','مدیریت مرکز',1,1,?,?)"
                );
                $u->execute(['center-admin-' . $id, $id, 'مدیر مرکز ' . ($c['name'] ?? ''), $adminUsername, $hash, $now, $now]);
                $result['users'] += $u->rowCount() > 0 ? 1 : 0;
            } catch (Throwable) {}
        }
    }
    return $result;
}

/** نوشتن config.local.php با اطلاعات دریافتی */
function writeConfigFile(
    string $configFile, string $host, int $port, string $db,
    string $dbUser, string $dbPass, string $username, string $passHash,
    string $backupKey, string $dataKey, string $kavenegarKey,
    string $geminiKey, string $identityUrl, string $identityKey
): void {
    $content  = "<?php\n";
    $content .= "// تولیدشده توسط Bastiyan HIS Setup — " . date('Y-m-d H:i:s') . "\n";
    $content .= "define('BASTIAN_DB_HOST',                 " . var_export($host,         true) . ");\n";
    $content .= "define('BASTIAN_DB_PORT',                 " . var_export($port,         true) . ");\n";
    $content .= "define('BASTIAN_DB_NAME',                 " . var_export($db,           true) . ");\n";
    $content .= "define('BASTIAN_DB_USER',                 " . var_export($dbUser,       true) . ");\n";
    $content .= "define('BASTIAN_DB_PASS',                 " . var_export($dbPass,       true) . ");\n";
    $content .= "define('KAVENEGAR_API_KEY',               " . var_export($kavenegarKey, true) . ");\n";
    $content .= "define('GEMINI_API_KEY',                  " . var_export($geminiKey,    true) . ");\n";
    $content .= "define('IDENTITY_PROVIDER_URL',           " . var_export($identityUrl,  true) . ");\n";
    $content .= "define('IDENTITY_PROVIDER_API_KEY',       " . var_export($identityKey,  true) . ");\n";
    $content .= "define('BASTIAN_SUPERADMIN_USERNAME',     " . var_export($username,     true) . ");\n";
    $content .= "define('BASTIAN_SUPERADMIN_PASSWORD_HASH'," . var_export($passHash,     true) . ");\n";
    $content .= "define('BASTIAN_BACKUP_KEY',              " . var_export($backupKey,    true) . ");\n";
    $content .= "define('BASTIAN_DATA_ENCRYPTION_KEY',     " . var_export($dataKey,      true) . ");\n";
    if (@file_put_contents($configFile, $content, LOCK_EX) === false)
        throw new RuntimeException('امکان نوشتن فایل api/config.local.php وجود ندارد. مجوز دسترسی پوشه api را بررسی کنید.');
    @chmod($configFile, 0640);
}

// ── بارگذاری vendor_prepare_lib.php ──────────────────────────────────────────
require_once __DIR__ . '/vendor_prepare_lib.php';

// ── وضعیت‌های کلی ────────────────────────────────────────────────────────────
$phpErrors   = checkPhpRequirements();  // [B6]
$page        = 'setup';   // setup | success | format_confirm | format_done | reset_confirm
$error       = '';
$warning     = '';
$details     = [];

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ACTION: بازنشانی config (فقط حذف config.local.php)  [B8] — نیاز به POST
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['_action'] ?? '') === 'reset_confirm') {
    if ($configExists) @unlink($configFile);
    header('Location: setup.php');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['_action'] ?? '') === 'reset_request') {
    $page = 'reset_confirm';
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ACTION: فرمت دیتابیس — مرحله ۱: درخواست تأیید
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['_action'] ?? '') === 'format_request') {
    $page = 'format_confirm';
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ACTION: فرمت دیتابیس — مرحله ۲: اجرا  [B1][B7]
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['_action'] ?? '') === 'format_execute') {
    $confirmWord = trim((string)($_POST['confirm_word'] ?? ''));
    if ($confirmWord !== 'FORMAT') {
        $error = 'برای تأیید فرمت دیتابیس، باید دقیقاً عبارت FORMAT را تایپ کنید.';
        $page  = 'format_confirm';
    } elseif (!$configExists) {
        $error = 'فایل تنظیمات (config.local.php) وجود ندارد. ابتدا راه‌اندازی اولیه را انجام دهید.';
        $page  = 'setup';
    } else {
        try {
            // [B4] بارگذاری db.php قبل از استفاده از توابع آن
            require_once __DIR__ . '/config.php';
            require_once __DIR__ . '/db.php';
            $pdo = bastianPdo();
            $dropped = dropAllBastianTables($pdo);
            bastianCreateSchema($pdo);
            // حذف config.local.php تا setup مجدداً اعتبارسنجی شود
            @unlink($configFile);
            $details = ['dropped' => $dropped, 'droppedCount' => count($dropped)];
            $page    = 'format_done';
        } catch (Throwable $e) {
            $error = 'فرمت دیتابیس انجام نشد: ' . $e->getMessage();
            $page  = 'format_confirm';
        }
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// بارگذاری config موجود و بررسی اتصال  [B2][B4][B9]
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
$configConnected = false;
if ($configExists && !in_array($page, ['reset_confirm', 'format_confirm', 'format_done'], true)) {
    // [B3] ارتقای config قدیمی بدون ENCRYPTION_KEY — قبل از require
    $existingConfig = (string)@file_get_contents($configFile);
    if (strpos($existingConfig, 'BASTIAN_DATA_ENCRYPTION_KEY') === false) {
        $upgradeLine = "\ndefine('BASTIAN_DATA_ENCRYPTION_KEY', " . var_export(base64_encode(random_bytes(32)), true) . ");\n";
        @file_put_contents($configFile, $upgradeLine, FILE_APPEND | LOCK_EX);
    }
    // [B4] config.php خودش db.php را require می‌کند
    try {
        require_once __DIR__ . '/config.php';
        $pdo = bastianPdo();
        $pdo->query('SELECT 1');
        bastianCreateSchema($pdo);
        $configConnected = true;
        $details['db']        = 'متصل';
        $details['php']       = PHP_VERSION;
        $details['pdo_mysql'] = extension_loaded('pdo_mysql') ? 'فعال' : 'غیرفعال';
        if (!bastianVendorReady()) {
            try   { $details['vendor'] = bastianPrepareVendor(false); }
            catch (Throwable $ve) { $warning = 'Runtime مرورگر دریافت نشد: ' . $ve->getMessage(); }
        } else {
            $details['vendor'] = 'آماده و محلی';
        }
        $page = 'success';
    } catch (Throwable $e) {
        // [B9] نمایش خطا با گزینه بازنشانی
        $error = 'اتصال دیتابیس برقرار نیست: ' . $e->getMessage();
        $page  = 'setup'; // فرم را نشان می‌دهد با خطا
        $configExists = false; // اجازه ورود مجدد اطلاعات
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ACTION: ارسال فرم راه‌اندازی اولیه  [B3][B5]
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
if ($_SERVER['REQUEST_METHOD'] === 'POST'
    && ($_POST['_action'] ?? '') === 'install'
    && $page === 'setup'
) {
    $host       = trim((string)($_POST['db_host'] ?? 'localhost'));
    $port       = max(1, min(65535, (int)($_POST['db_port'] ?? 3306)));
    $db         = trim((string)($_POST['db_name'] ?? ''));
    $dbUser     = trim((string)($_POST['db_user'] ?? ''));
    $dbPass     = (string)($_POST['db_pass'] ?? '');
    $username   = trim((string)($_POST['username'] ?? 'admin'));
    $password   = (string)($_POST['password'] ?? '');
    $confirm    = (string)($_POST['confirm'] ?? '');
    $kavenegarKey = trim((string)($_POST['kavenegar_key'] ?? ''));
    $geminiKey    = trim((string)($_POST['gemini_key']    ?? ''));
    $identityUrl  = trim((string)($_POST['identity_url']  ?? ''));
    $identityKey  = trim((string)($_POST['identity_key']  ?? ''));

    $doFormatFirst = !empty($_POST['format_before_install']); // گزینه پاک‌کردن قبل از نصب

    // اعتبارسنجی ورودی‌ها
    if ($phpErrors) {
        $error = 'پیش‌نیازهای PHP برآورده نشده‌اند: ' . implode(' | ', $phpErrors);
    } elseif ($db === '' || $dbUser === '') {
        $error = 'نام دیتابیس و کاربر دیتابیس الزامی است.';
    } elseif ($username === '') {
        $error = 'نام کاربری مدیریت کل الزامی است.';
    } elseif (!preg_match('/^[a-zA-Z0-9_@.-]{3,50}$/', $username)) {
        $error = 'نام کاربری فقط می‌تواند شامل حروف انگلیسی، اعداد و _ @ . - باشد.';
    } elseif (strlen($password) < 10) {
        $error = 'رمز مدیریت کل باید حداقل ۱۰ کاراکتر باشد.';
    } elseif ($password !== $confirm) {
        $error = 'رمز و تکرار رمز یکسان نیستند.';
    } elseif ($identityUrl !== '' && !str_starts_with(strtolower($identityUrl), 'https://')) {
        $error = 'آدرس Identity Provider باید با https:// شروع شود.';
    } else {
        try {
            // تست اتصال قبل از نوشتن هر فایل
            $pdo = setupPdo($host, $port, $db, $dbUser, $dbPass);
            $pdo->query('SELECT 1');

            // بارگذاری db.php پس از موفقیت اتصال
            require_once __DIR__ . '/db.php';

            // ── پاک‌کردن دیتابیس قبل از نصب (اگر کاربر تیک زده) ──────────
            $droppedBeforeInstall = [];
            if ($doFormatFirst) {
                $droppedBeforeInstall = dropAllBastianTables($pdo);
                $details['format_before_install'] = count($droppedBeforeInstall) . ' جدول قبل از نصب حذف شد';
            }

            bastianCreateSchema($pdo);

            // تولید کلیدهای امنیتی
            $dataKey   = base64_encode(random_bytes(32));
            $backupKey = bin2hex(random_bytes(32));
            $passHash  = password_hash($password, PASSWORD_DEFAULT);

            if (!defined('BASTIAN_DATA_ENCRYPTION_KEY'))
                define('BASTIAN_DATA_ENCRYPTION_KEY', $dataKey);

            // مهاجرت داده قدیمی — فقط اگر فرمت نشده
            $migration = $doFormatFirst ? ['centers'=>0,'users'=>0,'states'=>0] : migrateLegacyData($pdo);

            // نوشتن config.local.php
            writeConfigFile(
                $configFile, $host, $port, $db, $dbUser, $dbPass,
                $username, $passHash, $backupKey, $dataKey,
                $kavenegarKey, $geminiKey, $identityUrl, $identityKey
            );

            $details = array_merge($details, [
                'db'        => 'متصل — جداول ساخته شدند',
                'migration' => $migration,
                'php'       => PHP_VERSION,
                'dropped'   => $droppedBeforeInstall,
            ]);
            try   { $details['vendor'] = bastianPrepareVendor(false); }
            catch (Throwable $ve) {
                $warning = 'دیتابیس آماده است. Runtime مرورگر دریافت نشد: ' . $ve->getMessage();
            }
            $page = 'success';

        } catch (Throwable $e) {
            $error = 'راه‌اندازی انجام نشد: ' . $e->getMessage();
        }
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// HTML OUTPUT
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
?><!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>راه‌اندازی Bastiyan HIS Professional</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'B Nazanin',Tahoma,Arial,sans-serif;background:#020617;color:#e2e8f0;min-height:100vh;padding:28px 12px}
.wrap{width:min(780px,98vw);margin:auto}
.card{background:#0f172a;border:1px solid #1e293b;border-radius:24px;padding:28px 24px;box-shadow:0 24px 64px #0009;margin-bottom:20px}
.head{display:flex;gap:14px;align-items:center;margin-bottom:24px}
.logo img{width:52px;height:52px;border-radius:14px;object-fit:cover;display:block}
.head h1{font-size:20px;font-weight:700;color:#f1f5f9}
.head p{font-size:13px;color:#64748b;margin-top:3px}
/* alerts */
.alert{border-radius:12px;padding:14px 16px;margin-bottom:16px;font-size:13px;line-height:1.7}
.alert-err {background:#4c0519;border:1px solid #be123c;color:#fca5a5}
.alert-warn{background:#1c1004;border:1px solid #92400e;color:#fde68a}
.alert-ok  {background:#052e2b;border:1px solid #0f766e;color:#6ee7b7}
.alert-info{background:#0c1a2e;border:1px solid #1d4ed8;color:#93c5fd}
/* sections */
.sec{border-top:1px solid #1e293b;margin-top:22px;padding-top:18px}
.sec h2{font-size:15px;font-weight:600;color:#94a3b8;margin-bottom:14px}
/* grid */
.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
@media(max-width:600px){.grid{grid-template-columns:1fr}}
.col2{grid-column:1/-1}
/* form */
label{display:block;font-size:12px;color:#94a3b8;margin-bottom:5px;font-weight:500}
input[type=text],input[type=password],input[type=number],input[type=url]{
  width:100%;padding:11px 14px;border-radius:10px;border:1px solid #334155;
  background:#020617;color:#e2e8f0;font-size:14px;transition:border .15s}
input:focus{outline:none;border-color:#0d9488}
input[readonly]{opacity:.6;cursor:not-allowed}
/* buttons */
.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;
  padding:12px 20px;border-radius:11px;font-size:14px;font-weight:700;
  border:0;cursor:pointer;text-decoration:none;transition:opacity .15s}
.btn:hover{opacity:.88}
.btn-primary {background:#0d9488;color:#fff;width:100%;margin-top:18px}
.btn-danger  {background:#dc2626;color:#fff}
.btn-ghost   {background:#1e293b;color:#94a3b8;border:1px solid #334155}
.btn-sm{padding:8px 16px;font-size:13px;font-weight:600}
/* tip box */
.tip{background:#0c0f1a;border:1px solid #1e293b;border-radius:12px;padding:12px 14px;font-size:12px;line-height:1.9;color:#64748b}
.tip b{color:#94a3b8}
/* req list */
.req-ok {color:#34d399} .req-err{color:#f87171}
/* checkbox area */
.check-row{display:flex;align-items:flex-start;gap:10px;margin-top:14px;padding:12px;background:#0c1525;border:1px solid #1e3a5f;border-radius:10px;font-size:13px;color:#93c5fd}
input[type=checkbox]{width:18px;height:18px;margin-top:2px;accent-color:#0d9488;flex-shrink:0}
/* danger zone */
.danger-zone{border:1px solid #7f1d1d;border-radius:14px;padding:16px;margin-top:22px;background:#1a0808}
.danger-zone h3{color:#f87171;font-size:14px;font-weight:700;margin-bottom:8px}
/* confirm word input */
.confirm-word{font-family:monospace;font-size:16px;letter-spacing:2px;text-align:center;border-color:#dc2626!important}
/* tag */
.badge{display:inline-block;padding:2px 8px;border-radius:6px;font-size:11px;font-weight:600}
.badge-ok  {background:#065f46;color:#6ee7b7}
.badge-err {background:#7f1d1d;color:#fca5a5}
.badge-warn{background:#78350f;color:#fde68a}
/* progress check */
.check-item{display:flex;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid #1e293b;font-size:13px}
.check-item:last-child{border-bottom:0}
code{direction:ltr;display:inline-block;background:#020617;padding:1px 6px;border-radius:5px;font-size:12px;color:#7dd3fc}
</style>
</head>
<body>
<div class="wrap">

<!-- ── هدر ── -->
<div class="card">
  <div class="head">
    <div class="logo"><img src="../logo.png" alt="Bastiyan HIS" onerror="this.style.display='none'"></div>
    <div>
      <h1>Bastiyan HIS Professional</h1>
      <p>راه‌اندازی امن MySQL &nbsp;|&nbsp; نت‌افراز / DirectAdmin</p>
    </div>
  </div>

<?php // ══════════════════ صفحه SUCCESS ══════════════════
if ($page === 'success'): ?>

  <div class="alert alert-ok">
    <b>✅ سامانه فعال و آماده است.</b><br>
    دیتابیس متصل، جداول ساخته‌شده، تنظیمات امنیتی ذخیره شده‌اند.
  </div>

  <?php if ($warning): ?>
  <div class="alert alert-warn">⚠️ <?= h($warning) ?></div>
  <?php endif; ?>

  <div class="sec">
    <h2>وضعیت سیستم</h2>
    <div class="check-item"><span class="req-ok">✓</span> <span>PHP <?= h(PHP_VERSION) ?></span></div>
    <div class="check-item"><span class="req-ok">✓</span> <span>اتصال دیتابیس: <b><?= h($details['db'] ?? 'متصل') ?></b></span></div>
    <div class="check-item"><span class="req-ok">✓</span> <span>PDO MySQL: <?= h($details['pdo_mysql'] ?? 'فعال') ?></span></div>
    <div class="check-item">
      <?php $vd = $details['vendor'] ?? null; $vendorOk = is_array($vd) ? !empty($vd['success']) : ($vd === 'آماده و محلی'); ?>
      <span class="<?= $vendorOk ? 'req-ok' : 'req-err' ?>"><?= $vendorOk ? '✓' : '!' ?></span>
      <span>Vendor Runtime: <span class="badge <?= $vendorOk ? 'badge-ok' : 'badge-warn' ?>"><?= $vendorOk ? 'آماده' : 'در انتظار' ?></span></span>
    </div>
    <?php if (!empty($details['migration'])): $m = $details['migration']; ?>
    <div class="check-item"><span class="req-ok">✓</span>
      <span>مهاجرت داده قدیمی: <?= (int)($m['centers']??0) ?> مرکز، <?= (int)($m['users']??0) ?> کاربر</span>
    </div>
    <?php endif; ?>
    <?php if (!empty($details['format_before_install'])): ?>
    <div class="check-item"><span class="req-ok">✓</span>
      <span>پاک‌سازی قبل از نصب: <b><?= h($details['format_before_install']) ?></b></span>
    </div>
    <?php endif; ?>
  </div>

  <div class="sec">
    <a class="btn btn-primary" href="../">← ورود به سامانه</a>
  </div>

  <!-- دانجر زون -->
  <div class="danger-zone sec">
    <h3>⚙️ عملیات نگهداری</h3>
    <p style="font-size:12px;color:#94a3b8;margin-bottom:14px">این عملیات‌ها برگشت‌ناپذیر هستند. فقط در صورت نیاز استفاده کنید.</p>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <!-- بازنشانی config -->
      <form method="post" style="display:inline">
        <input type="hidden" name="_action" value="reset_request">
        <button type="submit" class="btn btn-ghost btn-sm">🔄 تغییر اطلاعات دیتابیس</button>
      </form>
      <!-- فرمت دیتابیس -->
      <form method="post" style="display:inline">
        <input type="hidden" name="_action" value="format_request">
        <button type="submit" class="btn btn-danger btn-sm">🗑️ فرمت دیتابیس (حذف کامل داده)</button>
      </form>
    </div>
  </div>


<?php // ══════════════════ صفحه FORMAT_CONFIRM ══════════════════
elseif ($page === 'format_confirm'): ?>

  <div class="alert alert-err">
    <b>⚠️ هشدار جدی — این عملیات برگشت‌ناپذیر است</b><br>
    تمام جداول <code>bastian_*</code> در دیتابیس حذف می‌شوند. همه مراکز، کاربران، بیماران، فاکتورها و تمام داده‌ها پاک می‌شوند.<br>
    <b>پیش از ادامه حتماً یک نسخه پشتیبان از دیتابیس تهیه کنید.</b>
  </div>

  <?php if ($error): ?>
  <div class="alert alert-err"><?= h($error) ?></div>
  <?php endif; ?>

  <form method="post" autocomplete="off">
    <input type="hidden" name="_action" value="format_execute">
    <div class="sec">
      <h2>تأیید فرمت دیتابیس</h2>
      <p style="font-size:13px;color:#94a3b8;margin-bottom:14px">برای تأیید، کلمه <code>FORMAT</code> را دقیقاً در کادر زیر تایپ کنید:</p>
      <input type="text" name="confirm_word" class="confirm-word" placeholder="FORMAT" autocomplete="off" required>
      <div class="check-row">
        <input type="checkbox" id="chk_format" required>
        <label for="chk_format" style="color:#fca5a5;cursor:pointer">
          می‌دانم که تمام داده‌های دیتابیس برای همیشه حذف می‌شوند و این عملیات قابل بازگشت نیست.
        </label>
      </div>
    </div>
    <div style="display:flex;gap:10px;margin-top:18px">
      <button type="submit" class="btn btn-danger" style="width:auto;padding:12px 24px">🗑️ فرمت و پاک‌کردن دیتابیس</button>
      <a href="setup.php" class="btn btn-ghost" style="width:auto;padding:12px 24px">← انصراف</a>
    </div>
  </form>


<?php // ══════════════════ صفحه FORMAT_DONE ══════════════════
elseif ($page === 'format_done'): ?>

  <div class="alert alert-ok">
    <b>✅ فرمت دیتابیس با موفقیت انجام شد.</b><br>
    <?= (int)($details['droppedCount'] ?? 0) ?> جدول حذف و ساختار جداول مجدداً ایجاد شد.<br>
    فایل تنظیمات نیز پاک شد — برای راه‌اندازی مجدد فرم زیر را تکمیل کنید.
  </div>

  <?php if (!empty($details['dropped'])): ?>
  <div class="tip" style="margin-bottom:14px">
    <b>جداول حذف‌شده:</b><br>
    <?= implode('، ', array_map(fn($t) => '<code>' . h($t) . '</code>', $details['dropped'])) ?>
  </div>
  <?php endif; ?>

  <div class="sec">
    <a class="btn btn-primary" href="setup.php">← رفتن به فرم راه‌اندازی اولیه</a>
  </div>


<?php // ══════════════════ صفحه RESET_CONFIRM ══════════════════
elseif ($page === 'reset_confirm'): ?>

  <div class="alert alert-warn">
    <b>⚠️ تغییر اطلاعات اتصال دیتابیس</b><br>
    فایل <code>config.local.php</code> حذف می‌شود و فرم راه‌اندازی دوباره نمایش داده می‌شود.<br>
    دیتابیس و داده‌ها دست‌نخورده می‌مانند.
  </div>

  <form method="post">
    <input type="hidden" name="_action" value="reset_confirm">
    <div style="display:flex;gap:10px;margin-top:16px">
      <button type="submit" class="btn btn-danger" style="width:auto;padding:12px 24px">بله، تنظیمات را بازنشانی کن</button>
      <a href="setup.php" class="btn btn-ghost" style="width:auto;padding:12px 24px">← انصراف</a>
    </div>
  </form>


<?php // ══════════════════ صفحه SETUP (فرم اصلی) ══════════════════
else: ?>

  <?php if ($phpErrors): ?>
  <div class="alert alert-err">
    <b>❌ پیش‌نیازهای PHP برآورده نشده‌اند:</b><br>
    <?php foreach ($phpErrors as $e): ?>
    <span class="req-err">✗ <?= h($e) ?></span><br>
    <?php endforeach; ?>
    با پشتیبانی هاست تماس بگیرید.
  </div>
  <?php endif; ?>

  <?php if ($error): ?>
  <div class="alert alert-err"><?= h($error) ?></div>
  <?php endif; ?>

  <?php if (!$phpErrors): ?>
  <div class="tip">
    <b>راهنما:</b> ابتدا در <b>DirectAdmin نت‌افراز</b> یک MySQL Database و User بسازید.<br>
    اطلاعات همان دیتابیس را اینجا وارد کنید — هیچ دستور SQL دستی لازم نیست.<br>
    ⚠️ <b>این فرم فقط یک بار اجرا می‌شود.</b> پس از تأیید موفق، فایل تنظیمات ذخیره و دفعه بعد مستقیماً وارد سامانه می‌شوید.
  </div>

  <!-- بررسی PHP -->
  <div class="sec">
    <h2>وضعیت محیط PHP</h2>
    <?php
    $checks = [
        'PDO'         => extension_loaded('pdo'),
        'PDO_MySQL'   => extension_loaded('pdo_mysql'),
        'OpenSSL'     => extension_loaded('openssl'),
        'JSON'        => extension_loaded('json'),
        'cURL'        => extension_loaded('curl'),
        'mbstring'    => extension_loaded('mbstring'),
        'PHP ≥ 8.0'   => version_compare(PHP_VERSION, '8.0.0', '>='),
    ];
    foreach ($checks as $name => $ok): ?>
    <div class="check-item">
      <span class="<?= $ok ? 'req-ok' : 'req-err' ?>"><?= $ok ? '✓' : '✗' ?></span>
      <span><?= h($name) ?>
        <?php if (!$ok): ?><span class="badge badge-err">غیرفعال</span><?php endif; ?>
      </span>
    </div>
    <?php endforeach; ?>
  </div>

  <form method="post" autocomplete="off">
    <input type="hidden" name="_action" value="install">

    <!-- بخش ۱: دیتابیس -->
    <div class="sec">
      <h2>۱) اطلاعات دیتابیس MySQL</h2>
      <div class="grid">
        <div>
          <label>DB Host</label>
          <input type="text" name="db_host" value="<?= h($_POST['db_host'] ?? 'localhost') ?>" required placeholder="localhost">
        </div>
        <div>
          <label>DB Port</label>
          <input type="number" name="db_port" value="<?= h($_POST['db_port'] ?? '3306') ?>" required min="1" max="65535" placeholder="3306">
        </div>
        <div>
          <label>نام دیتابیس <span style="color:#f87171">*</span></label>
          <input type="text" name="db_name" value="<?= h($_POST['db_name'] ?? '') ?>" required placeholder="u12345_his">
        </div>
        <div>
          <label>کاربر دیتابیس <span style="color:#f87171">*</span></label>
          <input type="text" name="db_user" value="<?= h($_POST['db_user'] ?? '') ?>" required placeholder="u12345_hisuser">
        </div>
        <div class="col2">
          <label>رمز دیتابیس</label>
          <input type="password" name="db_pass" placeholder="رمز دیتابیس">
        </div>
      </div>
    </div>

    <!-- بخش ۲: مدیریت کل -->
    <div class="sec">
      <h2>۲) حساب مدیریت کل سامانه</h2>
      <div class="alert alert-info" style="font-size:12px">
        این حساب سوپرادمین کل سامانه است (نه مدیر یک مرکز). رمز آن در سرور به صورت hashed ذخیره می‌شود.
      </div>
      <div class="grid">
        <div>
          <label>نام کاربری <span style="color:#f87171">*</span></label>
          <input type="text" name="username" value="<?= h($_POST['username'] ?? 'admin') ?>"
            required pattern="[a-zA-Z0-9_@.\-]{3,50}" placeholder="admin">
        </div>
        <div></div>
        <div>
          <label>رمز مدیریت کل <span style="color:#f87171">*</span> (حداقل ۱۰ کاراکتر)</label>
          <input type="password" name="password" minlength="10" required placeholder="••••••••••">
        </div>
        <div>
          <label>تکرار رمز <span style="color:#f87171">*</span></label>
          <input type="password" name="confirm" minlength="10" required placeholder="••••••••••">
        </div>
      </div>
    </div>

    <!-- بخش ۳: سرویس‌های اختیاری -->
    <div class="sec">
      <h2>۳) سرویس‌های اختیاری</h2>
      <div class="tip" style="margin-bottom:14px">
        <b>اختیاری:</b> کلیدها در فایل سرور ذخیره می‌شوند و هرگز به مرورگر ارسال نمی‌شوند.
        می‌توانید این بخش را خالی بگذارید و بعداً از پنل مدیریت کل تنظیم کنید.
      </div>
      <div class="grid">
        <div>
          <label>Kavenegar API Key (پیامک)</label>
          <input type="password" name="kavenegar_key" placeholder="کلید API کاوه‌نگار">
        </div>
        <div>
          <label>Gemini API Key (هوش مصنوعی)</label>
          <input type="password" name="gemini_key" placeholder="کلید Google Gemini">
        </div>
        <div>
          <label>Identity Provider URL (استعلام هویت)</label>
          <input type="url" name="identity_url" value="<?= h($_POST['identity_url'] ?? '') ?>"
            placeholder="https://provider.example/api/verify">
        </div>
        <div>
          <label>Identity Provider API Key</label>
          <input type="password" name="identity_key" placeholder="کلید API">
        </div>
      </div>
    </div>

    <!-- بخش ۴: پاک‌سازی دیتابیس قبل از نصب -->
    <div class="sec">
      <h2>۴) پاک‌سازی دیتابیس (مخصوص نصب مجدد)</h2>
      <div class="danger-zone" style="margin-top:0">
        <h3>🗑️ فرمت دیتابیس پیش از نصب</h3>
        <p style="font-size:12px;color:#fca5a5;margin-bottom:12px;line-height:1.8">
          اگر روی این دیتابیس قبلاً نرم‌افزار نصب بوده و می‌خواهید همه چیز را از صفر شروع کنید،
          این گزینه را فعال کنید.<br>
          <b>تمام جداول bastian_* و تمام داده‌ها برای همیشه حذف می‌شوند.</b>
        </p>
        <label style="display:flex;align-items:flex-start;gap:10px;cursor:pointer;padding:12px;background:#2d0a0a;border:1px solid #7f1d1d;border-radius:10px;color:#fca5a5">
          <input type="checkbox" name="format_before_install" value="1" id="chk_format_install"
            style="width:20px;height:20px;margin-top:1px;accent-color:#dc2626;flex-shrink:0">
          <span style="font-size:13px;line-height:1.7">
            <b>پاک‌کردن کامل دیتابیس قبل از نصب</b><br>
            <span style="font-size:11px;color:#f87171">تمام داده‌های قدیمی حذف می‌شوند. فقط برای نصب تازه از صفر استفاده کنید.</span>
          </span>
        </label>
      </div>
    </div>

    <!-- تأیید نهایی -->
    <div class="sec">
      <div class="check-row">
        <input type="checkbox" id="chk_agree" required>
        <label for="chk_agree" style="color:#93c5fd;cursor:pointer">
          تأیید می‌کنم که دیتابیس MySQL ساخته شده، اطلاعات فوق صحیح است و مسئولیت محافظت از این فایل تنظیمات را می‌پذیرم.
          در صورت فعال‌بودن گزینه پاک‌سازی، می‌دانم تمام داده‌های قبلی حذف می‌شوند.
        </label>
      </div>
      <button type="submit" class="btn btn-primary" id="btn_submit">⚙️ ساخت جداول و فعال‌سازی سامانه</button>
    </div>

  </form>

  <script>
  // تغییر رنگ دکمه submit بر اساس وضعیت چک‌باکس فرمت
  (function(){
    var chk = document.getElementById('chk_format_install');
    var btn = document.getElementById('btn_submit');
    if(!chk || !btn) return;
    function update(){
      if(chk.checked){
        btn.style.background = '#dc2626';
        btn.textContent = '🗑️ پاک‌کردن دیتابیس + نصب مجدد';
      } else {
        btn.style.background = '';
        btn.textContent = '⚙️ ساخت جداول و فعال‌سازی سامانه';
      }
    }
    chk.addEventListener('change', update);
    update();
  })();
  </script>
  <?php endif; // !phpErrors ?>

<?php endif; // page switch ?>

</div><!-- /card -->

<div style="text-align:center;color:#334155;font-size:11px;padding:10px 0">
  Bastiyan HIS Professional &nbsp;·&nbsp; <?= h(date('Y')) ?> &nbsp;·&nbsp;
  PHP <?= h(PHP_VERSION) ?>
</div>

</div><!-- /wrap -->
</body>
</html>
