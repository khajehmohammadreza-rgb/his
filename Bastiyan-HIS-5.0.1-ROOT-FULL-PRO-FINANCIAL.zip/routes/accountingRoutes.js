const router = require('express').Router();
const ctrl = require('../controllers/accountingController');
router.get('/balance/:admissionId', ctrl.getDischargeBalance);
router.post('/pay', ctrl.addPayment);
module.exports = router;
