const router = require('express').Router();
const ctrl = require('../controllers/patientController');
router.post('/fast-admit', ctrl.fastAdmit);
router.get('/queue', ctrl.getQueue);
module.exports = router;
