const router = require('express').Router();
const ctrl = require('../controllers/doctorController');
router.post('/complete', ctrl.completeVisit);
module.exports = router;
