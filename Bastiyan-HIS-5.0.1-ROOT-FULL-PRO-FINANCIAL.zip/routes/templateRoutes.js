const router = require('express').Router();
const ctrl = require('../controllers/templateController');
router.get('/list', ctrl.getAllTemplates);
router.post('/save', ctrl.saveTemplate);
router.delete('/:id', ctrl.deleteTemplate);
module.exports = router;
