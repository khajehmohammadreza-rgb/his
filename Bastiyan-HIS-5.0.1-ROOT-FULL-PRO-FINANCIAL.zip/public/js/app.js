/**
 * Bastiyan HIS Enterprise - Core Client Controller
 * Includes POS zero counter, keyboard navigation, double click patient selector, and discharge sync
 */

document.addEventListener('DOMContentLoaded', () => {
    initKeyboardShortcuts();
    initDoubleClickHandlers();
    loadPatientQueue();
    bindPaymentPills();
});

// 1. POS Helper & Zero Assistant
window.updatePosHelper = function(val) {
    const rawVal = String(val).replace(/[^0-9]/g, '');
    const toman = parseInt(rawVal) || 0;
    const rial = toman * 10;
    const badge = document.getElementById('posHelperDisplay');
    if (!badge) return;

    if (toman === 0) {
        badge.innerHTML = '💡 جهت کارتخوان: <b>۰ ریال</b> (۰ صفر)';
        return;
    }

    const zerosMatch = rial.toString().match(/0+$/);
    const zeroCount = zerosMatch ? zerosMatch[0].length : 0;
    
    badge.innerHTML = `💡 مبلغ کارتخوان: <b>${rial.toLocaleString('fa-IR')} ریال</b> (${zeroCount} صفر در دستگاه کارتخوان)`;
};

// 2. Global Hotkeys for Ultra-Fast Workflow
function initKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
        // F2: Fast Admission Save
        if (e.key === 'F2') {
            e.preventDefault();
            const btnAdmit = document.getElementById('btnSubmitAdmit');
            if (btnAdmit) btnAdmit.click();
        }
        // F3: Print Patient Receipt / Ticket
        else if (e.key === 'F3') {
            e.preventDefault();
            const btnPrint = document.getElementById('btnQuickPrint');
            if (btnPrint) btnPrint.click();
        }
        // Ctrl + Enter: Quick Confirm in any Modal/Action
        else if (e.ctrlKey && e.key === 'Enter') {
            e.preventDefault();
            const activeModalBtn = document.querySelector('.modal-overlay.active .btn-teal, #btnSubmitAdmit');
            if (activeModalBtn) activeModalBtn.click();
        }
    });
}

// 3. Double-Click Quick Selection for Reception & Doctor Desk
function initDoubleClickHandlers() {
    document.addEventListener('dblclick', (e) => {
        const row = e.target.closest('tr[data-admission-id]');
        if (row) {
            const admId = row.getAttribute('data-admission-id');
            const pName = row.getAttribute('data-patient-name');
            selectPatientForDischarge(admId, pName);
        }
    });
}

// 4. Payment Method Selection
function bindPaymentPills() {
    document.querySelectorAll('.pay-pill').forEach(pill => {
        pill.addEventListener('click', function() {
            document.querySelectorAll('.pay-pill').forEach(p => p.classList.remove('active'));
            this.classList.add('active');
            const methodInput = document.getElementById('selectedPayMethod');
            if (methodInput) methodInput.value = this.getAttribute('data-method');
        });
    });
}

// 5. Patient Admission & Safe Deposit Logging
window.submitFastAdmission = async function() {
    const payload = {
        fullName: document.getElementById('patName').value,
        nationalCode: document.getElementById('patNatCode').value,
        phone: document.getElementById('patPhone').value,
        serviceTitle: document.getElementById('patService').value,
        serviceFee: document.getElementById('patFee').value || 0,
        initialPaid: document.getElementById('patPaidAmount').value || 0,
        payMethod: document.getElementById('selectedPayMethod').value || 'pos',
        discountVal: document.getElementById('patDiscountVal').value || 0,
        discountType: document.getElementById('patDiscountType').value || 'fixed'
    };

    if (!payload.fullName || !payload.serviceTitle) {
        alert('لطفاً نام بیمار و عنوان خدمت را وارد فرمایید.');
        return;
    }

    try {
        const res = await fetch('/api/patients/fast-admit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const result = await res.json();
        if (result.success) {
            alert('پذیرش با موفقیت ثبت گردید. پرداخت در صورتحساب ترخیص ثبت شد.');
            loadPatientQueue();
            
            if (document.getElementById('chkAutoPrint').checked) {
                PrintEngine.printReceipt(payload.fullName, payload.serviceTitle, payload.initialPaid, payload.serviceFee - payload.initialPaid);
            }
            // Clear inputs
            document.getElementById('patName').value = '';
            document.getElementById('patNatCode').value = '';
            document.getElementById('patPaidAmount').value = '';
            updatePosHelper(0);
        }
    } catch (err) {
        alert('خطا در ثبت پذیرش: ' + err.message);
    }
};

// 6. Queue Loader
async function loadPatientQueue() {
    const tbody = document.getElementById('queueTableBody');
    if (!tbody) return;
    try {
        const res = await fetch('/api/patients/queue');
        const data = await res.json();
        tbody.innerHTML = '';
        data.queue.forEach(item => {
            const tr = document.createElement('tr');
            tr.setAttribute('data-admission-id', item.admissionId);
            tr.setAttribute('data-patient-name', item.full_name);
            tr.innerHTML = `
                <td><b>${item.admission_code}</b></td>
                <td><b>${item.full_name}</b> <small class="text-muted">(${item.national_code || '---'})</small></td>
                <td>${item.service_title}</td>
                <td>${Number(item.service_fee).toLocaleString('fa-IR')} تومان</td>
                <td><span class="kbd-badge" style="background:#0284c7;color:#fff;">دبل کلیک جهت تسویه ترخیص</span></td>
            `;
            tbody.appendChild(tr);
        });
    } catch (e) {
        console.error('Queue load error', e);
    }
}

// 7. Discharge Auto Deduct & Balancing Modal
window.selectPatientForDischarge = async function(admId, pName) {
    try {
        const res = await fetch('/api/accounting/balance/' + admId);
        const data = await res.json();
        if (data.success) {
            const s = data.summary;
            document.getElementById('modalPatientTitle').innerText = 'تسویه حساب ترخیص: ' + pName;
            document.getElementById('modalTotalFee').innerText = s.totalServicesCost.toLocaleString('fa-IR') + ' تومان';
            document.getElementById('modalPaidDeposit').innerText = s.totalPaidDeposits.toLocaleString('fa-IR') + ' تومان (کسر خودکار پرداختی‌های قبلی)';
            document.getElementById('modalDiscount').innerText = s.totalDiscount.toLocaleString('fa-IR') + ' تومان';
            document.getElementById('modalFinalRemaining').innerText = s.finalPayable.toLocaleString('fa-IR') + ' تومان';
            document.getElementById('dischargeModal').classList.add('active');
        }
    } catch (e) {
        alert('خطا در دریافت مانده ترخیص: ' + e.message);
    }
};

window.closeModal = function(modalId) {
    document.getElementById(modalId).classList.remove('active');
};

// 8. Printing Engine (Receipts, Consent & Educational Sheets)
window.PrintEngine = {
    printReceipt: function(patientName, service, paid, remaining) {
        const w = window.open('', '_blank');
        w.document.write(`
            <html dir="rtl">
            <head><title>فیش صندوق و پذیرش باستیان</title>
            <style>
                body { font-family: Tahoma, sans-serif; padding: 25px; font-size: 13px; line-height: 2; }
                .text-center { text-align: center; }
                .row { display: flex; justify-content: space-between; border-bottom: 1px dashed #aaa; padding: 6px 0; }
            </style>
            </head>
            <body>
                <div class="text-center">
                    <h2 style="margin:0;">مرکز تخصصی جراحی و زیبایی باستیان</h2>
                    <p>فیش پذیرش بیمار و رسید مالی صندوق</p>
                </div>
                <div class="row"><span>نام مراجع:</span><b>${patientName || 'مراجع آزاد'}</b></div>
                <div class="row"><span>خدمت / اقدام:</span><b>${service || 'ویزیت'}</b></div>
                <div class="row"><span>مبلغ پرداختی:</span><b>${Number(paid || 0).toLocaleString('fa-IR')} تومان</b></div>
                <div class="row"><span>باقیمانده حساب:</span><b>${Number(remaining || 0).toLocaleString('fa-IR')} تومان</b></div>
                <div class="text-center" style="margin-top:25px;"><small>این پرداختی در صورتحساب نهایی ترخیص کسر شده است.</small></div>
                <script>window.print(); window.close();<\/script>
            </body>
            </html>
        `);
        w.document.close();
    },
    printEducationSheet: function() {
        const w = window.open('', '_blank');
        w.document.write(`
            <html dir="rtl">
            <head><title>برگه آموزش مراقبت در منزل</title>
            <style>body { font-family: Tahoma; padding: 30px; line-height: 2.2; font-size: 14px; }</style>
            </head>
            <body>
                <h2 style="text-align:center; color:#0d9488;">مرکز تخصصی جراحی و کلینیک زخم باستیان</h2>
                <h3 style="border-bottom:2px solid #333; padding-bottom:10px;">دستورالعمل جامع مراقبت در منزل بیمار</h3>
                <ol>
                    <li>پانسمان محل جراحی یا اقدام درمانی را تا زمان قید شده توسط پزشک، کاملاً تمیز و خشک نگه دارید.</li>
                    <li>داروهای آنتی‌بیوتیک و مسکن تجویزشده را در ساعات منظم مصرف فرمایید.</li>
                    <li>در صورت مشاهده قرمزی فزاینده، خونریزی غیرمعمول یا تب بالای ۳۸ درجه، سریعاً به کلینیک مراجعه نمایید.</li>
                    <li>نوبت مراجعه بعدی جهت بازبینی و تعویض پانسمان را از بخش پذیرش دریافت نمایید.</li>
                </ol>
                <div style="margin-top:40px; text-align:left;"><b>مهر و امضای پزشک معالج / سرپرستار</b></div>
                <script>window.print(); window.close();<\/script>
            </body>
            </html>
        `);
        w.document.close();
    }
};
