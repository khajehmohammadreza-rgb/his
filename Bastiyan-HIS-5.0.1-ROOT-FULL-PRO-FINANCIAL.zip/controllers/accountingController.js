const db = require('../config/database');

exports.getDischargeBalance = (req, res) => {
    const { admissionId } = req.params;

    db.get(`SELECT a.*, p.full_name, p.national_code FROM admissions a JOIN patients p ON a.patient_id = p.id WHERE a.id = ?`, [admissionId], (err, admission) => {
        if (err || !admission) return res.status(404).json({ success: false, message: 'پذیرش یافت نشد' });

        db.all(`SELECT * FROM transactions WHERE admission_id = ?`, [admissionId], (err2, transactions) => {
            if (err2) return res.status(500).json({ success: false, message: err2.message });

            const totalServicesCost = Number(admission.service_fee) || 0;
            const totalPaidDeposits = transactions.reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
            
            let totalDiscount = 0;
            transactions.forEach(t => {
                if (t.discount_type === 'percentage') {
                    totalDiscount += (totalServicesCost * (Number(t.discount_value) / 100));
                } else {
                    totalDiscount += (Number(t.discount_value) || 0);
                }
            });

            const finalPayable = Math.max(0, totalServicesCost - totalDiscount - totalPaidDeposits);

            return res.json({
                success: true,
                admission,
                transactions,
                summary: {
                    totalServicesCost,
                    totalDiscount,
                    totalPaidDeposits,
                    finalPayable,
                    isCleared: finalPayable === 0
                }
            });
        });
    });
};

exports.addPayment = (req, res) => {
    const { admissionId, patientId, amount, method, discountType, discountValue, note } = req.body;
    db.run(
        `INSERT INTO transactions (admission_id, patient_id, amount, method, discount_type, discount_value, note)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [admissionId, patientId, amount, method, discountType || 'fixed', discountValue || 0, note || 'واریزی صندوق'],
        function(err) {
            if (err) return res.status(500).json({ success: false, message: err.message });
            res.json({ success: true, message: 'پرداخت با موفقیت در سیستم ثبت گردید.', transactionId: this.lastID });
        }
    );
};
