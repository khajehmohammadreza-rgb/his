const db = require('../config/database');

exports.fastAdmit = (req, res) => {
    const { nationalCode, fullName, phone, age, gender, insuranceType, serviceTitle, serviceFee, doctorId, initialPaid, payMethod, discountVal, discountType } = req.body;
    
    db.run(
        `INSERT OR REPLACE INTO patients (national_code, full_name, phone, age, gender, insurance_type) 
         VALUES (?, ?, ?, ?, ?, ?)`,
        [nationalCode, fullName, phone, age, gender, insuranceType],
        function(err) {
            if (err) return res.status(500).json({ success: false, message: err.message });
            
            const patientId = this.lastID || 1;
            const admissionCode = 'ADM-' + Date.now().toString().slice(-6);
            
            db.run(
                `INSERT INTO admissions (admission_code, patient_id, doctor_id, department, service_title, service_fee, status) 
                 VALUES (?, ?, ?, 'پذیرش عمومی', ?, ?, 'admitted')`,
                [admissionCode, patientId, doctorId || 1, serviceTitle || 'ویزیت و معاینه', serviceFee || 0],
                function(err2) {
                    if (err2) return res.status(500).json({ success: false, message: err2.message });
                    const admissionId = this.lastID;

                    // If initial deposit / fee paid on admission, register it seamlessly
                    if (initialPaid && Number(initialPaid) > 0) {
                        db.run(
                            `INSERT INTO transactions (admission_id, patient_id, amount, method, discount_type, discount_value, note)
                             VALUES (?, ?, ?, ?, ?, ?, 'پرداخت اولیه در پذیرش')`,
                            [admissionId, patientId, initialPaid, payMethod || 'pos', discountType || 'fixed', discountVal || 0]
                        );
                    }

                    return res.json({
                        success: true,
                        message: 'پذیرش با موفقیت ثبت شد و پرداخت اولیه بدون اختلال در گردش کار اعمال گردید.',
                        data: { admissionId, admissionCode, patientId, fullName, serviceTitle, initialPaid }
                    });
                }
            );
        }
    );
};

exports.getQueue = (req, res) => {
    const sql = `SELECT a.id as admissionId, a.admission_code, a.service_title, a.service_fee, a.status, a.created_at,
                        p.id as patientId, p.full_name, p.national_code, p.phone
                 FROM admissions a
                 JOIN patients p ON a.patient_id = p.id
                 ORDER BY a.id DESC LIMIT 50`;
    db.all(sql, [], (err, rows) => {
        if (err) return res.status(500).json({ success: false, message: err.message });
        res.json({ success: true, queue: rows });
    });
};
