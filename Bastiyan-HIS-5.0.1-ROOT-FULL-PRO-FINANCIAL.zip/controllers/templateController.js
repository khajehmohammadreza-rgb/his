const db = require('../config/database');

exports.getAllTemplates = (req, res) => {
    db.all(`SELECT * FROM templates ORDER BY id ASC`, [], (err, rows) => {
        if (err) return res.status(500).json({ success: false, message: err.message });
        res.json({ success: true, templates: rows });
    });
};

exports.saveTemplate = (req, res) => {
    const { id, title, category, content } = req.body;
    if (id) {
        db.run(`UPDATE templates SET title = ?, category = ?, content = ? WHERE id = ?`, [title, category, content, id], (err) => {
            if (err) return res.status(500).json({ success: false, message: err.message });
            res.json({ success: true, message: 'قالب با موفقیت ویرایش شد.' });
        });
    } else {
        db.run(`INSERT INTO templates (title, category, content) VALUES (?, ?, ?)`, [title, category, content], function(err) {
            if (err) return res.status(500).json({ success: false, message: err.message });
            res.json({ success: true, message: 'قالب جدید ایجاد شد.', templateId: this.lastID });
        });
    }
};

exports.deleteTemplate = (req, res) => {
    const { id } = req.params;
    db.run(`DELETE FROM templates WHERE id = ?`, [id], (err) => {
        if (err) return res.status(500).json({ success: false, message: err.message });
        res.json({ success: true, message: 'قالب حذف گردید.' });
    });
};
