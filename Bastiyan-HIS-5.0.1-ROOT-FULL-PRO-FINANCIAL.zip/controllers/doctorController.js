const db = require('../config/database');

exports.completeVisit = (req, res) => {
    const { admissionId, diagnosis, prescription, proceduresOrdered, nextAction } = req.body;
    db.run(
        `UPDATE admissions SET status = 'treatment' WHERE id = ?`,
        [admissionId],
        function(err) {
            if (err) return res.status(500).json({ success: false, message: err.message });
            res.json({ success: true, message: 'ویزیت ثبت شد و بیمار بدون معطلی به بخش بعدی هدایت گردید.' });
        }
    );
};
