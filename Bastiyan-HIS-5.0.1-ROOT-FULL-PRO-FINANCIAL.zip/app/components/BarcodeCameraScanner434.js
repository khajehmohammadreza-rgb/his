import React, { useEffect, useRef, useState } from '../../vendor/react.js';
import { X, Camera, CheckCircle2, AlertTriangle, Search } from '../../vendor/lucide-react.js';
const h = React.createElement;
const L = { 0: '0001101', 1: '0011001', 2: '0010011', 3: '0111101', 4: '0100011', 5: '0110001', 6: '0101111', 7: '0111011', 8: '0110111', 9: '0001011' };
const G = { 0: '0100111', 1: '0110011', 2: '0011011', 3: '0100001', 4: '0011101', 5: '0111001', 6: '0000101', 7: '0010001', 8: '0001001', 9: '0010111' };
const R = { 0: '1110010', 1: '1100110', 2: '1101100', 3: '1000010', 4: '1011100', 5: '1001110', 6: '1010000', 7: '1000100', 8: '1001000', 9: '1110100' };
const PARITY = { LLLLLL: '0', LLGLGG: '1', LLGGLG: '2', LLGGGL: '3', LGLLGG: '4', LGGLLG: '5', LGGGLL: '6', LGLGLG: '7', LGLGGL: '8', LGGLGL: '9' };
const rev = (obj) => Object.fromEntries(Object.entries(obj).map(([k, v]) => [v, k]));
const LR = rev(L), GR = rev(G), RR = rev(R);
const dist = (a, b) => {
    let n = 0;
    for (let i = 0; i < a.length; i++)
        if (a[i] !== b[i])
            n++;
    return n;
};
function closest(pattern, map, max = 1) {
    if (map[pattern] != null)
        return map[pattern];
    let best = null, bd = 99;
    for (const [p, d] of Object.entries(map)) {
        const x = dist(pattern, p);
        if (x < bd) {
            bd = x;
            best = d;
        }
    }
    return bd <= max ? best : null;
}
function decodeLeftPattern(pattern) {
    if (LR[pattern] != null)
        return { digit: LR[pattern], parity: 'L' };
    if (GR[pattern] != null)
        return { digit: GR[pattern], parity: 'G' };
    let best = null, bd = 99;
    for (const [p, d] of Object.entries(LR)) {
        const x = dist(pattern, p);
        if (x < bd) {
            bd = x;
            best = { digit: d, parity: 'L' };
        }
    }
    for (const [p, d] of Object.entries(GR)) {
        const x = dist(pattern, p);
        if (x < bd) {
            bd = x;
            best = { digit: d, parity: 'G' };
        }
    }
    return bd <= 1 ? best : null;
}
function eanChecksum(code) {
    const ds = String(code).split('').map(Number), check = ds.pop();
    let sum = 0;
    for (let i = 0; i < ds.length; i++)
        sum += ds[i] * (((ds.length - 1 - i) % 2 === 0) ? 3 : 1);
    return (10 - (sum % 10)) % 10 === check;
}
export function decodeEanModules(bits) {
    const s = String(bits || '');
    if (s.length === 95 && dist(s.slice(0, 3), '101') <= 1 && dist(s.slice(45, 50), '01010') <= 1 && dist(s.slice(92), '101') <= 1) {
        let left = '', parity = '';
        for (let i = 0; i < 6; i++) {
            const p = s.slice(3 + i * 7, 10 + i * 7), decoded = decodeLeftPattern(p);
            if (!decoded)
                return null;
            left += decoded.digit;
            parity += decoded.parity;
        }
        const first = PARITY[parity];
        if (first == null)
            return null;
        let right = '';
        for (let i = 0; i < 6; i++) {
            const d = closest(s.slice(50 + i * 7, 57 + i * 7), RR, 1);
            if (d == null)
                return null;
            right += d;
        }
        const code = first + left + right;
        return eanChecksum(code) ? code : null;
    }
    if (s.length === 67 && dist(s.slice(0, 3), '101') <= 1 && dist(s.slice(31, 36), '01010') <= 1 && dist(s.slice(64), '101') <= 1) {
        let code = '';
        for (let i = 0; i < 4; i++) {
            const d = closest(s.slice(3 + i * 7, 10 + i * 7), LR, 1);
            if (d == null)
                return null;
            code += d;
        }
        for (let i = 0; i < 4; i++) {
            const d = closest(s.slice(36 + i * 7, 43 + i * 7), RR, 1);
            if (d == null)
                return null;
            code += d;
        }
        return eanChecksum(code) ? code : null;
    }
    return null;
}
function rle(bits) {
    const out = [];
    if (!bits.length)
        return out;
    let bit = bits[0], start = 0;
    for (let i = 1; i <= bits.length; i++) {
        if (i === bits.length || bits[i] !== bit) {
            out.push({ bit, len: i - start, start });
            if (i < bits.length) {
                bit = bits[i];
                start = i;
            }
        }
    }
    return out;
}
function sampleModules(bits, start, module, count) {
    let out = '';
    for (let i = 0; i < count; i++) {
        const at = Math.round(start + (i + .5) * module);
        out += bits[Math.max(0, Math.min(bits.length - 1, at))] ? '1' : '0';
    }
    return out;
}
function decodeLine(gray) {
    let min = 255, max = 0;
    for (const v of gray) {
        if (v < min)
            min = v;
        if (v > max)
            max = v;
    }
    if (max - min < 45)
        return null;
    for (const bias of [-18, -8, 0, 8, 18]) {
        const th = Math.max(25, Math.min(230, (min + max) / 2 + bias));
        const bits = Array.from(gray, v => v < th ? 1 : 0), runs = rle(bits);
        for (let i = 1; i < runs.length - 3; i++) {
            const a = runs[i], b = runs[i + 1], c = runs[i + 2], quiet = runs[i - 1];
            if (a.bit !== 1 || b.bit !== 0 || c.bit !== 1 || quiet.bit !== 0)
                continue;
            const m = (a.len + b.len + c.len) / 3;
            if (m < 1.2 || Math.max(a.len, b.len, c.len) > m * 1.85 || Math.min(a.len, b.len, c.len) < m * .45 || quiet.len < m * 3)
                continue;
            for (const count of [95, 67])
                for (const scale of [.94, .97, 1, 1.03, 1.06]) {
                    const mm = m * scale;
                    if (a.start + count * mm > bits.length)
                        continue;
                    const code = decodeEanModules(sampleModules(bits, a.start, mm, count));
                    if (code)
                        return code;
                }
        }
    }
    return null;
}
function decodeCanvasEan(video, canvas) {
    if (!(video === null || video === void 0 ? void 0 : video.videoWidth) || !(video === null || video === void 0 ? void 0 : video.videoHeight))
        return null;
    const w = Math.min(1000, video.videoWidth), ratio = w / video.videoWidth, h = Math.round(video.videoHeight * ratio);
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(video, 0, 0, w, h);
    const rows = [.42, .46, .5, .54, .58];
    for (const ry of rows) {
        const y = Math.max(0, Math.min(h - 1, Math.round(h * ry))), data = ctx.getImageData(0, y, w, 1).data, gray = new Uint8Array(w);
        for (let x = 0; x < w; x++) {
            const j = x * 4;
            gray[x] = Math.round(data[j] * .299 + data[j + 1] * .587 + data[j + 2] * .114);
        }
        const code = decodeLine(gray);
        if (code)
            return code;
    }
    return null;
}
function beep() {
    try {
        const A = window.AudioContext || window.webkitAudioContext;
        if (!A)
            return;
        const ctx = new A(), o = ctx.createOscillator(), g = ctx.createGain();
        o.frequency.value = 1250;
        g.gain.value = .12;
        o.connect(g);
        g.connect(ctx.destination);
        o.start();
        o.stop(ctx.currentTime + .12);
    }
    catch (_) { }
}
export function BarcodeCameraScanner({ open = false, onDetected, onClose, continuous = false }) {
    const videoRef = useRef(null), canvasRef = useRef(null), streamRef = useRef(null), timerRef = useRef(null), doneRef = useRef(false), detectorRef = useRef(null), resumeTimerRef = useRef(null);
    const [manual, setManual] = useState('');
    const [error, setError] = useState('');
    const [status, setStatus] = useState('');
    const [lastCode, setLastCode] = useState('');
    const [capturing, setCapturing] = useState(false);
    const resumeScan = () => { doneRef.current = false; setLastCode(''); setStatus(detectorRef.current ? 'دوربین آماده است؛ بارکد بعدی را داخل کادر قرار دهید.' : 'موتور داخلی آماده است؛ بارکد بعدی را صاف داخل کادر قرار دهید.'); };
    useEffect(() => {
        if (!open)
            return undefined;
        let cancelled = false;
        doneRef.current = false;
        setError('');
        setLastCode('');
        setStatus('در حال آماده‌سازی دوربین...');
        const detectDone = (raw) => {
            if (doneRef.current || !raw)
                return;
            doneRef.current = true;
            beep();
            setLastCode(String(raw));
            setStatus(`بارکد شناسایی شد: ${raw}`);
            const control = { resume: resumeScan, close: () => onClose === null || onClose === void 0 ? void 0 : onClose() };
            window.setTimeout(() => {
                const result = onDetected === null || onDetected === void 0 ? void 0 : onDetected(String(raw), control);
                if (!continuous && result !== false)
                    onClose === null || onClose === void 0 ? void 0 : onClose();
            }, 80);
        };
        const start = async () => {
            var _a, _b;
            try {
                if (!((_a = navigator.mediaDevices) === null || _a === void 0 ? void 0 : _a.getUserMedia))
                    throw new Error('NO_CAMERA');
                const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 }, focusMode: { ideal: 'continuous' } }, audio: false });
                if (cancelled) {
                    stream.getTracks().forEach(t => t.stop());
                    return;
                }
                streamRef.current = stream;
                if (videoRef.current) {
                    videoRef.current.srcObject = stream;
                    await videoRef.current.play();
                }
                const Ctor = window.BarcodeDetector;
                if (Ctor) {
                    const supported = await ((_b = Ctor.getSupportedFormats) === null || _b === void 0 ? void 0 : _b.call(Ctor).catch(() => [])) || [];
                    const requested = ['ean_13', 'ean_8', 'code_128', 'code_39', 'upc_a', 'upc_e', 'qr_code'].filter(x => !supported.length || supported.includes(x));
                    detectorRef.current = new Ctor(requested.length ? { formats: requested } : undefined);
                    setStatus('دوربین آماده است؛ شناسایی خودکار فعال است.');
                    const scan = async () => {
                        var _a;
                        if (cancelled)
                            return;
                        if (!doneRef.current && videoRef.current) {
                            try {
                                const codes = await detectorRef.current.detect(videoRef.current);
                                const raw = (_a = codes === null || codes === void 0 ? void 0 : codes[0]) === null || _a === void 0 ? void 0 : _a.rawValue;
                                if (raw) {
                                    detectDone(raw);
                                }
                            }
                            catch (_) { }
                        }
                        timerRef.current = window.setTimeout(scan, 130);
                    };
                    scan();
                    return;
                }
                detectorRef.current = null;
                setStatus('دوربین آماده است؛ موتور داخلی EAN-13/EAN-8 و شناسایی خودکار فعال است.');
                const scanFallback = () => {
                    if (cancelled)
                        return;
                    if (!doneRef.current && videoRef.current) {
                        try {
                            const raw = decodeCanvasEan(videoRef.current, canvasRef.current);
                            if (raw)
                                detectDone(raw);
                        }
                        catch (_) { }
                    }
                    timerRef.current = window.setTimeout(scanFallback, 160);
                };
                scanFallback();
            }
            catch (err) {
                setError('دسترسی به دوربین برقرار نشد. سایت باید با HTTPS باز باشد و مجوز Camera برای مرورگر فعال شود.');
                setStatus('');
            }
        };
        start();
        return () => {
            var _a;
            cancelled = true;
            if (timerRef.current)
                clearTimeout(timerRef.current);
            if (resumeTimerRef.current)
                clearTimeout(resumeTimerRef.current);
            (_a = streamRef.current) === null || _a === void 0 ? void 0 : _a.getTracks().forEach(t => t.stop());
            streamRef.current = null;
            detectorRef.current = null;
        };
    }, [open]);
    if (!open)
        return null;
    const submit = e => {
        e.preventDefault();
        const v = manual.trim();
        if (v) {
            beep();
            onDetected === null || onDetected === void 0 ? void 0 : onDetected(v, { resume: resumeScan, close: () => onClose === null || onClose === void 0 ? void 0 : onClose() });
            setManual('');
        }
    };
    const captureAnalyze = async () => {
        var _a;
        if (!videoRef.current || !canvasRef.current)
            return;
        setCapturing(true);
        setStatus('در حال تحلیل تصویر ثابت بارکد...');
        try {
            const v = videoRef.current, c = canvasRef.current;
            c.width = v.videoWidth || 1280;
            c.height = v.videoHeight || 720;
            const ctx = c.getContext('2d', { willReadFrequently: true });
            ctx.drawImage(v, 0, 0, c.width, c.height);
            let raw = '';
            if (detectorRef.current) {
                try {
                    const codes = await detectorRef.current.detect(c);
                    raw = ((_a = codes === null || codes === void 0 ? void 0 : codes[0]) === null || _a === void 0 ? void 0 : _a.rawValue) || '';
                }
                catch (_) { }
            }
            if (!raw)
                raw = decodeCanvasEan(v, c) || '';
            if (raw) {
                doneRef.current = false;
                beep();
                setLastCode(raw);
                setStatus(`بارکد از تصویر ثابت شناسایی شد: ${raw}`);
                onDetected === null || onDetected === void 0 ? void 0 : onDetected(raw, { resume: resumeScan, close: () => onClose === null || onClose === void 0 ? void 0 : onClose() });
            }
            else
                setStatus('از تصویر ثابت بارکدی شناسایی نشد؛ فاصله و نور را تنظیم کنید و دوباره بزنید.');
        }
        finally {
            setCapturing(false);
        }
    };
    return h('div', { className: 'bhis-picker-overlay', dir: 'rtl', role: 'dialog', 'aria-modal': 'true' }, h('div', { className: 'bhis-scanner-panel bhis-scanner-rapid' }, h('header', { className: 'bhis-calendar-head' }, h('div', null, h('strong', null, 'بارکدخوان سریع کالا و دارو'), h('span', null, 'شناسایی خودکار • دوربین موبایل / وب‌کم / بارکدخوان فیزیکی')), h('button', { type: 'button', className: 'bhis-icon-button', onClick: onClose }, h(X, { className: 'w-5 h-5' }))), h('div', { className: 'bhis-scanner-video' }, h('video', { ref: videoRef, playsInline: true, muted: true }), h('canvas', { ref: canvasRef, style: { display: 'none' } }), !error ? h('div', { className: 'bhis-scanner-frame' }, h('span')) : null, error ? h('div', { className: 'bhis-scanner-error' }, h(AlertTriangle, { className: 'w-8 h-8' }), h('strong', null, 'دوربین در دسترس نیست'), h('p', null, error)) : null), h('div', { className: `bhis-scanner-status ${lastCode ? 'success' : ''}` }, lastCode ? h(CheckCircle2, { className: 'w-4 h-4' }) : h(Camera, { className: 'w-4 h-4' }), status || ' '), h('div', { className: 'bhis-scanner-actions' }, h('button', { type: 'button', className: 'bhis-secondary-button', disabled: capturing, onClick: captureAnalyze }, h(Camera, { className: 'w-4 h-4' }), capturing ? 'در حال تحلیل...' : 'اسکن دقیق از تصویر'), lastCode && continuous ? h('button', { type: 'button', className: 'bhis-primary-button', onClick: resumeScan }, 'آماده اسکن بعدی') : null), h('form', { className: 'bhis-scanner-manual', onSubmit: submit }, h(Search, { className: 'w-4 h-4' }), h('input', { value: manual, onChange: e => setManual(e.target.value), placeholder: 'بارکد را دستی وارد کنید یا با بارکدخوان USB اسکن کنید...', inputMode: 'numeric' }), h('button', { type: 'submit', className: 'bhis-primary-button' }, h(CheckCircle2, { className: 'w-4 h-4' }), 'اعمال'))));
}
