import { jsx as _jsx, jsxs as _jsxs } from "../../vendor/react-jsx-runtime.js";
/**
 * Native browser barcode scanner (no external runtime dependency).
 * Uses BarcodeDetector when available and always keeps manual/hardware input fallback.
 */
import React, { useEffect, useRef, useState } from '../../vendor/react.js';
import { Camera, CheckCircle2, X, Barcode, AlertTriangle } from '../../vendor/lucide-react.js';
function playScanBeep() {
    try {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1400, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.15);
    }
    catch (_) { }
}
export const WebcamScannerModal = ({ products = [], onScanBarcode, onClose }) => {
    const videoRef = useRef(null);
    const streamRef = useRef(null);
    const timerRef = useRef(null);
    const [manualBarcodeInput, setManualBarcodeInput] = useState('');
    const [cameraError, setCameraError] = useState(null);
    const [scannedResultText, setScannedResultText] = useState(null);
    const finishScan = (value) => {
        if (!value || scannedResultText)
            return;
        setScannedResultText(value);
        playScanBeep();
        try {
            navigator.vibrate?.(120);
        }
        catch (_) { }
        window.setTimeout(() => onScanBarcode(value), 250);
    };
    useEffect(() => {
        let cancelled = false;
        const start = async () => {
            try {
                if (!navigator.mediaDevices?.getUserMedia)
                    throw new Error('camera_not_supported');
                const BarcodeDetectorCtor = window.BarcodeDetector;
                if (!BarcodeDetectorCtor) {
                    setCameraError('مرورگر این دستگاه اسکن مستقیم بارکد را پشتیبانی نمی‌کند. می‌توانید از بارکدخوان فیزیکی یا ورود دستی استفاده کنید.');
                    return;
                }
                const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
                if (cancelled) {
                    stream.getTracks().forEach(t => t.stop());
                    return;
                }
                streamRef.current = stream;
                if (videoRef.current) {
                    videoRef.current.srcObject = stream;
                    await videoRef.current.play();
                }
                const detector = new BarcodeDetectorCtor({ formats: ['ean_13', 'ean_8', 'code_128', 'code_39', 'upc_a', 'upc_e', 'qr_code'] });
                const scanFrame = async () => {
                    if (cancelled || !videoRef.current)
                        return;
                    try {
                        const codes = await detector.detect(videoRef.current);
                        const raw = codes?.[0]?.rawValue;
                        if (raw) {
                            finishScan(raw);
                            return;
                        }
                    }
                    catch (_) { }
                    timerRef.current = window.setTimeout(scanFrame, 250);
                };
                scanFrame();
            }
            catch (_) {
                setCameraError('دسترسی به دوربین برقرار نشد. مجوز دوربین را فعال کنید یا بارکد را دستی/با بارکدخوان فیزیکی وارد نمایید.');
            }
        };
        start();
        return () => {
            cancelled = true;
            if (timerRef.current)
                window.clearTimeout(timerRef.current);
            streamRef.current?.getTracks().forEach(t => t.stop());
        };
    }, []);
    const handleManualSubmit = (e) => {
        e.preventDefault();
        const value = manualBarcodeInput.trim();
        if (value)
            finishScan(value);
    };
    return (_jsx("div", { className: "fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 dir-rtl", children: _jsxs("div", { className: "bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg p-5 space-y-4 shadow-2xl text-slate-100", children: [_jsxs("div", { className: "flex items-center justify-between border-b border-slate-800 pb-3", children: [_jsxs("div", { className: "flex items-center gap-2.5", children: [_jsx("div", { className: "w-10 h-10 rounded-2xl bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-teal-400", children: _jsx(Camera, { className: "w-5 h-5" }) }), _jsxs("div", { children: [_jsx("h3", { className: "font-extrabold text-sm", children: "\u0627\u0633\u06A9\u0646\u0631 \u0628\u0627\u0631\u06A9\u062F" }), _jsx("p", { className: "text-[11px] text-slate-400", children: "\u062F\u0648\u0631\u0628\u06CC\u0646\u060C \u0628\u0627\u0631\u06A9\u062F\u062E\u0648\u0627\u0646 \u0641\u06CC\u0632\u06CC\u06A9\u06CC \u06CC\u0627 \u0648\u0631\u0648\u062F \u062F\u0633\u062A\u06CC" })] })] }), _jsx("button", { onClick: onClose, className: "text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-slate-800", children: _jsx(X, { className: "w-5 h-5" }) })] }), _jsxs("div", { className: "relative bg-slate-950 rounded-2xl overflow-hidden aspect-video border-2 border-teal-500/30 flex items-center justify-center", children: [_jsx("video", { ref: videoRef, playsInline: true, muted: true, className: "w-full h-full object-cover" }), !cameraError && !scannedResultText && _jsx("div", { className: "absolute inset-6 border-2 border-emerald-400/70 rounded-2xl pointer-events-none flex items-center", children: _jsx("div", { className: "w-full h-0.5 bg-rose-500 animate-pulse" }) }), cameraError && _jsxs("div", { className: "absolute inset-0 bg-slate-950/95 p-5 text-center flex flex-col items-center justify-center gap-3", children: [_jsx(AlertTriangle, { className: "w-10 h-10 text-amber-400" }), _jsx("p", { className: "text-xs text-slate-300 leading-relaxed", children: cameraError })] }), scannedResultText && _jsxs("div", { className: "absolute inset-0 bg-emerald-950/90 flex flex-col items-center justify-center gap-2", children: [_jsx(CheckCircle2, { className: "w-12 h-12 text-emerald-400" }), _jsx("span", { className: "font-black", children: "\u0628\u0627\u0631\u06A9\u062F \u0634\u0646\u0627\u0633\u0627\u06CC\u06CC \u0634\u062F" }), _jsx("span", { className: "font-mono text-emerald-300", children: scannedResultText })] })] }), _jsxs("form", { onSubmit: handleManualSubmit, className: "space-y-2", children: [_jsx("label", { className: "block text-slate-300 font-bold text-[11px]", children: "\u0648\u0631\u0648\u062F \u062F\u0633\u062A\u06CC \u06CC\u0627 \u0628\u0627\u0631\u06A9\u062F\u062E\u0648\u0627\u0646 \u0641\u06CC\u0632\u06CC\u06A9\u06CC:" }), _jsxs("div", { className: "flex gap-2", children: [_jsxs("div", { className: "relative flex-1", children: [_jsx(Barcode, { className: "w-4 h-4 text-slate-400 absolute right-3 top-2.5" }), _jsx("input", { autoFocus: true, type: "text", value: manualBarcodeInput, onChange: e => setManualBarcodeInput(e.target.value), placeholder: "\u0628\u0627\u0631\u06A9\u062F \u0631\u0627 \u0648\u0627\u0631\u062F \u06CC\u0627 \u0627\u0633\u06A9\u0646 \u06A9\u0646\u06CC\u062F", className: "w-full bg-slate-800 border border-slate-700 pr-9 pl-3 py-2 rounded-xl font-mono text-xs focus:border-teal-500 focus:outline-none" })] }), _jsx("button", { type: "submit", className: "bg-teal-600 hover:bg-teal-500 px-4 py-2 rounded-xl text-xs font-bold", children: "\u062B\u0628\u062A" })] })] }), products.filter(p => p.barcode).slice(0, 4).length > 0 && _jsxs("div", { className: "text-[10px] text-slate-500", children: ["\u0646\u0645\u0648\u0646\u0647 \u06A9\u0627\u0644\u0627\u0647\u0627\u06CC \u062F\u0627\u0631\u0627\u06CC \u0628\u0627\u0631\u06A9\u062F: ", products.filter(p => p.barcode).slice(0, 4).map(p => p.name).join('، ')] })] }) }));
};
