import React from '../../vendor/react.js';
import { ProfessionalCashierModule } from './ProfessionalCashierModule453.js';
const h=React.createElement;
export function ProfessionalDischargeWorkspace450(props){
 return h('div',{className:'bhis-discharge450',dir:'rtl'},h(ProfessionalCashierModule,props));
}
