import React, { useMemo, useState } from '../../vendor/react.js';
import { Download, FilePlus2, Filter, Play, Save, Trash2 } from '../../vendor/lucide-react.js';
import { exportDataToExcel } from '../utils/excelUtils.js';

const SOURCES = {
  serviceRecipients: {
    label: 'خدمات انجام‌شده برای بیماران',
    columns: {
      patientName: 'نام بیمار', patientMobile: 'شماره همراه', patientNationalId: 'کد ملی',
      serviceName: 'خدمت / کالا', quantity: 'تعداد', amount: 'مبلغ', date: 'تاریخ',
      doctorName: 'پزشک / ارائه‌دهنده', invoiceNumber: 'شماره فاکتور', status: 'وضعیت',
    },
  },
  patients: { label: 'بیماران', columns: { fullName: 'نام بیمار', mobilePhone: 'شماره همراه', nationalId: 'کد ملی', fileNumber: 'شماره پرونده', lastVisitDate: 'آخرین مراجعه', currentDebt: 'بدهی جاری', verificationStatus: 'وضعیت هویت' } },
  invoices: { label: 'فاکتورهای فروش', columns: { invoiceNumber: 'شماره فاکتور', patientName: 'بیمار', patientMobile: 'شماره همراه', jalaliDate: 'تاریخ', payableAmount: 'مبلغ', paymentMethodLabel: 'روش پرداخت', createdByUserName: 'صادرکننده', status: 'وضعیت' } },
  payments: { label: 'تراکنش‌های صندوق', columns: { invoiceNumber: 'شماره فاکتور', patientName: 'بیمار', methodLabel: 'روش پرداخت', amount: 'مبلغ', transactionNumber: 'شماره تراکنش', transactionDate: 'تاریخ تراکنش', transactionTime: 'ساعت', bankName: 'بانک / درگاه', terminalNumber: 'پایانه', cashier: 'صندوقدار' } },
  appointments: { label: 'نوبت‌ها', columns: { patientName: 'بیمار', patientMobile: 'شماره همراه', doctorName: 'پزشک', serviceName: 'خدمت', date: 'تاریخ', time: 'ساعت', status: 'وضعیت' } },
  visitQueue: { label: 'پذیرش و صف مراجعه', columns: { patientName: 'بیمار', patientMobile: 'شماره همراه', doctorName: 'پزشک', serviceName: 'خدمت', jalaliDate: 'تاریخ', turnNumber: 'شماره نوبت', status: 'وضعیت' } },
  products: { label: 'کالا و موجودی', columns: { code: 'کد کالا', name: 'نام', categoryName: 'دسته', stockQuantity: 'موجودی', minStock: 'حداقل موجودی', purchasePrice: 'قیمت خرید', salesPrice: 'قیمت فروش', activeLabel: 'وضعیت' } },
  expenses: { label: 'هزینه‌ها', columns: { title: 'عنوان', category: 'دسته', amount: 'مبلغ', jalaliDate: 'تاریخ', paymentMethod: 'روش پرداخت', description: 'شرح', createdByUserName: 'ثبت‌کننده' } },
  purchaseInvoices: { label: 'فاکتورهای خرید', columns: { invoiceNumber: 'شماره', supplierName: 'تأمین‌کننده', jalaliDate: 'تاریخ', totalAmount: 'مبلغ کل', createdByUserName: 'ثبت‌کننده', status: 'وضعیت' } },
};

const patientIndex = (patients = []) => new Map(patients.map((p) => [p.id, p]));
const compact = (value) => value === null || value === undefined ? '' : value;

function buildRows(source, state) {
  const patients = patientIndex(state.patients || []);
  const invoices = state.salesInvoices || [];
  if (source === 'patients') return (state.patients || []).map((p) => ({ ...p, currentDebt: p.creditConfig?.currentDebt || 0 }));
  if (source === 'invoices') return invoices.map((inv) => ({ ...inv, paymentMethodLabel: inv.payments?.[0]?.methodLabel || ({ card: 'PC-POS', cash: 'نقدی', credit: 'اعتباری', split: 'ترکیبی' }[inv.paymentMethod] || inv.paymentMethod) }));
  if (source === 'payments') return invoices.flatMap((inv) => (inv.payments || []).map((pay) => ({ invoiceNumber: inv.invoiceNumber, patientName: inv.patientName, cashier: inv.createdByUserName, methodLabel: pay.methodLabel || ({ card: 'PC-POS', cash: 'نقدی', credit: 'اعتباری' }[pay.method] || pay.method), amount: pay.amount, transactionNumber: pay.transactionNumber || pay.posReferenceCode || '', transactionDate: pay.transactionDate || pay.jalaliDate || inv.jalaliDate, transactionTime: pay.transactionTime || '', bankName: pay.bankName || '', terminalNumber: pay.terminalNumber || pay.posTerminalName || '' })));
  if (source === 'serviceRecipients') {
    const patientFields = (row) => { const patient = patients.get(row.patientId); return { patientName: row.patientName || patient?.fullName || '', patientMobile: row.patientMobile || patient?.mobilePhone || '', patientNationalId: row.patientNationalId || patient?.nationalId || '' }; };
    const invoiceRows = invoices.flatMap((inv) => (inv.items || []).map((item) => ({ ...patientFields(inv), serviceName: item.serviceName || item.productName || item.name || '', quantity: item.qty || item.quantity || 1, amount: item.totalPrice || item.amount || item.unitPrice || 0, date: inv.jalaliDate || inv.date, doctorName: item.doctorName || inv.doctorName || '', invoiceNumber: inv.invoiceNumber, status: inv.status })));
    const queueRows = (state.visitQueue || []).map((row) => ({ ...patientFields(row), serviceName: row.serviceName || row.serviceTitle || row.medicalServiceName || '', quantity: 1, amount: row.amount || row.tariffPrice || 0, date: row.jalaliDate || row.date, doctorName: row.doctorName || '', invoiceNumber: row.invoiceNumber || '', status: row.status || '' }));
    const appointmentRows = (state.appointments || []).map((row) => ({ ...patientFields(row), serviceName: row.serviceName || row.serviceTitle || row.title || '', quantity: 1, amount: row.amount || 0, date: row.jalaliDate || row.date, doctorName: row.doctorName || '', invoiceNumber: row.invoiceNumber || '', status: row.status || '' }));
    const planRows = (state.treatmentPlans || []).flatMap((plan) => { const items = plan.services || plan.items || [plan]; return items.map((item) => ({ ...patientFields(plan), serviceName: item.serviceName || item.serviceTitle || item.title || plan.title || '', quantity: item.quantity || 1, amount: item.amount || item.price || 0, date: item.jalaliDate || plan.jalaliDate || plan.date, doctorName: item.doctorName || plan.doctorName || '', invoiceNumber: plan.invoiceNumber || '', status: item.status || plan.status || '' })); });
    return [...invoiceRows, ...queueRows, ...appointmentRows, ...planRows].filter((row) => row.serviceName);
  }
  if (source === 'appointments') return (state.appointments || []).map((row) => { const patient = patients.get(row.patientId); return { ...row, patientName: row.patientName || patient?.fullName || '', patientMobile: row.patientMobile || patient?.mobilePhone || '' }; });
  if (source === 'visitQueue') return (state.visitQueue || []).map((row) => { const patient = patients.get(row.patientId); return { ...row, patientName: row.patientName || patient?.fullName || '', patientMobile: row.patientMobile || patient?.mobilePhone || '' }; });
  if (source === 'products') return (state.products || []).map((p) => ({ ...p, activeLabel: p.active === false ? 'غیرفعال' : 'فعال' }));
  if (source === 'expenses') return state.expenseRecords || state.expenses || [];
  if (source === 'purchaseInvoices') return state.purchaseInvoices || [];
  return [];
}

function matches(row, filter) {
  const actual = String(compact(row[filter.field])).toLocaleLowerCase('fa');
  const expected = String(compact(filter.value)).toLocaleLowerCase('fa');
  if (!filter.field) return true;
  if (filter.operator === 'contains') return actual.includes(expected);
  if (filter.operator === 'not_contains') return !actual.includes(expected);
  if (filter.operator === 'equals') return actual === expected;
  if (filter.operator === 'not_equals') return actual !== expected;
  if (filter.operator === 'starts') return actual.startsWith(expected);
  if (filter.operator === 'greater') return Number(row[filter.field]) > Number(filter.value);
  if (filter.operator === 'less') return Number(row[filter.field]) < Number(filter.value);
  if (filter.operator === 'empty') return !actual;
  if (filter.operator === 'not_empty') return Boolean(actual);
  return true;
}

const emptyDefinition = () => ({ id: '', name: '', description: '', source: 'serviceRecipients', columns: ['patientName', 'patientMobile', 'serviceName', 'date'], filters: [{ field: 'serviceName', operator: 'contains', value: '' }] });

export function CustomReportBuilder({ state = {}, savedReports = [], onSaveReports, currentUser }) {
  const [definition, setDefinition] = useState(emptyDefinition);
  const [showBuilder, setShowBuilder] = useState(savedReports.length === 0);
  const sourceConfig = SOURCES[definition.source];
  const allRows = useMemo(() => buildRows(definition.source, state), [definition.source, state]);
  const filteredRows = useMemo(() => allRows.filter((row) => definition.filters.every((filter) => matches(row, filter))), [allRows, definition.filters]);
  const displayedRows = filteredRows.slice(0, 100);

  const setSource = (source) => setDefinition({ ...definition, source, columns: Object.keys(SOURCES[source].columns).slice(0, 5), filters: [{ field: Object.keys(SOURCES[source].columns)[0], operator: 'contains', value: '' }] });
  const toggleColumn = (key) => setDefinition({ ...definition, columns: definition.columns.includes(key) ? definition.columns.filter((item) => item !== key) : [...definition.columns, key] });
  const updateFilter = (index, patch) => setDefinition({ ...definition, filters: definition.filters.map((filter, i) => i === index ? { ...filter, ...patch } : filter) });
  const addFilter = () => setDefinition({ ...definition, filters: [...definition.filters, { field: Object.keys(sourceConfig.columns)[0], operator: 'contains', value: '' }] });
  const removeFilter = (index) => setDefinition({ ...definition, filters: definition.filters.filter((_, i) => i !== index) });
  const saveReport = () => {
    if (!definition.name.trim()) return alert('برای گزارش یک نام مشخص وارد کنید.');
    if (definition.columns.length === 0) return alert('حداقل یک ستون را انتخاب کنید.');
    const saved = { ...definition, id: definition.id || `report-${Date.now()}`, name: definition.name.trim(), updatedAt: new Date().toISOString(), updatedBy: currentUser?.name || 'مدیر سیستم' };
    const next = definition.id ? savedReports.map((item) => item.id === definition.id ? saved : item) : [saved, ...savedReports];
    onSaveReports(next);
    setDefinition(saved);
    setShowBuilder(false);
  };
  const runSaved = (report) => { setDefinition({ ...report }); setShowBuilder(false); };
  const editSaved = (report) => { setDefinition({ ...report }); setShowBuilder(true); };
  const deleteSaved = (id) => { if (confirm('این گزارش ذخیره‌شده حذف شود؟')) onSaveReports(savedReports.filter((item) => item.id !== id)); };
  const exportRows = () => exportDataToExcel(filteredRows.map((row) => Object.fromEntries(definition.columns.map((key) => [sourceConfig.columns[key], compact(row[key])]))), definition.name || 'گزارش_سفارشی', 'گزارش');
  const createBotoxTemplate = () => { setDefinition({ id: '', name: 'شماره همراه بیماران تزریق بوتاکس', description: 'فهرست بیماران دارای خدمت تزریق بوتاکس به همراه شماره همراه', source: 'serviceRecipients', columns: ['patientName', 'patientMobile', 'patientNationalId', 'serviceName', 'date', 'doctorName'], filters: [{ field: 'serviceName', operator: 'contains', value: 'بوتاکس' }] }); setShowBuilder(true); };

  return (
    <div className="space-y-5">
      <div className="bg-gradient-to-l from-teal-950/50 to-slate-900 border border-teal-800/40 rounded-2xl p-5 flex flex-col md:flex-row gap-3 md:items-center justify-between">
        <div><h2 className="font-black text-slate-100">گزارش‌ساز حرفه‌ای باستیان</h2><p className="text-xs text-slate-400 mt-1">منبع، ستون‌ها و فیلترها را انتخاب کنید؛ گزارش را در پنل ذخیره و هر زمان اجرا یا به Excel صادر کنید.</p></div>
        <div className="flex flex-wrap gap-2"><button onClick={createBotoxTemplate} className="bg-slate-800 hover:bg-slate-700 text-teal-300 text-xs px-3 py-2 rounded-xl">نمونه آماده: بیماران بوتاکس</button><button onClick={() => { setDefinition(emptyDefinition()); setShowBuilder(true); }} className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-3 py-2 rounded-xl flex items-center gap-1"><FilePlus2 className="w-4 h-4" /> گزارش جدید</button></div>
      </div>

      {savedReports.length > 0 && <div><h3 className="text-xs font-bold text-slate-300 mb-2">گزارش‌های افزوده‌شده به پنل من</h3><div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">{savedReports.map((report) => <div key={report.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3"><div><div className="font-bold text-slate-100 text-sm">{report.name}</div><div className="text-[11px] text-slate-500 mt-1">{SOURCES[report.source]?.label} · {report.columns.length} ستون</div></div><div className="flex gap-2"><button onClick={() => runSaved(report)} className="flex-1 bg-teal-600 hover:bg-teal-500 text-white text-xs py-2 rounded-lg flex justify-center gap-1"><Play className="w-3.5 h-3.5" /> اجرا</button><button onClick={() => editSaved(report)} className="bg-slate-800 text-slate-300 text-xs px-3 rounded-lg">ویرایش</button><button onClick={() => deleteSaved(report.id)} className="bg-rose-950/50 text-rose-400 px-2 rounded-lg"><Trash2 className="w-4 h-4" /></button></div></div>)}</div></div>}

      {showBuilder && <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3"><div><label className="text-[11px] text-slate-400">نام گزارش *</label><input className="w-full bg-slate-950 border border-slate-700 text-slate-100 text-xs px-3 py-2.5 rounded-xl" value={definition.name} onChange={(e) => setDefinition({ ...definition, name: e.target.value })} /></div><div className="md:col-span-2"><label className="text-[11px] text-slate-400">منبع داده</label><select className="w-full bg-slate-950 border border-slate-700 text-slate-100 text-xs px-3 py-2.5 rounded-xl" value={definition.source} onChange={(e) => setSource(e.target.value)}>{Object.entries(SOURCES).map(([key, config]) => <option key={key} value={key}>{config.label}</option>)}</select></div></div>
        <div><div className="text-xs font-bold text-slate-300 mb-2">ستون‌های خروجی</div><div className="flex flex-wrap gap-2">{Object.entries(sourceConfig.columns).map(([key, label]) => <label key={key} className={`px-3 py-2 rounded-xl border text-xs cursor-pointer ${definition.columns.includes(key) ? 'bg-emerald-500/15 border-emerald-500 text-emerald-300' : 'bg-slate-950 border-slate-700 text-slate-400'}`}><input type="checkbox" className="hidden" checked={definition.columns.includes(key)} onChange={() => toggleColumn(key)} />{label}</label>)}</div></div>
        <div><div className="flex justify-between items-center mb-2"><div className="text-xs font-bold text-slate-300 flex gap-1"><Filter className="w-4 h-4" /> فیلترها (همه شروط)</div><button onClick={addFilter} className="text-xs text-teal-300">+ افزودن شرط</button></div><div className="space-y-2">{definition.filters.map((filter, index) => <div key={index} className="grid grid-cols-1 md:grid-cols-[1fr_180px_1fr_40px] gap-2"><select className="bg-slate-950 border border-slate-700 text-slate-200 text-xs px-2 py-2 rounded-lg" value={filter.field} onChange={(e) => updateFilter(index, { field: e.target.value })}>{Object.entries(sourceConfig.columns).map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select><select className="bg-slate-950 border border-slate-700 text-slate-200 text-xs px-2 py-2 rounded-lg" value={filter.operator} onChange={(e) => updateFilter(index, { operator: e.target.value })}><option value="contains">شامل باشد</option><option value="not_contains">شامل نباشد</option><option value="equals">برابر باشد</option><option value="not_equals">برابر نباشد</option><option value="starts">شروع شود با</option><option value="greater">بزرگ‌تر از</option><option value="less">کوچک‌تر از</option><option value="empty">خالی باشد</option><option value="not_empty">خالی نباشد</option></select><input disabled={['empty', 'not_empty'].includes(filter.operator)} className="bg-slate-950 border border-slate-700 text-slate-200 text-xs px-2 py-2 rounded-lg" value={filter.value} onChange={(e) => updateFilter(index, { value: e.target.value })} /><button onClick={() => removeFilter(index)} className="bg-rose-950/50 text-rose-400 rounded-lg"><Trash2 className="w-4 h-4 mx-auto" /></button></div>)}</div></div>
        <div className="flex flex-wrap justify-end gap-2"><button onClick={() => setShowBuilder(false)} className="bg-slate-800 text-slate-300 px-4 py-2 rounded-xl text-xs">بستن</button><button onClick={saveReport} className="bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-bold flex gap-1"><Save className="w-4 h-4" /> ذخیره و افزودن به پنل</button></div>
      </div>}

      {!showBuilder && definition.name && <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden"><div className="p-4 border-b border-slate-800 flex flex-col sm:flex-row gap-2 justify-between sm:items-center"><div><h3 className="font-bold text-slate-100">{definition.name}</h3><p className="text-[11px] text-slate-400 mt-1">{filteredRows.length.toLocaleString('fa-IR')} رکورد یافت شد؛ پیش‌نمایش حداکثر ۱۰۰ ردیف است.</p></div><button onClick={exportRows} className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 py-2 rounded-xl flex items-center gap-1"><Download className="w-4 h-4" /> خروجی Excel کامل</button></div><div className="overflow-auto max-h-[560px]"><table className="w-full text-xs text-right"><thead className="bg-slate-800 text-slate-300 sticky top-0"><tr>{definition.columns.map((key) => <th key={key} className="p-3 whitespace-nowrap">{sourceConfig.columns[key]}</th>)}</tr></thead><tbody className="divide-y divide-slate-800">{displayedRows.map((row, index) => <tr key={index} className="hover:bg-slate-800/40">{definition.columns.map((key) => <td key={key} className="p-3 text-slate-300 whitespace-nowrap">{String(compact(row[key])) || '—'}</td>)}</tr>)}{displayedRows.length === 0 && <tr><td colSpan={definition.columns.length} className="p-8 text-center text-slate-500">داده‌ای مطابق فیلترهای انتخاب‌شده یافت نشد.</td></tr>}</tbody></table></div></div>}
    </div>
  );
}
