import React from '../../vendor/react.js';
import { MoneyInput450 } from './MoneyInput450.js';
import { PAYMENT_METHOD_LABELS_450 } from '../utils/financeClinical450.js';
const h = React.createElement;

const DEFAULTS = Object.entries(PAYMENT_METHOD_LABELS_450).map(([id, name]) => ({ id, name, enabled: true }));
const codeOf = (item) => String(item?.id ?? item?.code ?? item?.key ?? item?.value ?? '').trim();
const labelOf = (item, code) => String(item?.name ?? item?.title ?? item?.label ?? PAYMENT_METHOD_LABELS_450[code] ?? code);

function normalizedMethods(methods = []) {
  const map = new Map();
  for (const base of DEFAULTS) map.set(base.id, base);
  for (const item of Array.isArray(methods) ? methods : []) {
    const code = codeOf(item); if (!code) continue;
    const enabled = item?.enabled !== false && item?.active !== false && item?.isActive !== false;
    map.set(code, { ...item, id: code, name: labelOf(item, code), enabled });
  }
  return [...map.values()].filter(x => x.enabled !== false);
}

const needsBankFields = method => ['card','standalone_pos','bank_transfer','deposit_receipt','online_gateway','cheque','other'].includes(method);

export function PaymentMethodSelector450({ methods = [], value = 'cash', onChange, details = {}, onDetailsChange, amount = 0, paidAmount = 0, onPaidAmountChange }) {
  const list = normalizedMethods(methods);
  const selected = list.some(x => x.id === value) ? value : (list[0]?.id || 'cash');
  const setDetail = (key, val) => onDetailsChange?.({ ...(details || {}), [key]: val });
  return h('section', { className: 'bhis-payment-selector450', dir: 'rtl' },
    h('div', { className: 'bhis-payment-selector-title450' },
      h('strong', null, 'روش پرداخت'),
      h('small', null, 'روش دریافت در گزارش‌های مالی به‌صورت تفکیکی ثبت می‌شود.')
    ),
    h('div', { className: 'bhis-payment-methods450' },
      ...list.map(item => h('button', {
        key: item.id, type: 'button', className: `bhis-payment-method450 ${selected === item.id ? 'active' : ''}`,
        onClick: () => onChange?.(item.id)
      }, item.name))
    ),
    selected !== 'credit' ? h('div', { className: 'bhis-payment-details450' },
      h('label', { className: 'bhis-field' }, h('span', null, 'مبلغ دریافتی'),
        h(MoneyInput450, { value: paidAmount, onChange: onPaidAmountChange, unit: 'تومان' })),
      needsBankFields(selected) ? h(React.Fragment, null,
        h('label', { className: 'bhis-field' }, h('span', null, selected === 'cheque' ? 'شماره چک / پیگیری' : 'شماره پیگیری / مرجع'),
          h('input', { value: details?.transactionNumber || '', onChange: e => setDetail('transactionNumber', e.target.value), placeholder: 'شماره پیگیری' })),
        h('label', { className: 'bhis-field' }, h('span', null, 'تاریخ تراکنش'),
          h('input', { value: details?.transactionDate || '', onChange: e => setDetail('transactionDate', e.target.value), placeholder: 'مثال: ۱۴۰۵/۰۵/۲۸ یا 2026-08-19', dir: 'ltr' })),
        h('label', { className: 'bhis-field' }, h('span', null, 'ساعت تراکنش'),
          h('input', { type: 'time', value: details?.transactionTime || '', onChange: e => setDetail('transactionTime', e.target.value), dir: 'ltr' }))
      ) : null
    ) : h('div', { className: 'bhis-payment-credit-note450' }, `این مراجعه به‌صورت اعتباری ثبت می‌شود. مانده قابل پرداخت: ${Number(amount || 0).toLocaleString('fa-IR')} تومان`)
  );
}
