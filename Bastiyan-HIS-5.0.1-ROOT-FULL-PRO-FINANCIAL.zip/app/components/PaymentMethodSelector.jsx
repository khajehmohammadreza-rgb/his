import React, { useMemo, useState } from '../../vendor/react.js';
import { Plus, Settings, Trash2, X } from '../../vendor/lucide-react.js';
import { getJalaliDateString } from '../utils/jalali.js';
import { normalizePaymentMethods } from '../utils/paymentMethods.js';

const inputClass = 'w-full bg-slate-950 border border-slate-700 text-slate-100 text-xs px-2.5 py-2 rounded-lg focus:outline-none focus:border-emerald-500';

export function PaymentMethodSelector({
  methods,
  value,
  onChange,
  details,
  onDetailsChange,
  onMethodsChange,
  canManage = false,
  onConnectPcPos,
  posMerchantName,
  amount = 0,
  splitCashAmount = 0,
  splitCardAmount = 0,
  onSplitCashChange,
  onSplitCardChange,
}) {
  const normalized = useMemo(() => normalizePaymentMethods(methods), [methods]);
  const activeMethods = normalized.filter((method) => method.active !== false);
  const selected = normalized.find((method) => method.id === value) || activeMethods[0];
  const [managerOpen, setManagerOpen] = useState(false);
  const [draft, setDraft] = useState({ label: '', kind: 'custom', requiresReference: true, requiresDateTime: true });

  const patchDetails = (patch) => onDetailsChange({ ...details, ...patch });
  const saveMethods = (next) => onMethodsChange?.(next);
  const toggleMethod = (id) => saveMethods(normalized.map((item) => item.id === id ? { ...item, active: item.system && id === 'cash' ? true : !item.active } : item));
  const removeMethod = (id) => saveMethods(normalized.filter((item) => item.id !== id || item.system));
  const addMethod = () => {
    if (!draft.label.trim()) return;
    const id = `custom_${Date.now()}`;
    saveMethods([...normalized, { ...draft, id, label: draft.label.trim(), icon: '💠', active: true, system: false }]);
    setDraft({ label: '', kind: 'custom', requiresReference: true, requiresDateTime: true });
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between gap-2">
        <label className="block text-xs font-semibold text-slate-300">روش پرداخت:</label>
        {canManage && (
          <button type="button" onClick={() => setManagerOpen(true)} className="text-[11px] text-teal-300 hover:text-teal-200 flex items-center gap-1">
            <Settings className="w-3.5 h-3.5" /> مدیریت روش‌ها
          </button>
        )}
      </div>
      <div className="grid grid-cols-2 gap-2 text-xs max-h-44 overflow-y-auto pr-0.5">
        {activeMethods.map((method) => (
          <button
            type="button"
            key={method.id}
            onClick={() => { onChange(method.id); onDetailsChange({ transactionDate: getJalaliDateString(), transactionTime: new Date().toTimeString().slice(0, 5) }); }}
            className={`p-2 rounded-xl border text-right font-medium transition-colors ${value === method.id ? 'bg-emerald-500/15 border-emerald-500 text-emerald-300' : 'bg-slate-800 border-slate-700 text-slate-300'}`}
          >
            <span className="ml-1">{method.icon || '💠'}</span>{method.label}
          </button>
        ))}
      </div>

      {selected?.kind === 'pcpos' && (
        <div className="bg-slate-800/60 p-2.5 rounded-xl border border-slate-700 space-y-2">
          <div className="flex items-center justify-between text-xs"><span className="text-slate-300">دستگاه متصل:</span><span className="font-bold text-teal-400">{posMerchantName || 'PC-POS'}</span></div>
          <button type="button" onClick={onConnectPcPos} className="w-full bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold px-3 py-2 rounded-lg">ارسال مبلغ و دریافت پاسخ معتبر POS</button>
        </div>
      )}

      {selected?.kind === 'split' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-slate-800/60 p-2.5 rounded-xl border border-slate-700">
          <div><label className="text-[10px] text-slate-400">مبلغ نقدی</label><input type="number" min="0" className={inputClass} value={splitCashAmount || ''} onChange={(e) => onSplitCashChange?.(Number(e.target.value) || 0)} /></div>
          <div><label className="text-[10px] text-slate-400">مبلغ PC-POS</label><input type="number" min="0" className={inputClass} value={splitCardAmount || ''} onChange={(e) => onSplitCardChange?.(Number(e.target.value) || 0)} /></div>
          <div className={`sm:col-span-2 text-[11px] ${(splitCashAmount + splitCardAmount) === amount ? 'text-emerald-300' : 'text-amber-300'}`}>جمع پرداخت: {(splitCashAmount + splitCardAmount).toLocaleString('fa-IR')} از {Number(amount).toLocaleString('fa-IR')}</div>
          {splitCardAmount > 0 && <button type="button" onClick={onConnectPcPos} className="sm:col-span-2 bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold px-3 py-2 rounded-lg">ارسال سهم کارت به PC-POS و دریافت پاسخ معتبر</button>}
        </div>
      )}

      {!['cash', 'credit', 'split', 'pcpos'].includes(selected?.kind) && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-slate-800/60 p-2.5 rounded-xl border border-slate-700">
          {selected?.requiresReference !== false && (
            <div className="sm:col-span-2"><label className="text-[10px] text-slate-400">شماره تراکنش / پیگیری *</label><input className={inputClass} value={details.transactionNumber || ''} onChange={(e) => patchDetails({ transactionNumber: e.target.value })} /></div>
          )}
          {selected?.requiresDateTime !== false && <>
            <div><label className="text-[10px] text-slate-400">تاریخ تراکنش *</label><input className={inputClass} value={details.transactionDate || ''} onChange={(e) => patchDetails({ transactionDate: e.target.value })} placeholder="۱۴۰۵/۰۵/۲۰" /></div>
            <div><label className="text-[10px] text-slate-400">ساعت تراکنش *</label><input type="time" className={inputClass} value={details.transactionTime || ''} onChange={(e) => patchDetails({ transactionTime: e.target.value })} /></div>
          </>}
          {['standalone_pos', 'bank_transfer', 'online_gateway', 'cheque'].includes(selected?.kind) && <>
            <div><label className="text-[10px] text-slate-400">بانک / درگاه</label><input className={inputClass} value={details.bankName || ''} onChange={(e) => patchDetails({ bankName: e.target.value })} /></div>
            <div><label className="text-[10px] text-slate-400">شماره پایانه / چک</label><input className={inputClass} value={details.terminalNumber || ''} onChange={(e) => patchDetails({ terminalNumber: e.target.value })} /></div>
          </>}
          {selected?.kind === 'standalone_pos' && <div className="sm:col-span-2"><label className="text-[10px] text-slate-400">چهار رقم آخر کارت (اختیاری)</label><input maxLength="4" className={inputClass} value={details.cardLast4 || ''} onChange={(e) => patchDetails({ cardLast4: e.target.value.replace(/\D/g, '').slice(0, 4) })} /></div>}
          <div className="sm:col-span-2"><label className="text-[10px] text-slate-400">توضیحات</label><input className={inputClass} value={details.notes || ''} onChange={(e) => patchDetails({ notes: e.target.value })} /></div>
        </div>
      )}

      {managerOpen && (
        <div className="fixed inset-0 z-[80] bg-slate-950/85 backdrop-blur-sm p-4 flex items-center justify-center">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl p-5 w-full max-w-2xl max-h-[85vh] overflow-y-auto space-y-4">
            <div className="flex justify-between items-center"><div><h3 className="font-bold text-slate-100">مدیریت روش‌های پرداخت مرکز</h3><p className="text-[11px] text-slate-400 mt-1">روش‌های فعال برای همه صندوق‌های همین مرکز نمایش داده می‌شوند.</p></div><button onClick={() => setManagerOpen(false)}><X className="w-5 h-5 text-slate-400" /></button></div>
            <div className="space-y-2">
              {normalized.map((method) => (
                <div key={method.id} className="flex items-center gap-2 bg-slate-950 border border-slate-800 rounded-xl p-3">
                  <span className="text-lg">{method.icon || '💠'}</span><span className="flex-1 text-xs text-slate-200">{method.label}</span>
                  <label className="flex items-center gap-1 text-[11px] text-slate-400"><input type="checkbox" checked={method.active !== false} disabled={method.id === 'cash'} onChange={() => toggleMethod(method.id)} /> فعال</label>
                  {!method.system && <button onClick={() => removeMethod(method.id)} className="text-rose-400"><Trash2 className="w-4 h-4" /></button>}
                </div>
              ))}
            </div>
            <div className="border-t border-slate-800 pt-4 grid grid-cols-1 sm:grid-cols-3 gap-2">
              <input className={`${inputClass} sm:col-span-2`} placeholder="نام روش جدید؛ مثال: پرداخت سازمانی" value={draft.label} onChange={(e) => setDraft({ ...draft, label: e.target.value })} />
              <button onClick={addMethod} className="bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1"><Plus className="w-4 h-4" /> افزودن روش</button>
              <label className="text-[11px] text-slate-400 flex items-center gap-1"><input type="checkbox" checked={draft.requiresReference} onChange={(e) => setDraft({ ...draft, requiresReference: e.target.checked })} /> نیازمند شماره پیگیری</label>
              <label className="text-[11px] text-slate-400 flex items-center gap-1"><input type="checkbox" checked={draft.requiresDateTime} onChange={(e) => setDraft({ ...draft, requiresDateTime: e.target.checked })} /> نیازمند تاریخ و ساعت</label>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
