import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "../../vendor/react-jsx-runtime.js";
import React, { useState, useEffect } from '../../vendor/react.js';
import { SearchableItemSelector } from './SearchableItemSelector.js';
import { PatientSettlementInvoiceModal } from './PatientSettlementInvoiceModal.js';
import { PatientSmsModal } from './PatientSmsModal.js';
import { SalamatInsuranceModal } from './SalamatInsuranceModal.js';
import { Search, UserPlus, Clock, CheckCircle2, AlertTriangle, Stethoscope, Plus, Trash2, Send, FileText, CreditCard, ShieldCheck, UserCheck, X, Calendar, DollarSign, Coins, Eye, ChevronDown, ChevronUp, Edit3, Package, RotateCcw, Printer, MessageSquare, Sparkles, } from '../../vendor/lucide-react.js';
import { getJalaliDateString, formatCurrency, toPersianDigits, toEnglishDigits, calculateAgeFromJalali, calculateBirthYearFromAge, } from '../utils/jalali.js';
import { queryPatientIdentity } from '../utils/identityApi.js';
import { notificationService } from '../utils/webNotification.js';
// 10-digit National ID Iranian Algorithm check
function isValidIranianNationalId(code) {
    if (!/^\d{10}$/.test(code))
        return false;
    const check = parseInt(code.charAt(9), 10);
    let sum = 0;
    for (let i = 0; i < 9; i++) {
        sum += parseInt(code.charAt(i), 10) * (10 - i);
    }
    const remainder = sum % 11;
    return (remainder < 2 && check === remainder) || (remainder >= 2 && check === 11 - remainder);
}
export const ReceptionQueue = ({ patients = [], visitQueue = [], doctors = [], medicalServices = [], products = [], currentUser, settings, onAddPatient, onUpdatePatient, onAddQueueItem, onUpdateQueueItem, onNavigateToTab, onSettleDebt, onOpenPatientProfile, }) => {
    // Search & Filter state
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedPatient, setSelectedPatient] = useState(null);
    // Registration Modal State
    const [showRegModal, setShowRegModal] = useState(false);
    const [regCategory, setRegCategory] = useState('iranian');
    const [regFirstName, setRegFirstName] = useState('');
    const [regLastName, setRegLastName] = useState('');
    const [regNationalId, setRegNationalId] = useState('');
    const [regPassportNumber, setRegPassportNumber] = useState('');
    const [regMobile, setRegMobile] = useState('');
    const [regFatherName, setRegFatherName] = useState('');
    const [regBirthDate, setRegBirthDate] = useState('');
    const [regAge, setRegAge] = useState('');
    const [regIsApproximateAge, setRegIsApproximateAge] = useState(false);
    const [regGender, setRegGender] = useState('female');
    const [verifyingIdentity, setVerifyingIdentity] = useState(false);
    const [identityVerified, setIdentityVerified] = useState(false);
    const [identityError, setIdentityError] = useState('');
    const [verifiedInsuranceRecord, setVerifiedInsuranceRecord] = useState(null);
    // Visit Creation Form State
    const [selectedDoctorId, setSelectedDoctorId] = useState(doctors[0]?.id || '');
    const [selectedServices, setSelectedServices] = useState([]);
    const [visitNotes, setVisitNotes] = useState('');
    // Queue Status Filter
    const [queueStatusFilter, setQueueStatusFilter] = useState('all');
    // Debt Details & Quick Settlement State
    const [showDebtDetails, setShowDebtDetails] = useState(false);
    const [showQuickSettleModal, setShowQuickSettleModal] = useState(false);
    const [settleAmount, setSettleAmount] = useState(0);
    const [settleMethod, setSettleMethod] = useState('card');
    const [settleRrn, setSettleRrn] = useState('');
    // Universal Visit Edit / Correction Modal State
    const [editingItem, setEditingItem] = useState(null);
    const [editServices, setEditServices] = useState([]);
    const [editDoctorId, setEditDoctorId] = useState('');
    const [editNotes, setEditNotes] = useState('');
    const [editDiagnosis, setEditDiagnosis] = useState('');
    const [editStatus, setEditStatus] = useState('waiting_doctor');
    const [addServiceSelect, setAddServiceSelect] = useState('');
    const [addProductSelect, setAddProductSelect] = useState('');
    const [addProductQty, setAddProductQty] = useState(1);
    // Final Discharge & Settlement Modal State
    const [dischargingItem, setDischargingItem] = useState(null);
    const [dischargePayMethod, setDischargePayMethod] = useState('card');
    const [dischargeRrn, setDischargeRrn] = useState('');
    // Settlement Printable Invoice Modal State
    const [settlementInvoiceItem, setSettlementInvoiceItem] = useState(null);
    // Patient SMS Modal State (Welcome Pattern welcome / ID 1488881 & Invoice SMS)
    const [smsPatientItem, setSmsPatientItem] = useState(null);
    const [sendWelcomeSmsOnQueue, setSendWelcomeSmsOnQueue] = useState(true);
    const [showSalamatModal, setShowSalamatModal] = useState(false);
    const handleSavePatientInsurance = (patientId, insuranceRecord) => {
        const targetPat = patients.find(p => p.id === patientId);
        if (targetPat) {
            const updated = {
                ...targetPat,
                insuranceProvider: 'salamat',
                salamatInsuranceInfo: insuranceRecord,
            };
            onUpdatePatient(updated);
            if (selectedPatient && selectedPatient.id === patientId) {
                setSelectedPatient(updated);
            }
        }
    };
    // Fast Patient Filtering (Starts at >= 2 characters)
    const filteredPatients = searchTerm.trim().length >= 2
        ? patients.filter((p) => {
            const term = searchTerm.toLowerCase().trim();
            return ((p.fullName || '').toLowerCase().includes(term) ||
                (p.fileNumber || '').toLowerCase().includes(term) ||
                (p.nationalId && p.nationalId.includes(term)) ||
                (p.mobilePhone && p.mobilePhone.includes(term)) ||
                (p.passportNumber && p.passportNumber.toLowerCase().includes(term)));
        })
        : [];
    // Welcome SMS Trigger
    const handleSendWelcomeSms = async (patientName, mobile, fileNum, silent = false) => {
        if (!mobile || mobile.length < 11) {
            if (!silent)
                alert('شماره همراه معتبر نیست.');
            return;
        }
        const clinicTitle = settings.clinicName || 'کلینیک تخصصی درمانی';
        const cleanPatientName = patientName.trim().replace(/\s+/g, '-');
        const cleanFileNum = (fileNum || 'ثبت-شده').trim().replace(/\s+/g, '-');
        try {
            // 1. Try pattern HISREGISTER (%token% = patientName, %token2% = fileNumber)
            let res = await fetch('/api/sms/verify', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    mobile,
                    template: 'HISREGISTER',
                    token: cleanPatientName,
                    token2: cleanFileNum,
                }),
            });
            let data = await res.json();
            // 2. Try pattern HISwelcome (%token% = patientName)
            if (!data.success) {
                res = await fetch('/api/sms/verify', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        mobile,
                        template: 'HISwelcome',
                        token: cleanPatientName,
                    }),
                });
                data = await res.json();
            }
            // 3. Fallback to normal SMS send
            if (!data.success) {
                const template = settings.welcomeSmsTemplate || 'مراجعه‌کننده گرامی {patient_name}، به {clinic_name} خوش آمدید.\nشماره پرونده شما: {file_number}.\nبا آرزوی تندرستی.';
                const msg = template
                    .replace(/\{patient_name\}/g, patientName)
                    .replace(/\{file_number\}/g, fileNum || 'ثبت گردید')
                    .replace(/\{clinic_name\}/g, clinicTitle);
                res = await fetch('/api/sms/send', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        mobile,
                        message: msg,
                        sender: settings.smsSenderLine || undefined,
                    }),
                });
                data = await res.json();
            }
            if (data.success) {
                if (!silent)
                    alert(`پیامک خوش‌آمدگویی با موفقیت به شماره ${mobile} ارسال گردید.`);
            }
            else {
                if (!silent)
                    alert(`خطا در ارسال پیامک خوش‌آمدگویی: ${data.message || 'ناموفق'}`);
            }
        }
        catch (err) {
            if (!silent)
                alert(`ارسال پیامک خوش‌آمدگویی با خطا مواجه شد.`);
        }
    };
    // National ID algorithm validation
    const nationalIdValid = regCategory === 'iranian' && regNationalId.length === 10 ? isValidIranianNationalId(regNationalId) : true;
    // Auto-fill real patient details if national ID matches an existing registered patient in clinic records
    useEffect(() => {
        if (regCategory === 'iranian' && regNationalId.length === 10 && isValidIranianNationalId(regNationalId)) {
            const existing = patients.find((p) => p.nationalId === regNationalId);
            if (existing) {
                if (existing.firstName && !regFirstName)
                    setRegFirstName(existing.firstName);
                if (existing.lastName && !regLastName)
                    setRegLastName(existing.lastName);
                if (existing.fatherName && !regFatherName)
                    setRegFatherName(existing.fatherName);
                if (existing.mobilePhone && !regMobile)
                    setRegMobile(existing.mobilePhone);
                if (existing.birthDate && !regBirthDate)
                    setRegBirthDate(existing.birthDate);
                if (existing.age !== undefined && !regAge)
                    setRegAge(String(existing.age));
                if (existing.isApproximateAge !== undefined)
                    setRegIsApproximateAge(existing.isApproximateAge);
                setIdentityVerified(true);
                setIdentityError('');
            }
        }
    }, [regNationalId, regCategory, patients]);
    // Handle Official Identity Verification
    const handleVerifyIdentity = async () => {
        if (regCategory === 'iranian') {
            if (!isValidIranianNationalId(regNationalId)) {
                setIdentityError('کد ملی وارد شده طبق الگوریتم ۱۰ رقمی ثبت احوال معتبر نیست.');
                return;
            }
        }
        if (!settings.enableOnlineIdentityInquiry) {
            setIdentityError('سرویس استعلام آنلاین هویت (ثبت احوال / شاهکار) تا زمان فعال‌سازی درگاه و ثبت کلید سرویس در بخش تنظیمات غیرفعال می‌باشد. لطفاً اطلاعات بیمار را دستی وارد کنید.');
            return;
        }
        setVerifyingIdentity(true);
        setIdentityError('');
        try {
            const res = await queryPatientIdentity({
                nationalId: regNationalId,
                mobilePhone: regMobile,
            });
            setVerifyingIdentity(false);
            if (res.success) {
                setIdentityVerified(true);
                if (res.firstName)
                    setRegFirstName(res.firstName);
                if (res.lastName)
                    setRegLastName(res.lastName);
                if (res.fatherName)
                    setRegFatherName(res.fatherName);
                if (res.insuranceInfo) {
                    setVerifiedInsuranceRecord(res.insuranceInfo);
                    if (res.insuranceInfo.birthDate) {
                        setRegBirthDate(res.insuranceInfo.birthDate);
                        const computedAge = calculateAgeFromJalali(res.insuranceInfo.birthDate);
                        if (computedAge !== undefined)
                            setRegAge(String(computedAge));
                    }
                }
            }
            else {
                setIdentityError(res.message || 'خطا در استعلام هویت از سامانه ثبت احوال / شاهکار.');
            }
        }
        catch (err) {
            setVerifyingIdentity(false);
            setIdentityError('خطای ارتباط با مرکز استعلام هویت.');
        }
    };
    // Submit New Patient
    const handleRegisterPatient = (e) => {
        e.preventDefault();
        // Mandatory National ID and Mobile Phone validations
        if (regCategory === 'iranian') {
            if (!regNationalId.trim()) {
                alert('ورود کد ملی ۱۰ رقمی اجباری است.');
                return;
            }
            if (regNationalId.length !== 10 || !isValidIranianNationalId(regNationalId)) {
                alert('کد ملی وارد شده ۱۰ رقمی و معتبر نیست.');
                return;
            }
            // Check for duplicate national ID
            const cleanNatId = regNationalId.trim();
            const existingPatientWithSameId = patients.find((p) => p.nationalId === cleanNatId);
            if (existingPatientWithSameId) {
                alert(`امکان ثبت وجود ندارد! بیمار دیگری به نام «${existingPatientWithSameId.fullName}» با کد ملی (${toPersianDigits(cleanNatId)}) قبلاً در سیستم ثبت شده است.`);
                return;
            }
        }
        if (!regMobile.trim() || regMobile.length < 11) {
            alert('ورود شماره همراه ۱۱ رقمی برای ثبت پرونده اجباری است.');
            return;
        }
        if (!regFirstName.trim() || !regLastName.trim()) {
            alert('لطفاً نام و نام خانوادگی بیمار را وارد کنید.');
            return;
        }
        const numericAge = regAge ? parseInt(toEnglishDigits(regAge), 10) : calculateAgeFromJalali(regBirthDate);
        const calculatedBirthDate = regIsApproximateAge && numericAge !== undefined && !isNaN(numericAge)
            ? calculateBirthYearFromAge(numericAge)
            : regBirthDate;
        const fileNum = 'CL-' + Math.floor(10000 + Math.random() * 90000);
        const newPat = {
            id: 'pat-' + Date.now(),
            fileNumber: fileNum,
            identityCategory: regCategory,
            nationalId: regCategory === 'iranian' ? regNationalId : undefined,
            passportNumber: regCategory === 'foreign' ? regPassportNumber : undefined,
            mobilePhone: regMobile,
            firstName: regFirstName,
            lastName: regLastName,
            fullName: `${regFirstName} ${regLastName}`,
            fatherName: regFatherName,
            birthDate: calculatedBirthDate.trim() || undefined,
            age: numericAge !== undefined && !isNaN(numericAge) ? numericAge : undefined,
            isApproximateAge: regIsApproximateAge,
            gender: regGender,
            type: 'regular',
            verificationStatus: identityVerified ? 'verified' : 'unverified',
            insuranceProvider: verifiedInsuranceRecord ? 'salamat' : 'none',
            salamatInsuranceInfo: verifiedInsuranceRecord || undefined,
            creditConfig: {
                enabled: true,
                creditLimit: 5000000,
                maturityDays: 30,
                currentDebt: 0,
            },
            createdAt: new Date().toISOString(),
            lastVisitDate: getJalaliDateString(),
        };
        onAddPatient(newPat);
        setSelectedPatient(newPat);
        if (settings.enableWelcomeSmsOnRegistration) {
            handleSendWelcomeSms(newPat.fullName, newPat.mobilePhone, fileNum, true);
        }
        setShowRegModal(false);
        resetRegForm();
    };
    const resetRegForm = () => {
        setRegFirstName('');
        setRegLastName('');
        setRegNationalId('');
        setRegPassportNumber('');
        setRegMobile('');
        setRegFatherName('');
        setRegBirthDate('');
        setRegAge('');
        setRegIsApproximateAge(false);
        setIdentityVerified(false);
        setIdentityError('');
    };
    // Real-time live filtering inside patient specification form
    const modalNatIdQuery = regNationalId.trim();
    const modalFirstNameQuery = regFirstName.trim().toLowerCase();
    const modalLastNameQuery = regLastName.trim().toLowerCase();
    const modalMobileQuery = regMobile.trim();
    const modalPassportQuery = regPassportNumber.trim().toLowerCase();
    const hasModalSearchQuery = modalNatIdQuery.length >= 1 ||
        modalFirstNameQuery.length >= 1 ||
        modalLastNameQuery.length >= 1 ||
        modalMobileQuery.length >= 1 ||
        modalPassportQuery.length >= 1;
    const modalMatchingPatients = hasModalSearchQuery
        ? patients.filter((p) => {
            const pNatId = p.nationalId || '';
            const pFirstName = (p.firstName || '').toLowerCase();
            const pLastName = (p.lastName || '').toLowerCase();
            const pFullName = (p.fullName || '').toLowerCase();
            const pMobile = p.mobilePhone || '';
            const pPassport = (p.passportNumber || '').toLowerCase();
            const matchesNatId = modalNatIdQuery.length >= 1 && pNatId.includes(modalNatIdQuery);
            const matchesFirstName = modalFirstNameQuery.length >= 1 &&
                (pFirstName.includes(modalFirstNameQuery) || pFullName.includes(modalFirstNameQuery));
            const matchesLastName = modalLastNameQuery.length >= 1 &&
                (pLastName.includes(modalLastNameQuery) || pFullName.includes(modalLastNameQuery));
            const matchesMobile = modalMobileQuery.length >= 1 && pMobile.includes(modalMobileQuery);
            const matchesPassport = modalPassportQuery.length >= 1 && pPassport.includes(modalPassportQuery);
            return matchesNatId || matchesFirstName || matchesLastName || matchesMobile || matchesPassport;
        })
        : [];
    // Toggle Service Selection for Visit
    const handleToggleService = (service) => {
        if (selectedServices.some((s) => s.id === service.id)) {
            setSelectedServices(selectedServices.filter((s) => s.id !== service.id));
        }
        else {
            // Check if service is already in active queue for selectedPatient
            if (selectedPatient) {
                const activeQueueForPatient = (visitQueue || []).filter((q) => q.patientId === selectedPatient.id &&
                    q.status !== 'cancelled' &&
                    q.status !== 'completed' &&
                    q.status !== 'discharged');
                for (const activeQ of activeQueueForPatient) {
                    const dupSrv = (activeQ.services || []).find((s) => {
                        if (s.serviceId && s.serviceId === service.id)
                            return true;
                        const t1 = s.title.trim().toLowerCase();
                        const t2 = service.title.trim().toLowerCase();
                        return t1 === t2 || t1.startsWith(t2) || t2.startsWith(t1);
                    });
                    if (dupSrv) {
                        alert(`⚠️ خدمت تکراری:\nخدمت «${service.title}» قبلاً برای بیمار «${selectedPatient.fullName}» در صف نوبت‌دهی (نوبت شماره ${toPersianDigits(activeQ.turnNumber || 1)}) ثبت شده است. امکان انتخاب و ثبت مجدد خدمت تکراری وجود ندارد.`);
                        return;
                    }
                }
            }
            setSelectedServices([...selectedServices, service]);
        }
    };
    // Add Visit to Queue
    const handleCreateVisitQueue = async () => {
        if (!selectedPatient) {
            alert('لطفاً ابتدا یک بیمار را از جستجو انتخاب یا ثبت نام کنید.');
            return;
        }
        const doctor = doctors.find((d) => d.id === selectedDoctorId) || doctors[0];
        // Check if patient already has active queue item with duplicate service or doctor visit
        const activeQueueItemsForPatient = (visitQueue || []).filter((q) => q.patientId === selectedPatient.id &&
            q.status !== 'cancelled' &&
            q.status !== 'completed' &&
            q.status !== 'discharged');
        // 1. Check selected services against active queue for this patient
        if (selectedServices.length > 0) {
            for (const selSrv of selectedServices) {
                for (const activeQ of activeQueueItemsForPatient) {
                    const dupSrv = (activeQ.services || []).find((qs) => {
                        if (qs.serviceId && qs.serviceId === selSrv.id)
                            return true;
                        const t1 = qs.title.trim().toLowerCase();
                        const t2 = selSrv.title.trim().toLowerCase();
                        return t1 === t2 || t1.startsWith(t2) || t2.startsWith(t1);
                    });
                    if (dupSrv) {
                        alert(`⚠️ خدمت تکراری:\nخدمت «${selSrv.title}» قبلاً برای بیمار «${selectedPatient.fullName}» ثبت شده و در صف نوبت‌دهی (نوبت شماره ${toPersianDigits(activeQ.turnNumber || 1)}) قرار دارد.\n\nجهت افزودن یا تغییر تعداد خدمات، نوبت قبلی بیمار را در لیست صف ویرایش فرمایید.`);
                        return;
                    }
                }
            }
        }
        else {
            // 2. If no services selected, check if patient is already queued for doctor visit today
            const activeDoctorVisit = activeQueueItemsForPatient.find((q) => q.doctorId === doctor?.id);
            if (activeDoctorVisit) {
                alert(`⚠️ نوبت تکراری:\nنوبت ویزیت با پزشک «${doctor?.name || ''}» قبلاً برای بیمار «${selectedPatient.fullName}» در صف نوبت‌دهی (نوبت شماره ${toPersianDigits(activeDoctorVisit.turnNumber || 1)}) ثبت شده و فعال است.\n\nامکان ثبت مجدد نوبت تکراری وجود ندارد.`);
                return;
            }
        }
        const totalCost = selectedServices.reduce((sum, s) => sum + s.tariffPrice, 0);
        const queueServices = selectedServices.map((s) => ({
            id: 'qs-' + Date.now() + Math.random().toString(36).substring(2, 5),
            title: s.title,
            category: s.category,
            price: s.tariffPrice,
            status: 'pending',
            serviceId: s.id,
            quantity: 1,
            unitPrice: s.tariffPrice,
        }));
        const existingTurns = (visitQueue || []).map((q) => q.turnNumber || 0);
        const maxTurn = existingTurns.length > 0 ? Math.max(...existingTurns) : 0;
        const newTurnNumber = maxTurn > 0 ? maxTurn + 1 : (visitQueue || []).length + 1;
        const newQueueItem = {
            id: 'q-' + Date.now(),
            turnNumber: newTurnNumber,
            patientId: selectedPatient.id,
            patientName: selectedPatient.fullName,
            patientCode: selectedPatient.fileNumber,
            nationalId: selectedPatient.nationalId,
            mobilePhone: selectedPatient.mobilePhone,
            doctorId: doctor?.id,
            doctorName: doctor?.name,
            department: doctor?.specialty || 'درمانگاه تخصصی',
            status: 'waiting_doctor',
            registeredAt: new Date().toISOString(),
            jalaliTime: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
            services: queueServices,
            doctorNotes: visitNotes,
            totalCost,
            paidAmount: 0,
            remainingDebt: totalCost,
        };
        onAddQueueItem(newQueueItem);
        // Web Notification Alert for Admin/Doctor
        notificationService.notify('بیمار جدید در صف پذیرش', `بیمار ${selectedPatient.fullName} با نوبت شماره ${toPersianDigits(newTurnNumber)} جهت ویزیت ${doctor?.name || ''} پذیرش شد.`, 'patient', 'reception');
        // Auto-send Welcome SMS if toggle is active
        let smsSentOk = false;
        if (sendWelcomeSmsOnQueue && selectedPatient.mobilePhone && selectedPatient.mobilePhone.length >= 10) {
            try {
                const tokenVal = selectedPatient.fullName.trim().replace(/\s+/g, '-');
                const token2Val = (settings.clinicName || 'مرکز-درمانی').trim().replace(/\s+/g, '-');
                let res = await fetch('/api/sms/verify', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        mobile: selectedPatient.mobilePhone,
                        template: 'welcome',
                        token: tokenVal,
                        token2: token2Val,
                    }),
                });
                let data = await res.json();
                if (!data.success) {
                    res = await fetch('/api/sms/verify', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            mobile: selectedPatient.mobilePhone,
                            template: '1488881',
                            token: tokenVal,
                            token2: token2Val,
                        }),
                    });
                    data = await res.json();
                }
                if (!data.success) {
                    const fallbackText = `بیمار گرامی ${selectedPatient.fullName}، به ${settings.clinicName || 'مرکز درمانی'} خوش آمدید. پذیرش شما با موفقیت ثبت گردید.`;
                    res = await fetch('/api/sms/send', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            mobile: selectedPatient.mobilePhone,
                            message: fallbackText,
                            sender: settings.smsSenderLine || undefined,
                        }),
                    });
                    data = await res.json();
                }
                if (data.success) {
                    smsSentOk = true;
                }
            }
            catch (err) {
                console.error('Welcome SMS Auto Error:', err);
            }
        }
        setSelectedPatient(null);
        setSelectedServices([]);
        setVisitNotes('');
        let msg = `نوبت بیمار ${selectedPatient.fullName} با موفقیت در صف ویزیت ${doctor?.name || ''} ثبت گردید.`;
        if (sendWelcomeSmsOnQueue) {
            if (smsSentOk) {
                msg += '\n\n✅ پیامک خوش‌آمدگویی (پاترن welcome - کد ۱۴۸۸۸۸۱) با موفقیت ارسال شد.';
            }
            else {
                msg += '\n\n⚠️ پیامک خوش‌آمدگویی ارسال نشد (لطفاً شماره همراه یا تنظیمات سامانه کاوه‌نگار را بررسی کنید).';
            }
        }
        alert(msg);
    };
    // Queue Item Status Update
    const handleUpdateStatus = (item, newStatus) => {
        const updated = { ...item, status: newStatus };
        onUpdateQueueItem(updated);
    };
    // Open Edit Modal for a visit (Secretary/Doctor/Nurse modification)
    const handleOpenEditModal = (item) => {
        setEditingItem(item);
        setEditServices([...item.services]);
        setEditDoctorId(item.doctorId || (doctors[0]?.id || ''));
        setEditNotes(item.doctorNotes || '');
        setEditDiagnosis(item.diagnosis || '');
        setEditStatus(item.status);
        setAddServiceSelect('');
        setAddProductSelect('');
        setAddProductQty(1);
    };
    // Searchable Mappers for Reception Queue Edit Modal
    const searchableServicesForEdit = medicalServices.map((s) => ({
        id: s.id,
        title: s.title,
        price: s.tariffPrice ?? s.price ?? 0,
        code: s.code,
        category: s.category,
        originalData: s,
    }));
    const searchableProductsForEdit = products.map((p) => ({
        id: p.id,
        title: p.name,
        price: p.salesPrice || p.purchasePrice || p.price || 0,
        code: p.code,
        unit: p.unit,
        stockQuantity: p.stockQuantity,
        category: p.category,
        originalData: p,
    }));
    const handleAddServiceFromSearchToEdit = (item, qty) => {
        if (editStatus === 'discharged' || editStatus === 'completed') {
            alert('این بیمار ترخیص شده است. جهت افزودن خدمت، ابتدا بیمار را از حالت ترخیص بازگردانی کنید.');
            return;
        }
        const srv = item.originalData;
        const srvTitle = srv ? srv.title : item.title;
        // Duplicate Medical Service Check
        const isDuplicate = editServices.some((s) => {
            if (srv && s.serviceId === srv.id)
                return true;
            const t1 = s.title.trim().toLowerCase();
            const t2 = srvTitle.trim().toLowerCase();
            return t1 === t2 || t1.startsWith(t2) || t2.startsWith(t1);
        });
        if (isDuplicate) {
            alert(`⚠️ خدمت تکراری:\nخدمت «${srvTitle}» قبلاً برای این بیمار ثبت شده است. امکان ثبت مجدد خدمت تکراری وجود ندارد.`);
            return;
        }
        const srvPrice = srv ? (srv.tariffPrice ?? srv.price ?? 0) : item.price;
        const qtyVal = Math.max(1, qty);
        const newItem = {
            id: `srv_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
            title: qtyVal > 1 ? `${srvTitle} (${toPersianDigits(qtyVal)} بار)` : srvTitle,
            category: srv?.category || item.category || 'خدمات پزشکی',
            price: srvPrice * qtyVal,
            status: 'pending',
            serviceId: srv?.id,
            quantity: qtyVal,
            unitPrice: srvPrice,
        };
        setEditServices((prev) => [...prev, newItem]);
    };
    const handleAddProductFromSearchToEdit = (item, qty) => {
        if (editStatus === 'discharged' || editStatus === 'completed') {
            alert('این بیمار ترخیص شده است. جهت افزودن وسایل مصرفی، ابتدا بیمار را از حالت ترخیص بازگردانی کنید.');
            return;
        }
        const prod = item.originalData;
        const prodName = prod ? prod.name : item.title;
        // Duplicate Consumable Item Check
        const isDuplicate = editServices.some((s) => {
            if (prod && s.productId === prod.id)
                return true;
            const t1 = s.title.trim().toLowerCase();
            const p1 = prodName.trim().toLowerCase();
            return t1.includes(p1) || p1.includes(t1);
        });
        if (isDuplicate) {
            alert(`⚠️ کالا قبلاً ثبت شده است:\nکالای «${prodName}» قبلاً برای این بیمار ثبت شده است. جهت افزایش تعداد، در قسمت «لیست خدمات و تجهیزات مصرفی ثبت‌شده» اقدام فرمایید.`);
            return;
        }
        const unitPrice = prod ? (prod.salesPrice || prod.purchasePrice || prod.price || 0) : item.price;
        const qtyVal = Math.max(1, qty);
        const unitStr = prod?.unit || item.unit || 'عدد';
        const newItem = {
            id: `prod_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
            title: `${prodName} (${toPersianDigits(qtyVal)} ${unitStr}) [مصرفی]`,
            category: 'تجهیزات مصرفی',
            price: unitPrice * qtyVal,
            status: 'completed',
            productId: prod?.id,
            quantity: qtyVal,
            unitPrice,
            unit: unitStr,
        };
        setEditServices((prev) => [...prev, newItem]);
    };
    // Add a medical service to Edit Modal via dropdown
    const handleAddServiceToEdit = () => {
        if (editStatus === 'discharged' || editStatus === 'completed') {
            alert('این بیمار ترخیص شده است. جهت افزودن خدمت، ابتدا بیمار را از حالت ترخیص بازگردانی کنید.');
            return;
        }
        if (!addServiceSelect)
            return;
        const srv = medicalServices.find((s) => s.id === addServiceSelect);
        if (srv) {
            const isDuplicate = editServices.some((s) => {
                if (s.serviceId === srv.id)
                    return true;
                const t1 = s.title.trim().toLowerCase();
                const t2 = srv.title.trim().toLowerCase();
                return t1 === t2 || t1.startsWith(t2) || t2.startsWith(t1);
            });
            if (isDuplicate) {
                alert(`⚠️ خدمت تکراری:\nخدمت «${srv.title}» قبلاً برای این بیمار ثبت شده است. امکان ثبت مجدد آن به صورت تکراری وجود ندارد.`);
                return;
            }
            const srvPrice = srv.tariffPrice ?? srv.price ?? 0;
            const newItem = {
                id: `srv_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
                title: srv.title,
                category: srv.category,
                price: srvPrice,
                status: 'pending',
                serviceId: srv.id,
                quantity: 1,
                unitPrice: srvPrice,
            };
            setEditServices((prev) => [...prev, newItem]);
            setAddServiceSelect('');
        }
    };
    // Add a consumable product/supply from inventory to Edit Modal via dropdown
    const handleAddProductToEdit = () => {
        if (editStatus === 'discharged' || editStatus === 'completed') {
            alert('این بیمار ترخیص شده است. جهت افزودن وسایل مصرفی، ابتدا بیمار را از حالت ترخیص بازگردانی کنید.');
            return;
        }
        if (!addProductSelect)
            return;
        const prod = products.find((p) => p.id === addProductSelect);
        if (prod) {
            const isDuplicate = editServices.some((s) => {
                if (s.productId === prod.id)
                    return true;
                const t1 = s.title.trim().toLowerCase();
                const p1 = prod.name.trim().toLowerCase();
                return t1.includes(p1) || p1.includes(t1);
            });
            if (isDuplicate) {
                alert(`⚠️ کالا قبلاً ثبت شده است:\nکالای «${prod.name}» قبلاً برای این بیمار ثبت شده است. جهت افزایش تعداد، در قسمت «لیست خدمات و تجهیزات مصرفی ثبت‌شده» اقدام فرمایید.`);
                return;
            }
            const qtyVal = Math.max(1, addProductQty);
            const unitPrice = prod.price || prod.salesPrice || prod.purchasePrice || 0;
            const totalPrice = unitPrice * qtyVal;
            const newItem = {
                id: `prod_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
                title: `${prod.name} (${toPersianDigits(qtyVal)} ${prod.unit || 'عدد'}) [اتاق عمل]`,
                category: 'تجهیزات مصرفی اتاق عمل',
                price: totalPrice,
                status: 'completed',
                productId: prod.id,
                quantity: qtyVal,
                unitPrice,
                unit: prod.unit || 'عدد',
            };
            setEditServices((prev) => [...prev, newItem]);
            setAddProductSelect('');
            setAddProductQty(1);
        }
    };
    // Increase Quantity of Registered Item in Edit Modal
    const handleIncreaseServiceQty = (id) => {
        if (editStatus === 'discharged' || editStatus === 'completed') {
            alert('این بیمار ترخیص شده است.');
            return;
        }
        setEditServices((prev) => prev.map((item) => {
            if (item.id !== id)
                return item;
            const currentQty = item.quantity || 1;
            const newQty = currentQty + 1;
            const unitPrice = item.unitPrice || (item.price / currentQty);
            const newPrice = unitPrice * newQty;
            let newTitle = item.title;
            if (item.productId) {
                const pName = item.title.split('(')[0].trim();
                const unitStr = item.unit || 'عدد';
                const tag = item.title.includes('[اتاق عمل]') ? ' [اتاق عمل]' : ' [مصرفی]';
                newTitle = `${pName} (${toPersianDigits(newQty)} ${unitStr})${tag}`;
            }
            else if (item.serviceId || item.title.includes('(')) {
                const sName = item.title.split('(')[0].trim();
                const suffix = item.title.includes(']') ? ` [${item.title.split('[').pop()}` : '';
                newTitle = `${sName} (${toPersianDigits(newQty)} بار)${suffix}`;
            }
            return {
                ...item,
                quantity: newQty,
                unitPrice,
                price: newPrice,
                title: newTitle,
            };
        }));
    };
    // Decrease Quantity of Registered Item in Edit Modal
    const handleDecreaseServiceQty = (id) => {
        if (editStatus === 'discharged' || editStatus === 'completed') {
            alert('این بیمار ترخیص شده است.');
            return;
        }
        setEditServices((prev) => prev.map((item) => {
            if (item.id !== id)
                return item;
            const currentQty = item.quantity || 1;
            if (currentQty <= 1)
                return item;
            const newQty = currentQty - 1;
            const unitPrice = item.unitPrice || (item.price / currentQty);
            const newPrice = unitPrice * newQty;
            let newTitle = item.title;
            if (item.productId) {
                const pName = item.title.split('(')[0].trim();
                const unitStr = item.unit || 'عدد';
                const tag = item.title.includes('[اتاق عمل]') ? ' [اتاق عمل]' : ' [مصرفی]';
                newTitle = `${pName} (${toPersianDigits(newQty)} ${unitStr})${tag}`;
            }
            else if (item.serviceId || item.title.includes('(')) {
                const sName = item.title.split('(')[0].trim();
                const suffix = item.title.includes(']') ? ` [${item.title.split('[').pop()}` : '';
                newTitle = newQty === 1 ? `${sName}${suffix}` : `${sName} (${toPersianDigits(newQty)} بار)${suffix}`;
            }
            return {
                ...item,
                quantity: newQty,
                unitPrice,
                price: newPrice,
                title: newTitle,
            };
        }));
    };
    // Remove item from Edit Modal
    const handleRemoveServiceFromEdit = (id) => {
        if (editStatus === 'discharged' || editStatus === 'completed') {
            alert('این بیمار ترخیص شده است. جهت حذف خدمت، ابتدا بیمار را از حالت ترخیص بازگردانی کنید.');
            return;
        }
        setEditServices((prev) => prev.filter((s) => s.id !== id));
    };
    // Save Visit Modifications & Recalculate Debtor / Creditor status
    const handleSaveVisitEdits = () => {
        if (!editingItem)
            return;
        if (editStatus === 'discharged' || editStatus === 'completed') {
            alert('ثبت خدمات جدید یا حذف خدمات برای بیمار ترخیص شده امکان‌پذیر نیست. لطفا وضعیت را به «جاهای دیگر» یا «آماده ترخیص» تغییر دهید تا بازگردانی از ترخیص انجام شود.');
            return;
        }
        const doc = doctors.find((d) => d.id === editDoctorId);
        const newTotal = editServices.reduce((acc, s) => acc + (s.price ?? s.tariffPrice ?? 0), 0);
        const paid = editingItem.paidAmount || 0;
        const newRemainingDebt = newTotal - paid; // positive = debtor, negative = creditor
        const updatedItem = {
            ...editingItem,
            doctorId: editDoctorId,
            doctorName: doc ? doc.name : editingItem.doctorName,
            services: editServices,
            totalCost: newTotal,
            remainingDebt: newRemainingDebt,
            doctorNotes: editNotes,
            diagnosis: editDiagnosis,
            status: editStatus,
        };
        onUpdateQueueItem(updatedItem);
        // Sync master patient record credit balance
        const targetPat = patients.find((p) => p.id === editingItem.patientId);
        if (targetPat) {
            const updatedPat = {
                ...targetPat,
                creditConfig: {
                    ...targetPat.creditConfig,
                    currentDebt: newRemainingDebt,
                },
            };
            onUpdatePatient(updatedPat);
        }
        setEditingItem(null);
        if (newRemainingDebt > 0) {
            alert(`اصلاحات پرونده با موفقیت ذخیره شد.\nبیمار به مبلغ ${newRemainingDebt.toLocaleString('fa-IR')} تومان بدهکار گردید.`);
        }
        else if (newRemainingDebt < 0) {
            alert(`اصلاحات پرونده با موفقیت ذخیره شد.\nبیمار به مبلغ ${Math.abs(newRemainingDebt).toLocaleString('fa-IR')} تومان بستانکار گردید.`);
        }
        else {
            alert(`اصلاحات پرونده با موفقیت ذخیره شد و حساب بیمار به صورت کامل تسویه گردید.`);
        }
    };
    // Revert Discharge (بازگردانی از ترخیص جهت بازگشایی امکان ویرایش خدمات)
    const handleRevertDischarge = (item) => {
        if (confirm(`آیا از بازگردانی بیمار «${item.patientName}» از ترخیص اطمینان دارید؟\n\nبا بازگردانی بیمار به صف پذیرش/صندوق، امکان اضافه نمودن خدمات جدید، حذف خدمات و محاسبه وضعیت بدهکاری/بستانکاری جدید فعال می‌شود.`)) {
            const newRemaining = (item.totalCost || 0) - (item.paidAmount || 0);
            const updated = {
                ...item,
                status: 'ready_for_discharge',
                remainingDebt: newRemaining,
            };
            onUpdateQueueItem(updated);
            const targetPat = patients.find((p) => p.id === item.patientId);
            if (targetPat) {
                const updatedPat = {
                    ...targetPat,
                    creditConfig: {
                        ...targetPat.creditConfig,
                        currentDebt: newRemaining,
                    },
                };
                onUpdatePatient(updatedPat);
            }
            alert(`بیمار ${item.patientName} با موفقیت از حالت ترخیص بازگردانده شد. اکنون می‌توانید خدمات را کم یا زیاد کنید.`);
        }
    };
    // Open Discharge Modal
    const handleOpenDischargeModal = (item) => {
        setDischargingItem(item);
        setDischargePayMethod('card');
        setDischargeRrn('');
    };
    // Complete Final Discharge
    const handleConfirmDischarge = (autoPrintInvoice = true) => {
        if (!dischargingItem)
            return;
        const updated = {
            ...dischargingItem,
            status: 'completed',
            paidAmount: dischargingItem.totalCost,
            remainingDebt: 0,
            paymentMethod: dischargePayMethod,
            posRrn: dischargeRrn || undefined,
        };
        onUpdateQueueItem(updated);
        const targetPat = patients.find((p) => p.id === dischargingItem.patientId);
        if (targetPat) {
            const updatedPat = {
                ...targetPat,
                creditConfig: {
                    ...targetPat.creditConfig,
                    currentDebt: 0,
                },
            };
            onUpdatePatient(updatedPat);
        }
        setDischargingItem(null);
        if (autoPrintInvoice) {
            setSettlementInvoiceItem(updated);
        }
    };
    // Filter queue items by lifecycle stage
    const filteredQueue = visitQueue.filter((q) => {
        if (queueStatusFilter === 'all')
            return true;
        if (queueStatusFilter === 'waiting_doctor')
            return q.status === 'waiting_doctor' || q.status === 'waiting';
        if (queueStatusFilter === 'operating_room')
            return q.status === 'operating_room' || q.status === 'under_treatment';
        if (queueStatusFilter === 'ready_for_discharge')
            return q.status === 'ready_for_discharge' || q.status === 'waiting_payment';
        if (queueStatusFilter === 'completed')
            return q.status === 'completed' || q.status === 'discharged';
        return q.status === queueStatusFilter;
    });
    const getStatusBadge = (status) => {
        switch (status) {
            case 'waiting_doctor':
            case 'waiting':
                return (_jsxs("span", { className: "bg-amber-100 text-amber-900 border border-amber-300 px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1", children: [_jsx(Clock, { className: "w-3.5 h-3.5 text-amber-600" }), " \u06F1. \u067E\u0630\u06CC\u0631\u0634 \u0634\u062F\u0647 (\u0645\u0646\u062A\u0638\u0631 \u067E\u0632\u0634\u06A9/\u0627\u062A\u0627\u0642 \u0639\u0645\u0644)"] }));
            case 'operating_room':
            case 'under_treatment':
                return (_jsxs("span", { className: "bg-purple-100 text-purple-900 border border-purple-300 px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1", children: [_jsx(Stethoscope, { className: "w-3.5 h-3.5 text-purple-600" }), " \u06F2. \u062F\u0631 \u0627\u062A\u0627\u0642 \u0639\u0645\u0644 / \u062C\u0631\u0627\u062D\u06CC"] }));
            case 'ready_for_discharge':
            case 'waiting_payment':
                return (_jsxs("span", { className: "bg-emerald-100 text-emerald-900 border border-emerald-300 px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1", children: [_jsx(CreditCard, { className: "w-3.5 h-3.5 text-emerald-600" }), " \u06F3. \u0622\u0645\u0627\u062F\u0647 \u062A\u0631\u062E\u06CC\u0635 \u062F\u0631 \u0635\u0646\u062F\u0648\u0642"] }));
            case 'discharged':
            case 'completed':
                return (_jsxs("span", { className: "bg-blue-100 text-blue-900 border border-blue-300 px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1", children: [_jsx(ShieldCheck, { className: "w-3.5 h-3.5 text-blue-600" }), " \u062A\u06A9\u0645\u06CC\u0644 \u0648 \u062A\u0631\u062E\u06CC\u0635 \u0646\u0647\u0627\u06CC\u06CC"] }));
            case 'cancelled':
                return (_jsxs("span", { className: "bg-gray-100 text-gray-700 border border-gray-300 px-2.5 py-1 rounded-full text-xs font-medium flex items-center gap-1", children: [_jsx(X, { className: "w-3.5 h-3.5" }), " \u0627\u0646\u0635\u0631\u0627\u0641 / \u0644\u063A\u0648"] }));
            default:
                return _jsx("span", { className: "bg-gray-100 text-gray-800 px-2.5 py-1 rounded-full text-xs font-medium", children: "\u062F\u0631 \u0627\u0646\u062A\u0638\u0627\u0631" });
        }
    };
    return (_jsxs("div", { className: "space-y-6", children: [_jsxs("div", { className: "bg-white rounded-xl shadow-sm border border-slate-200 p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4", children: [_jsxs("div", { className: "flex items-center gap-3", children: [_jsx("div", { className: "p-3 bg-teal-50 border border-teal-200 text-teal-700 rounded-xl", children: _jsx(Stethoscope, { className: "w-6 h-6" }) }), _jsxs("div", { children: [_jsx("h1", { className: "text-xl font-bold text-slate-800", children: "\u067E\u0630\u06CC\u0631\u0634 \u0648 \u0646\u0648\u0628\u062A\u200C\u062F\u0647\u06CC \u0628\u06CC\u0645\u0627\u0631\u0627\u0646 \u062F\u0631\u0645\u0627\u0646\u06AF\u0627\u0647" }), _jsx("p", { className: "text-xs text-slate-500 mt-1", children: "\u062C\u0633\u062A\u062C\u0648\u06CC \u0641\u0648\u0631\u06CC \u067E\u0631\u0648\u0646\u062F\u0647\u060C \u062B\u0628\u062A \u0628\u06CC\u0645\u0627\u0631\u0627\u0646 \u0627\u06CC\u0631\u0627\u0646\u06CC/\u0627\u062A\u0628\u0627\u0639/\u0645\u062C\u0647\u0648\u0644\u060C \u0627\u0633\u062A\u0639\u0644\u0627\u0645 \u0647\u0648\u06CC\u062A \u0648 \u0645\u062F\u06CC\u0631\u06CC\u062A \u0635\u0641 \u0631\u0648\u0632\u0627\u0646\u0647" })] })] }), _jsxs("button", { onClick: () => {
                            resetRegForm();
                            setShowRegModal(true);
                        }, className: "flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white text-sm font-medium px-4 py-2.5 rounded-lg transition shadow-sm min-h-[44px]", children: [_jsx(UserPlus, { className: "w-4 h-4" }), "\u062B\u0628\u062A\u200C\u0646\u0627\u0645 \u0648 \u067E\u0630\u06CC\u0631\u0634 \u0628\u06CC\u0645\u0627\u0631 \u062C\u062F\u06CC\u062F"] })] }), _jsxs("div", { className: "grid grid-cols-1 lg:grid-cols-12 gap-6", children: [_jsxs("div", { className: "lg:col-span-5 space-y-5", children: [_jsxs("div", { className: "bg-white rounded-2xl shadow-sm border border-slate-200 p-5 space-y-4", children: [_jsxs("div", { className: "flex items-center justify-between border-b border-slate-100 pb-3", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("div", { className: "p-2 bg-teal-50 border border-teal-200 rounded-xl text-teal-700", children: _jsx(UserPlus, { className: "w-5 h-5" }) }), _jsxs("div", { children: [_jsx("h2", { className: "text-sm font-bold text-slate-800", children: "\u0645\u0634\u062E\u0635\u0627\u062A \u062E\u0627\u0645 \u0628\u06CC\u0645\u0627\u0631\u060C \u0627\u0633\u062A\u0639\u0644\u0627\u0645 \u0647\u0648\u06CC\u062A \u0648 \u062A\u0634\u06A9\u06CC\u0644 \u067E\u0631\u0648\u0646\u062F\u0647 \u0627\u0644\u06A9\u062A\u0631\u0648\u0646\u06CC\u06A9\u06CC" }), _jsx("p", { className: "text-[11px] text-slate-500", children: "\u062C\u0633\u062A\u062C\u0648\u06CC \u0632\u0646\u062F\u0647\u060C \u0646\u0645\u0627\u06CC\u0634 \u0627\u0633\u0627\u0645\u06CC \u0645\u0634\u0627\u0628\u0647 \u062F\u0631 \u0632\u06CC\u0631 \u0641\u0631\u0645 \u0648 \u0627\u06CC\u062C\u0627\u062F \u067E\u0631\u0648\u0646\u062F\u0647 \u062C\u062F\u06CC\u062F \u062F\u0631 \u06CC\u06A9 \u0641\u0631\u06CC\u0645" })] })] }), _jsx("button", { type: "button", onClick: resetRegForm, className: "text-xs font-semibold text-slate-400 hover:text-slate-600 underline", children: "\u067E\u0627\u06A9\u0633\u0627\u0632\u06CC \u0641\u0631\u0645" })] }), _jsxs("div", { className: "grid grid-cols-3 gap-2 text-xs font-medium", children: [_jsx("button", { type: "button", onClick: () => {
                                                    setRegCategory('iranian');
                                                    setIdentityVerified(false);
                                                }, className: `p-2 rounded-xl border text-center transition ${regCategory === 'iranian'
                                                    ? 'bg-teal-50 border-teal-500 text-teal-800 font-bold'
                                                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'}`, children: "\u0627\u06CC\u0631\u0627\u0646\u06CC (\u06A9\u062F \u0645\u0644\u06CC)" }), _jsx("button", { type: "button", onClick: () => {
                                                    setRegCategory('foreign');
                                                    setIdentityVerified(false);
                                                }, className: `p-2 rounded-xl border text-center transition ${regCategory === 'foreign'
                                                    ? 'bg-teal-50 border-teal-500 text-teal-800 font-bold'
                                                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'}`, children: "\u0627\u062A\u0628\u0627\u0639 \u062E\u0627\u0631\u062C\u06CC" }), _jsx("button", { type: "button", onClick: () => {
                                                    setRegCategory('unknown');
                                                    setIdentityVerified(false);
                                                }, className: `p-2 rounded-xl border text-center transition ${regCategory === 'unknown'
                                                    ? 'bg-teal-50 border-teal-500 text-teal-800 font-bold'
                                                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'}`, children: "\u0645\u062C\u0647\u0648\u0644\u200C\u0627\u0644\u0647\u0648\u06CC\u0647 / \u0627\u0648\u0631\u0698\u0627\u0646\u0633" })] }), _jsxs("div", { className: "space-y-3", children: [_jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs", children: [regCategory === 'iranian' && (_jsxs("div", { children: [_jsxs("div", { className: "flex items-center justify-between mb-1", children: [_jsx("label", { className: "font-bold text-slate-700", children: "\u06A9\u062F \u0645\u0644\u06CC \u06F1\u06F0 \u0631\u0642\u0645\u06CC:" }), _jsx("span", { className: "text-[10px] bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded font-bold", children: "\u0627\u062C\u0628\u0627\u0631\u06CC" })] }), _jsx("input", { type: "text", maxLength: 10, placeholder: "\u0645\u062B\u0644\u0627\u064B \u06F3\u06F5\u06F2\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7", value: regNationalId, onChange: (e) => {
                                                                    setRegNationalId(e.target.value.replace(/\D/g, ''));
                                                                    setIdentityVerified(false);
                                                                }, className: `w-full text-xs border rounded-xl p-2.5 focus:ring-2 dir-ltr text-right font-mono bg-white text-slate-900 font-bold placeholder:text-slate-400 ${regNationalId.length === 10
                                                                    ? isValidIranianNationalId(regNationalId)
                                                                        ? 'border-emerald-500 focus:ring-emerald-500'
                                                                        : 'border-rose-500 focus:ring-rose-500'
                                                                    : 'border-slate-300 focus:ring-teal-500'}` })] })), regCategory === 'foreign' && (_jsxs("div", { children: [_jsxs("div", { className: "flex items-center justify-between mb-1", children: [_jsx("label", { className: "font-bold text-slate-700", children: "\u0634\u0645\u0627\u0631\u0647 \u06AF\u0630\u0631\u0646\u0627\u0645\u0647 / \u0634\u0646\u0627\u0633\u0647:" }), _jsx("span", { className: "text-[10px] bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded font-bold", children: "\u0627\u062C\u0628\u0627\u0631\u06CC" })] }), _jsx("input", { type: "text", placeholder: "\u0645\u062B\u0644\u0627\u064B AFG-889900", value: regPassportNumber, onChange: (e) => setRegPassportNumber(e.target.value), className: "w-full text-xs border border-slate-300 rounded-xl p-2.5 focus:ring-2 focus:ring-teal-500 bg-white text-slate-900 font-bold placeholder:text-slate-400" })] })), _jsxs("div", { children: [_jsxs("div", { className: "flex items-center justify-between mb-1", children: [_jsx("label", { className: "font-bold text-slate-700", children: "\u0634\u0645\u0627\u0631\u0647 \u0647\u0645\u0631\u0627\u0647 (\u06F1\u06F1 \u0631\u0642\u0645\u06CC):" }), _jsx("span", { className: "text-[10px] bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded font-bold", children: "\u0627\u062C\u0628\u0627\u0631\u06CC" })] }), _jsx("input", { type: "text", maxLength: 11, placeholder: "\u06F0\u06F9\u06F1\u06F2\u06F3\u06F2\u06F6\u06F4\u06F6\u06F9\u06F9", value: regMobile, onChange: (e) => setRegMobile(e.target.value.replace(/\D/g, '')), className: "w-full text-xs border border-slate-300 rounded-xl p-2.5 focus:ring-2 focus:ring-teal-500 dir-ltr text-right font-mono bg-white text-slate-900 font-bold placeholder:text-slate-400" })] })] }), _jsxs("div", { className: "grid grid-cols-2 gap-3 text-xs", children: [_jsxs("div", { children: [_jsxs("div", { className: "flex items-center justify-between mb-1", children: [_jsx("label", { className: "font-bold text-slate-700", children: "\u0646\u0627\u0645 \u0628\u06CC\u0645\u0627\u0631:" }), _jsx("span", { className: "text-[10px] bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded font-bold", children: "\u0627\u062C\u0628\u0627\u0631\u06CC" })] }), _jsx("input", { type: "text", placeholder: "\u0645\u0631\u06CC\u0645", value: regFirstName, onChange: (e) => setRegFirstName(e.target.value), className: "w-full text-xs border border-slate-300 rounded-xl p-2.5 focus:ring-2 focus:ring-teal-500 bg-white text-slate-900 font-bold placeholder:text-slate-400" })] }), _jsxs("div", { children: [_jsxs("div", { className: "flex items-center justify-between mb-1", children: [_jsx("label", { className: "font-bold text-slate-700", children: "\u0646\u0627\u0645 \u062E\u0627\u0646\u0648\u0627\u062F\u06AF\u06CC \u0628\u06CC\u0645\u0627\u0631:" }), _jsx("span", { className: "text-[10px] bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded font-bold", children: "\u0627\u062C\u0628\u0627\u0631\u06CC" })] }), _jsx("input", { type: "text", placeholder: "\u0646\u0627\u0645 \u062E\u0627\u0646\u0648\u0627\u062F\u06AF\u06CC", value: regLastName, onChange: (e) => setRegLastName(e.target.value), className: "w-full text-xs border border-slate-300 rounded-xl p-2.5 focus:ring-2 focus:ring-teal-500 bg-white text-slate-900 font-bold placeholder:text-slate-400" })] })] }), _jsxs("div", { className: "grid grid-cols-2 gap-3 text-xs", children: [_jsxs("div", { children: [_jsx("label", { className: "block font-bold text-slate-700 mb-1", children: "\u0646\u0627\u0645 \u067E\u062F\u0631:" }), _jsx("input", { type: "text", placeholder: "\u062D\u0633\u06CC\u0646", value: regFatherName, onChange: (e) => setRegFatherName(e.target.value), className: "w-full text-xs border border-slate-300 rounded-xl p-2.5 focus:ring-2 focus:ring-teal-500 bg-white text-slate-900 font-bold placeholder:text-slate-400" })] }), _jsxs("div", { children: [_jsx("label", { className: "block font-bold text-slate-700 mb-1", children: "\u062C\u0646\u0633\u06CC\u062A:" }), _jsxs("select", { value: regGender, onChange: (e) => setRegGender(e.target.value), className: "w-full text-xs border border-slate-300 rounded-xl p-2.5 focus:ring-2 focus:ring-teal-500 bg-white text-slate-900 font-bold", children: [_jsx("option", { value: "female", children: "\u0632\u0646" }), _jsx("option", { value: "male", children: "\u0645\u0631\u062F" })] })] })] }), regCategory === 'iranian' && (_jsxs("button", { type: "button", onClick: handleVerifyIdentity, disabled: verifyingIdentity || regNationalId.length !== 10, className: "w-full bg-slate-800 hover:bg-slate-900 disabled:bg-slate-300 text-white text-xs font-bold py-2 rounded-xl transition flex items-center justify-center gap-2 shadow-sm", children: [_jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-400" }), verifyingIdentity ? 'درحال استعلام ثبت احوال...' : 'استعلام آنلاین هویت بیمار از ثبت احوال'] })), identityError && (_jsx("div", { className: "p-2.5 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs font-medium", children: identityError })), identityVerified && (_jsxs("div", { className: "p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-medium flex items-center gap-2", children: [_jsx(CheckCircle2, { className: "w-4 h-4 text-emerald-600" }), "\u0647\u0648\u06CC\u062A \u0628\u06CC\u0645\u0627\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0627\u0632 \u062B\u0628\u062A \u0627\u062D\u0648\u0627\u0644 \u0627\u0633\u062A\u0639\u0644\u0627\u0645 \u06AF\u0631\u062F\u06CC\u062F."] })), hasModalSearchQuery && (_jsxs("div", { className: "bg-slate-900 text-slate-100 rounded-xl p-3.5 border border-slate-700 shadow-md space-y-2 mt-2 animate-in fade-in duration-150", children: [_jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-2 gap-1", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Search, { className: "w-4 h-4 text-teal-400 shrink-0" }), _jsxs("span", { className: "text-xs font-bold text-teal-300", children: ["\u0627\u0633\u0627\u0645\u06CC \u0648 \u067E\u0631\u0648\u0646\u062F\u0647\u200C\u0647\u0627\u06CC \u0645\u0634\u0627\u0628\u0647 \u06CC\u0627\u0641\u062A\u200C\u0634\u062F\u0647 (", toPersianDigits(modalMatchingPatients.length), " \u0645\u0648\u0631\u062F)"] })] }), _jsx("span", { className: "text-[10px] text-slate-400", children: "\u0628\u0627 \u0648\u0631\u0648\u062F \u0641\u0627\u0645\u06CC\u0644 \u06CC\u0627 \u06A9\u062F\u0645\u0644\u06CC\u060C \u0646\u062A\u0627\u06CC\u062C \u0628\u0647\u200C\u0635\u0648\u0631\u062A \u0622\u0646\u0644\u0627\u06CC\u0646 \u0632\u06CC\u0631 \u0627\u06CC\u0646 \u0641\u0631\u06CC\u0645 \u0628\u0631\u0648\u0632 \u0645\u06CC\u200C\u0634\u0648\u0646\u062F." })] }), modalMatchingPatients.length > 0 ? (_jsx("div", { className: "max-h-52 overflow-y-auto divide-y divide-slate-800", children: modalMatchingPatients.map((pat) => (_jsxs("div", { className: "py-2.5 px-2 flex items-center justify-between hover:bg-slate-800/80 rounded-lg transition", children: [_jsxs("div", { children: [_jsxs("div", { className: "text-xs font-bold text-white flex items-center gap-2", children: [_jsx("span", { children: pat.fullName }), _jsxs("span", { className: "text-[10px] text-teal-300 bg-teal-950/80 border border-teal-800 px-1.5 py-0.5 rounded", children: ["\u067E\u0631\u0648\u0646\u062F\u0647: ", pat.fileNumber] })] }), _jsxs("div", { className: "text-[11px] text-slate-400 flex items-center gap-3 mt-0.5", children: [pat.nationalId && _jsxs("span", { children: ["\u06A9\u062F \u0645\u0644\u06CC: ", pat.nationalId] }), pat.mobilePhone && _jsxs("span", { children: ["\u0647\u0645\u0631\u0627\u0647: ", pat.mobilePhone] }), pat.fatherName && _jsxs("span", { children: ["\u0646\u0627\u0645 \u067E\u062F\u0631: ", pat.fatherName] })] })] }), _jsxs("button", { type: "button", onClick: () => {
                                                                        setSelectedPatient(pat);
                                                                        resetRegForm();
                                                                    }, className: "bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow transition shrink-0 flex items-center gap-1", children: [_jsx(UserCheck, { className: "w-3.5 h-3.5" }), "\u0627\u0646\u062A\u062E\u0627\u0628 \u0627\u06CC\u0646 \u0628\u06CC\u0645\u0627\u0631"] })] }, pat.id))) })) : (_jsx("div", { className: "text-xs text-amber-300 p-2 text-center font-medium", children: "\u0647\u06CC\u0686 \u0628\u06CC\u0645\u0627\u0631\u06CC \u0628\u0627 \u0645\u0634\u062E\u0635\u0627\u062A \u0645\u0634\u0627\u0628\u0647 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F. \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u06CC\u062F \u0628\u0627 \u062F\u06A9\u0645\u0647 \u0632\u06CC\u0631 \u067E\u0631\u0648\u0646\u062F\u0647 \u062C\u062F\u06CC\u062F \u0631\u0627 \u062B\u0628\u062A \u0641\u0631\u0645\u0627\u06CC\u06CC\u062F." }))] })), _jsxs("button", { type: "button", onClick: (e) => handleRegisterPatient(e), className: "w-full bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold py-3 rounded-xl transition shadow-md flex items-center justify-center gap-2 mt-2", children: [_jsx(UserPlus, { className: "w-4 h-4" }), "\u062B\u0628\u062A \u0628\u06CC\u0645\u0627\u0631 \u062C\u062F\u06CC\u062F \u0648 \u062A\u0634\u06A9\u06CC\u0644 \u067E\u0631\u0648\u0646\u062F\u0647 \u0627\u0644\u06A9\u062A\u0631\u0648\u0646\u06CC\u06A9"] })] }), selectedPatient && (_jsxs("div", { className: "mt-4 p-4 bg-teal-50/60 border border-teal-200 rounded-xl space-y-3", children: [_jsxs("div", { className: "flex items-center justify-between border-b border-teal-100 pb-2", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(UserCheck, { className: "w-5 h-5 text-teal-700" }), _jsxs("div", { children: [_jsx("h3", { className: "text-sm font-bold text-slate-800", children: selectedPatient.fullName }), _jsxs("p", { className: "text-xs text-slate-500", children: ["\u06A9\u062F \u067E\u0631\u0648\u0646\u062F\u0647: ", selectedPatient.fileNumber, " | \u0647\u0645\u0631\u0627\u0647: ", selectedPatient.mobilePhone] })] })] }), _jsxs("div", { className: "flex items-center gap-2", children: [_jsxs("button", { type: "button", onClick: () => onOpenPatientProfile && onOpenPatientProfile(selectedPatient.id), className: "bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold px-2.5 py-1.5 rounded-lg transition flex items-center gap-1 shadow-xs", title: "\u0627\u0635\u0644\u0627\u062D \u0645\u0634\u062E\u0635\u0627\u062A\u060C \u06A9\u062F \u0645\u0644\u06CC \u0648 \u0634\u0646\u0627\u0633\u0646\u0627\u0645\u0647 \u0628\u06CC\u0645\u0627\u0631", children: [_jsx(Edit3, { className: "w-3.5 h-3.5" }), _jsx("span", { children: "\u0627\u0635\u0644\u0627\u062D \u0645\u0634\u062E\u0635\u0627\u062A \u0628\u06CC\u0645\u0627\u0631" })] }), _jsxs("button", { type: "button", onClick: () => handleSendWelcomeSms(selectedPatient.fullName, selectedPatient.mobilePhone, selectedPatient.fileNumber), className: "bg-teal-600 hover:bg-teal-700 text-white text-[11px] font-bold px-2.5 py-1.5 rounded-lg transition flex items-center gap-1 shadow-xs", title: "\u0627\u0631\u0633\u0627\u0644 \u067E\u06CC\u0627\u0645\u06A9 \u062E\u0648\u0634\u200C\u0622\u0645\u062F\u06AF\u0648\u06CC\u06CC \u0628\u0647 \u0647\u0645\u0631\u0627\u0647 \u0634\u0645\u0627\u0631\u0647 \u067E\u0631\u0648\u0646\u062F\u0647", children: [_jsx(Send, { className: "w-3.5 h-3.5" }), _jsx("span", { children: "\u0627\u0631\u0633\u0627\u0644 \u067E\u06CC\u0627\u0645\u06A9 \u062E\u0648\u0634\u200C\u0622\u0645\u062F\u06AF\u0648\u06CC\u06CC" })] }), _jsxs("button", { type: "button", onClick: () => setShowSalamatModal(true), className: "bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold px-2.5 py-1.5 rounded-lg transition flex items-center gap-1 shadow-xs", title: "\u0627\u0633\u062A\u0639\u0644\u0627\u0645 \u0648 \u0627\u0639\u062A\u0628\u0627\u0631\u0633\u0646\u062C\u06CC \u0628\u06CC\u0645\u0647 \u0633\u0644\u0627\u0645\u062A \u0628\u06CC\u0645\u0627\u0631 \u062F\u0631 \u0644\u062D\u0638\u0647 \u067E\u0630\u06CC\u0631\u0634", children: [_jsx(ShieldCheck, { className: "w-3.5 h-3.5" }), _jsx("span", { children: selectedPatient.salamatInsuranceInfo?.deserved ? 'بیمه سلامت: تایید' : 'استعلام بیمه سلامت' })] }), _jsx("button", { type: "button", onClick: () => setSelectedPatient(null), className: "text-slate-400 hover:text-slate-600 p-1 rounded-md", children: _jsx(X, { className: "w-4 h-4" }) })] })] }), selectedPatient.creditConfig.currentDebt > 0 ? (_jsxs("div", { className: "p-4 bg-rose-50 border-2 border-rose-400 rounded-xl space-y-3 text-rose-950 shadow-sm", children: [_jsxs("div", { className: "flex items-start justify-between gap-2", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(AlertTriangle, { className: "w-5 h-5 text-rose-600 shrink-0" }), _jsxs("div", { children: [_jsx("h4", { className: "text-sm font-bold text-rose-900", children: "\u26A0\uFE0F \u0647\u0634\u062F\u0627\u0631 \u0628\u062F\u0647\u06CC \u0645\u0639\u0648\u0642 \u0628\u06CC\u0645\u0627\u0631" }), _jsxs("p", { className: "text-xs text-rose-800 mt-0.5", children: ["\u0627\u06CC\u0646 \u0628\u06CC\u0645\u0627\u0631 \u062F\u0627\u0631\u0627\u06CC \u0645\u0627\u0646\u062F\u0647 \u0628\u062F\u0647\u06CC \u062A\u0633\u0648\u06CC\u0647 \u0646\u0634\u062F\u0647 \u0628\u0647 \u0645\u0628\u0644\u063A", ' ', _jsx("span", { className: "font-extrabold text-rose-900 text-sm", children: formatCurrency(selectedPatient.creditConfig.currentDebt, settings.currencyUnit) }), ' ', "\u0645\u06CC\u200C\u0628\u0627\u0634\u062F."] })] })] }), _jsxs("button", { type: "button", onClick: () => {
                                                                    setSettleAmount(selectedPatient.creditConfig.currentDebt);
                                                                    setSettleRrn('');
                                                                    setShowQuickSettleModal(true);
                                                                }, className: "bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold px-3 py-2 rounded-lg shadow transition flex items-center gap-1.5 shrink-0", children: [_jsx(Coins, { className: "w-4 h-4" }), "\u062A\u0633\u0648\u06CC\u0647 \u0628\u062F\u0647\u06CC"] })] }), _jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-rose-200 text-xs", children: [_jsxs("button", { type: "button", onClick: () => setShowDebtDetails(!showDebtDetails), className: "text-rose-800 hover:text-rose-950 font-bold underline flex items-center gap-1", children: [_jsx(Eye, { className: "w-3.5 h-3.5" }), showDebtDetails ? 'بستن جزئیات بدهی' : 'مشاهده جزئیات بدهی و سقف اعتبار', showDebtDetails ? _jsx(ChevronUp, { className: "w-3.5 h-3.5" }) : _jsx(ChevronDown, { className: "w-3.5 h-3.5" })] }), _jsx("button", { type: "button", onClick: () => onNavigateToTab('patients_credit'), className: "text-slate-600 hover:text-slate-900 text-[11px] underline", children: "\u0645\u062F\u06CC\u0631\u06CC\u062A \u0627\u0639\u062A\u0628\u0627\u0631 \u062F\u0631 \u0635\u0646\u062F\u0648\u0642" })] }), showDebtDetails && (_jsx("div", { className: "p-3 bg-white/90 border border-rose-200 rounded-lg text-xs space-y-2 text-slate-700 mt-2", children: _jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsxs("div", { children: [_jsx("span", { className: "text-slate-500", children: "\u0633\u0642\u0641 \u0627\u0639\u062A\u0628\u0627\u0631 \u062A\u062E\u0635\u06CC\u0635 \u06CC\u0627\u0641\u062A\u0647:" }), ' ', _jsx("span", { className: "font-bold text-slate-800", children: formatCurrency(selectedPatient.creditConfig.creditLimit, settings.currencyUnit) })] }), _jsxs("div", { children: [_jsx("span", { className: "text-slate-500", children: "\u0645\u0647\u0644\u062A \u0628\u0627\u0632\u067E\u0631\u062F\u0627\u062E\u062A:" }), ' ', _jsxs("span", { className: "font-bold text-slate-800", children: [selectedPatient.creditConfig.maturityDays, " \u0631\u0648\u0632"] })] }), _jsxs("div", { children: [_jsx("span", { className: "text-slate-500", children: "\u0627\u0639\u062A\u0628\u0627\u0631 \u0628\u0627\u0642\u06CC\u200C\u0645\u0627\u0646\u062F\u0647:" }), ' ', _jsx("span", { className: "font-bold text-emerald-700", children: formatCurrency(Math.max(0, selectedPatient.creditConfig.creditLimit - selectedPatient.creditConfig.currentDebt), settings.currencyUnit) })] }), _jsxs("div", { children: [_jsx("span", { className: "text-slate-500", children: "\u0648\u0636\u0639\u06CC\u062A \u0627\u0633\u062A\u0639\u0644\u0627\u0645 \u0647\u0648\u06CC\u062A:" }), ' ', _jsx("span", { className: "font-bold text-teal-700", children: selectedPatient.verificationStatus === 'verified' ? 'تایید شده ثبت احوال' : 'احراز نشده' })] })] }) }))] })) : (_jsxs("div", { className: "text-xs text-emerald-700 font-medium flex items-center gap-1.5 bg-emerald-50 border border-emerald-200 px-3 py-2 rounded-lg", children: [_jsx(CheckCircle2, { className: "w-4 h-4 text-emerald-600" }), "\u0648\u0636\u0639\u06CC\u062A \u062D\u0633\u0627\u0628 \u0628\u06CC\u0645\u0627\u0631 \u062A\u0633\u0648\u06CC\u0647 \u0648 \u0628\u062F\u0648\u0646 \u0628\u062F\u0647\u06CC \u0645\u06CC\u200C\u0628\u0627\u0634\u062F."] }))] }))] }), _jsxs("div", { className: "bg-white rounded-xl shadow-sm border border-slate-200 p-5 space-y-4", children: [_jsxs("h2", { className: "text-sm font-bold text-slate-800 flex items-center gap-2 border-b border-slate-100 pb-3", children: [_jsx(Plus, { className: "w-4 h-4 text-teal-600" }), "\u062B\u0628\u062A \u0646\u0648\u0628\u062A \u067E\u0630\u06CC\u0631\u0634 \u0648 \u0627\u0646\u062A\u062E\u0627\u0628 \u062E\u062F\u0645\u0627\u062A"] }), !selectedPatient ? (_jsx("div", { className: "p-6 text-center border-2 border-dashed border-slate-200 rounded-xl text-slate-400 text-xs", children: "\u0644\u0637\u0641\u0627\u064B \u0627\u0628\u062A\u062F\u0627 \u0628\u06CC\u0645\u0627\u0631 \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u0631\u0627 \u0627\u0632 \u06A9\u0627\u062F\u0631 \u0628\u0627\u0644\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06CC\u0627 \u062B\u0628\u062A \u0646\u0627\u0645 \u06A9\u0646\u06CC\u062F." })) : (_jsxs("div", { className: "space-y-4", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-slate-700 mb-1.5", children: "\u0627\u0646\u062A\u062E\u0627\u0628 \u067E\u0632\u0634\u06A9 \u0645\u0639\u0627\u0644\u062C / \u0645\u062A\u062E\u0635\u0635:" }), _jsx("select", { value: selectedDoctorId, onChange: (e) => setSelectedDoctorId(e.target.value), className: "w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-teal-500 focus:border-teal-500", children: doctors.map((doc) => (_jsxs("option", { value: doc.id, children: [doc.name, " - ", doc.specialty] }, doc.id))) })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-slate-700 mb-1.5", children: "\u0627\u0646\u062A\u062E\u0627\u0628 \u062E\u062F\u0645\u0627\u062A \u0645\u0648\u0631\u062F \u0646\u06CC\u0627\u0632 \u067E\u0630\u06CC\u0631\u0634:" }), _jsx("div", { className: "space-y-2 max-h-48 overflow-y-auto border border-slate-200 rounded-lg p-2.5 bg-slate-50", children: medicalServices.map((srv) => {
                                                            const isChecked = selectedServices.some((s) => s.id === srv.id);
                                                            return (_jsxs("label", { className: `flex items-center justify-between p-2 rounded-lg border text-xs cursor-pointer transition ${isChecked
                                                                    ? 'bg-teal-50 border-teal-300 text-teal-900 font-medium'
                                                                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'}`, children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx("input", { type: "checkbox", checked: isChecked, onChange: () => handleToggleService(srv), className: "w-4 h-4 text-teal-600 rounded focus:ring-teal-500" }), _jsx("span", { children: srv.title })] }), _jsxs("span", { className: "font-bold text-slate-600", children: [(srv.tariffPrice ?? srv.price ?? 0).toLocaleString('fa-IR'), " \u062A\u0648\u0645\u0627\u0646"] })] }, srv.id));
                                                        }) })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-slate-700 mb-1", children: "\u062A\u0648\u0636\u06CC\u062D\u0627\u062A \u067E\u0630\u06CC\u0631\u0634 / \u0639\u0644\u062A \u0645\u0631\u0627\u062C\u0639\u0647:" }), _jsx("input", { type: "text", placeholder: "\u0645\u062B\u0644\u0627\u064B: \u0645\u0639\u0627\u06CC\u0646\u0647 \u0632\u062E\u0645 \u062F\u06CC\u0627\u0628\u062A\u06CC \u067E\u0627\u06CC \u0631\u0627\u0633\u062A\u060C \u062A\u0639\u0648\u06CC\u0636 \u067E\u0627\u0646\u0633\u0645\u0627\u0646...", value: visitNotes, onChange: (e) => setVisitNotes(e.target.value), className: "w-full text-xs border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-teal-500" })] }), _jsxs("div", { className: "p-3 bg-slate-100 rounded-lg flex items-center justify-between text-xs", children: [_jsx("span", { className: "text-slate-600 font-medium", children: "\u062C\u0645\u0639 \u06A9\u0644 \u062A\u0639\u0631\u0641\u0647 \u062E\u062F\u0645\u0627\u062A:" }), _jsxs("span", { className: "text-sm font-bold text-teal-700", children: [selectedServices.reduce((sum, s) => sum + (s.tariffPrice ?? s.price ?? 0), 0).toLocaleString('fa-IR'), " \u062A\u0648\u0645\u0627\u0646"] })] }), _jsxs("label", { className: "flex items-center gap-2 p-2.5 bg-teal-50 border border-teal-200 rounded-lg cursor-pointer text-xs font-bold text-teal-900 hover:bg-teal-100/80 transition", children: [_jsx("input", { type: "checkbox", checked: sendWelcomeSmsOnQueue, onChange: (e) => setSendWelcomeSmsOnQueue(e.target.checked), className: "w-4 h-4 text-teal-600 rounded focus:ring-teal-500" }), _jsx(Sparkles, { className: "w-4 h-4 text-amber-500" }), _jsx("span", { children: "\u0627\u0631\u0633\u0627\u0644 \u0622\u0646\u06CC \u067E\u06CC\u0627\u0645\u06A9 \u062E\u0648\u0634\u200C\u0622\u0645\u062F\u06AF\u0648\u06CC\u06CC (\u0628\u0627 \u0627\u0644\u06AF\u0648\u06CC welcome - \u06A9\u062F \u06A9\u0627\u0648\u0647\u200C\u0646\u06AF\u0627\u0631 1488881)" })] }), _jsxs("button", { onClick: handleCreateVisitQueue, disabled: selectedServices.length === 0, className: "w-full flex items-center justify-center gap-2 bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 text-white text-sm font-bold py-3 rounded-lg transition shadow", children: [_jsx(Send, { className: "w-4 h-4" }), "\u062B\u0628\u062A \u0646\u0648\u0628\u062A \u0648 \u0627\u0631\u0633\u0627\u0644 \u0628\u0647 \u0635\u0641 \u067E\u0632\u0634\u06A9"] })] }))] })] }), _jsx("div", { className: "lg:col-span-7 space-y-4", children: _jsxs("div", { className: "bg-white rounded-xl shadow-sm border border-slate-200 p-5", children: [_jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3 mb-4", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Clock, { className: "w-5 h-5 text-teal-600" }), _jsx("h2", { className: "text-base font-bold text-slate-800", children: "\u0635\u0641 \u067E\u0630\u06CC\u0631\u0634 \u0648 \u0646\u0648\u0628\u062A\u200C\u0647\u0627\u06CC \u0627\u0645\u0631\u0648\u0632" }), _jsxs("span", { className: "bg-teal-100 text-teal-800 text-xs font-bold px-2 py-0.5 rounded-full", children: [visitQueue.length, " \u0646\u0648\u0628\u062A"] })] }), _jsxs("div", { className: "flex items-center gap-1 overflow-x-auto pb-1 text-xs", children: [_jsxs("button", { onClick: () => setQueueStatusFilter('all'), className: `px-3 py-1.5 rounded-lg whitespace-nowrap font-bold transition ${queueStatusFilter === 'all'
                                                        ? 'bg-slate-800 text-white'
                                                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`, children: ["\u0647\u0645\u0647 \u0646\u0648\u0628\u062A\u200C\u0647\u0627 (", visitQueue.length, ")"] }), _jsx("button", { onClick: () => setQueueStatusFilter('waiting_doctor'), className: `px-3 py-1.5 rounded-lg whitespace-nowrap font-bold transition ${queueStatusFilter === 'waiting_doctor'
                                                        ? 'bg-amber-600 text-white'
                                                        : 'bg-amber-50 text-amber-800 hover:bg-amber-100'}`, children: "\u06F1. \u067E\u0630\u06CC\u0631\u0634 (\u0645\u0646\u062A\u0638\u0631)" }), _jsx("button", { onClick: () => setQueueStatusFilter('operating_room'), className: `px-3 py-1.5 rounded-lg whitespace-nowrap font-bold transition ${queueStatusFilter === 'operating_room'
                                                        ? 'bg-purple-600 text-white'
                                                        : 'bg-purple-50 text-purple-800 hover:bg-purple-100'}`, children: "\u06F2. \u0627\u062A\u0627\u0642 \u0639\u0645\u0644 / \u062C\u0631\u0627\u062D\u06CC" }), _jsx("button", { onClick: () => setQueueStatusFilter('ready_for_discharge'), className: `px-3 py-1.5 rounded-lg whitespace-nowrap font-bold transition ${queueStatusFilter === 'ready_for_discharge'
                                                        ? 'bg-emerald-600 text-white'
                                                        : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'}`, children: "\u06F3. \u0622\u0645\u0627\u062F\u0647 \u062A\u0631\u062E\u06CC\u0635 / \u0635\u0646\u062F\u0648\u0642" }), _jsx("button", { onClick: () => setQueueStatusFilter('completed'), className: `px-3 py-1.5 rounded-lg whitespace-nowrap font-bold transition ${queueStatusFilter === 'completed'
                                                        ? 'bg-blue-600 text-white'
                                                        : 'bg-blue-50 text-blue-800 hover:bg-blue-100'}`, children: "\u062A\u0631\u062E\u06CC\u0635 \u0634\u062F\u0647" })] })] }), filteredQueue.length === 0 ? (_jsx("div", { className: "p-8 text-center border-2 border-dashed border-slate-200 rounded-xl text-slate-400 text-xs", children: "\u0647\u06CC\u0686 \u0646\u0648\u0628\u062A\u06CC \u062F\u0631 \u0627\u06CC\u0646 \u062F\u0633\u062A\u0647 \u0628\u0646\u062F\u06CC \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F." })) : (_jsx("div", { className: "space-y-3", children: filteredQueue.map((item, idx) => (_jsxs("div", { className: "p-4 border border-slate-200 hover:border-teal-300 rounded-xl bg-slate-50/50 space-y-3 transition shadow-sm", children: [_jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-2.5", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsxs("span", { className: "px-2.5 py-1 rounded-lg bg-teal-700 text-white text-xs font-extrabold shadow-xs shrink-0 dir-rtl", children: ["\u0646\u0648\u0628\u062A #", toPersianDigits(item.turnNumber || (idx + 1))] }), _jsxs("div", { children: [_jsxs("div", { className: "text-sm font-bold text-slate-800 flex items-center gap-2", children: [_jsx("button", { type: "button", onClick: () => onOpenPatientProfile && onOpenPatientProfile(item.patientId || item.patientName), className: "text-teal-800 hover:text-teal-900 underline decoration-teal-400 font-bold hover:bg-teal-50 px-1.5 py-0.5 rounded transition text-right", title: "\u06A9\u0644\u06CC\u06A9 \u06A9\u0646\u06CC\u062F: \u0645\u0634\u0627\u0647\u062F\u0647 \u067E\u0631\u0648\u0646\u062F\u0647 \u06A9\u0627\u0645\u0644\u060C \u067E\u0630\u06CC\u0631\u0634 \u0645\u062C\u062F\u062F \u0648 \u0633\u0648\u0627\u0628\u0642 \u0628\u06CC\u0645\u0627\u0631", children: item.patientName }), _jsxs("span", { className: "text-xs text-slate-400 font-normal", children: ["(", item.patientCode, ")"] })] }), _jsxs("div", { className: "text-xs text-slate-500 mt-0.5", children: ["\u067E\u0632\u0634\u06A9 \u0645\u0639\u0627\u0644\u062C: ", _jsx("span", { className: "font-semibold text-slate-700", children: item.doctorName }), " | \u0633\u0627\u0639\u062A \u062B\u0628\u062A: ", item.jalaliTime] })] })] }), _jsx("div", { className: "flex items-center gap-2", children: getStatusBadge(item.status) })] }), _jsxs("div", { className: "flex flex-wrap items-center gap-1.5 text-xs", children: [_jsx("span", { className: "text-slate-500 font-bold", children: "\u062E\u062F\u0645\u0627\u062A \u0648 \u062A\u062C\u0647\u06CC\u0632\u0627\u062A:" }), item.services.map((srv) => (_jsxs("span", { className: `border px-2 py-0.5 rounded text-[11px] font-medium ${srv.category?.includes('اتاق عمل') || srv.title?.includes('اتاق عمل')
                                                            ? 'bg-purple-50 text-purple-800 border-purple-200 font-bold'
                                                            : 'bg-white text-slate-700 border-slate-200'}`, children: [srv.title, " (", (srv.price ?? srv.tariffPrice ?? 0).toLocaleString('fa-IR'), " \u062A\u0648\u0645\u0627\u0646)"] }, srv.id)))] }), item.diagnosis && (_jsxs("div", { className: "text-xs text-slate-600 bg-amber-50/70 border border-amber-200 p-2 rounded-lg", children: [_jsx("span", { className: "font-bold text-amber-800", children: "\u062A\u0634\u062E\u06CC\u0635 / \u062A\u0648\u0636\u06CC\u062D\u0627\u062A: " }), item.diagnosis] })), _jsxs("div", { className: "flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200 text-xs", children: [_jsxs("div", { className: "font-bold text-slate-700 flex flex-wrap items-center gap-2", children: [_jsx("span", { children: "\u0645\u0628\u0644\u063A \u06A9\u0644:" }), _jsxs("span", { className: "text-teal-700 text-sm font-mono", children: [(item.totalCost ?? 0).toLocaleString('fa-IR'), " \u062A\u0648\u0645\u0627\u0646"] }), (() => {
                                                                const balance = (item.totalCost || 0) - (item.paidAmount || 0);
                                                                if (balance > 0) {
                                                                    return (_jsxs("span", { className: "bg-rose-100 text-rose-800 border border-rose-300 px-2 py-0.5 rounded-lg text-[11px] font-bold flex items-center gap-1", title: "\u0628\u06CC\u0645\u0627\u0631 \u067E\u0633 \u0627\u0632 \u062A\u063A\u06CC\u06CC\u0631 \u062E\u062F\u0645\u0627\u062A \u0628\u062F\u0647\u06A9\u0627\u0631 \u0634\u062F\u0647 \u0627\u0633\u062A", children: [_jsx(AlertTriangle, { className: "w-3 h-3 text-rose-600" }), "\u0628\u062F\u0647\u06A9\u0627\u0631: ", balance.toLocaleString('fa-IR'), " \u062A\u0648\u0645\u0627\u0646"] }));
                                                                }
                                                                else if (balance < 0) {
                                                                    return (_jsxs("span", { className: "bg-emerald-100 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded-lg text-[11px] font-bold flex items-center gap-1", title: "\u0628\u06CC\u0645\u0627\u0631 \u0627\u0636\u0627\u0641\u0647 \u062F\u0631\u06CC\u0627\u0641\u062A\u06CC \u062F\u0627\u0631\u062F \u0648 \u0628\u0633\u062A\u0627\u0646\u06A9\u0627\u0631 \u0634\u062F\u0647 \u0627\u0633\u062A", children: [_jsx(Coins, { className: "w-3 h-3 text-emerald-600" }), "\u0628\u0633\u062A\u0627\u0646\u06A9\u0627\u0631: ", Math.abs(balance).toLocaleString('fa-IR'), " \u062A\u0648\u0645\u0627\u0646"] }));
                                                                }
                                                                else if (item.paidAmount > 0 || item.status === 'completed' || item.status === 'discharged') {
                                                                    return (_jsxs("span", { className: "bg-blue-50 text-blue-700 border border-blue-200 px-2 py-0.5 rounded-lg text-[11px] font-bold flex items-center gap-1", children: [_jsx(ShieldCheck, { className: "w-3 h-3 text-blue-600" }), "\u062A\u0633\u0648\u06CC\u0647 \u0634\u062F\u0647"] }));
                                                                }
                                                                return null;
                                                            })()] }), _jsxs("div", { className: "flex flex-wrap items-center gap-1.5", children: [item.status !== 'discharged' && item.status !== 'completed' && item.status !== 'cancelled' && (_jsxs("button", { onClick: () => onNavigateToTab('consent'), className: "bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold px-2.5 py-1.5 rounded-lg transition flex items-center gap-1 shadow-2xs", title: "\u062B\u0628\u062A \u0627\u062E\u062A\u06CC\u0627\u0631\u06CC \u0641\u0631\u0645\u060C \u0631\u0636\u0627\u06CC\u062A\u200C\u0646\u0627\u0645\u0647 \u06CC\u0627 \u062A\u0631\u06CC\u0627\u0698 \u0642\u0628\u0644 \u0627\u0632 \u062A\u0631\u062E\u06CC\u0635", children: [_jsx(FileText, { className: "w-3.5 h-3.5 text-amber-700" }), _jsx("span", { children: "\u062B\u0628\u062A \u0631\u0636\u0627\u06CC\u062A\u200C\u0646\u0627\u0645\u0647 / \u0641\u0631\u0645" })] })), (item.status === 'discharged' || item.status === 'completed' || item.paidAmount > 0) && (_jsxs("button", { onClick: () => setSettlementInvoiceItem(item), className: "bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 shadow-xs text-xs", title: "\u0635\u062F\u0648\u0631 \u0648 \u0686\u0627\u067E \u0641\u0627\u06A9\u062A\u0648\u0631 \u062A\u0631\u062E\u06CC\u0635 \u0648 \u062A\u0633\u0648\u06CC\u0647 \u062D\u0633\u0627\u0628 (\u062D\u0631\u0627\u0631\u062A\u06CC / A4 / A5)", children: [_jsx(Printer, { className: "w-3.5 h-3.5" }), _jsx("span", { children: "\u0686\u0627\u067E \u0641\u0627\u06A9\u062A\u0648\u0631 \u062A\u0633\u0648\u06CC\u0647 (\u062D\u0631\u0627\u0631\u062A\u06CC/A4/A5)" })] })), _jsxs("button", { onClick: () => setSmsPatientItem(item), className: "bg-teal-600 hover:bg-teal-700 text-white font-bold px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 shadow-xs text-xs", title: "\u0627\u0631\u0633\u0627\u0644 \u067E\u06CC\u0627\u0645\u06A9 \u062E\u0648\u0634\u200C\u0622\u0645\u062F\u06AF\u0648\u06CC\u06CC (\u0627\u0644\u06AF\u0648\u06CC welcome - \u06A9\u062F 1488881) \u06CC\u0627 \u067E\u06CC\u0627\u0645\u06A9 \u062A\u0633\u0648\u06CC\u0647 \u062D\u0633\u0627\u0628", children: [_jsx(MessageSquare, { className: "w-3.5 h-3.5" }), _jsx("span", { children: "\u0627\u0631\u0633\u0627\u0644 \u067E\u06CC\u0627\u0645\u06A9 SMS" })] }), (item.status === 'discharged' || item.status === 'completed') && (_jsxs("button", { onClick: () => handleRevertDischarge(item), className: "bg-amber-500 hover:bg-amber-600 text-white font-bold px-2.5 py-1.5 rounded-lg transition flex items-center gap-1 shadow-xs", title: "\u0628\u0627\u0632\u06AF\u0631\u062F\u0627\u0646\u06CC \u067E\u0631\u0648\u0646\u062F\u0647 \u0628\u06CC\u0645\u0627\u0631 \u0627\u0632 \u062A\u0631\u062E\u06CC\u0635 \u062C\u0647\u062A \u0641\u0639\u0627\u0644 \u06A9\u0631\u062F\u0646 \u0645\u062C\u062F\u062F \u062B\u0628\u062A\u060C \u062D\u0630\u0641 \u06CC\u0627 \u0648\u06CC\u0631\u0627\u06CC\u0634 \u062E\u062F\u0645\u0627\u062A", children: [_jsx(RotateCcw, { className: "w-3.5 h-3.5" }), _jsx("span", { children: "\u0628\u0627\u0632\u06AF\u0631\u062F\u0627\u0646\u06CC \u0627\u0632 \u062A\u0631\u062E\u06CC\u0635 (\u062C\u0647\u062A \u0648\u06CC\u0631\u0627\u06CC\u0634 \u062E\u062F\u0645\u0627\u062A)" })] })), _jsxs("button", { onClick: () => handleOpenEditModal(item), className: "bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 font-bold px-2.5 py-1.5 rounded-lg transition flex items-center gap-1", title: "\u0627\u0635\u0644\u0627\u062D \u062E\u062F\u0645\u0627\u062A\u060C \u062A\u062C\u0647\u06CC\u0632\u0627\u062A\u060C \u067E\u0632\u0634\u06A9 \u0648 \u062C\u0632\u0626\u06CC\u0627\u062A \u067E\u0631\u0648\u0646\u062F\u0647", children: [_jsx(Edit3, { className: "w-3.5 h-3.5 text-indigo-600" }), _jsx("span", { children: "\u0627\u0635\u0644\u0627\u062D\u0627\u062A \u067E\u0631\u0648\u0646\u062F\u0647" })] }), (item.status === 'waiting_doctor' || item.status === 'waiting') && (_jsxs("button", { onClick: () => handleUpdateStatus(item, 'operating_room'), className: "bg-purple-600 hover:bg-purple-700 text-white font-bold px-3 py-1.5 rounded-lg transition flex items-center gap-1 shadow-sm", children: [_jsx(Stethoscope, { className: "w-3.5 h-3.5" }), "\u0627\u0631\u0633\u0627\u0644 \u0628\u0647 \u0627\u062A\u0627\u0642 \u0639\u0645\u0644"] })), (item.status === 'operating_room' || item.status === 'under_treatment') && (_jsxs(_Fragment, { children: [_jsxs("button", { onClick: () => handleOpenEditModal(item), className: "bg-purple-100 hover:bg-purple-200 text-purple-900 border border-purple-300 font-bold px-2.5 py-1.5 rounded-lg transition flex items-center gap-1", children: [_jsx(Package, { className: "w-3.5 h-3.5 text-purple-700" }), "\u062B\u0628\u062A \u0648\u0633\u0627\u06CC\u0644 \u0645\u0635\u0631\u0641\u06CC"] }), _jsxs("button", { onClick: () => handleUpdateStatus(item, 'ready_for_discharge'), className: "bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-3 py-1.5 rounded-lg transition flex items-center gap-1 shadow-sm", children: [_jsx(CheckCircle2, { className: "w-3.5 h-3.5" }), "\u0627\u0639\u0644\u0627\u0645 \u0622\u0645\u0627\u062F\u0647 \u0628\u0647 \u062A\u0631\u062E\u06CC\u0635"] })] })), (item.status === 'ready_for_discharge' || item.status === 'waiting_payment') && (_jsxs("button", { onClick: () => handleOpenDischargeModal(item), className: "bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-3 py-1.5 rounded-lg transition flex items-center gap-1 shadow-sm", children: [_jsx(CreditCard, { className: "w-3.5 h-3.5" }), "\u062A\u0633\u0648\u06CC\u0647 \u0648 \u062A\u0631\u062E\u06CC\u0635 \u0646\u0647\u0627\u06CC\u06CC"] })), item.status !== 'cancelled' && item.status !== 'completed' && item.status !== 'discharged' && (_jsx("button", { onClick: () => handleUpdateStatus(item, 'cancelled'), className: "text-slate-400 hover:text-rose-600 p-1.5 rounded hover:bg-rose-50", title: "\u0644\u063A\u0648 \u067E\u0630\u06CC\u0631\u0634", children: _jsx(X, { className: "w-4 h-4" }) }))] })] })] }, item.id))) }))] }) })] }), showRegModal && (_jsx("div", { className: "fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4", children: _jsxs("div", { className: "bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-2xl overflow-hidden animate-in fade-in zoom-in duration-200", children: [_jsxs("div", { className: "bg-teal-700 text-white p-4 flex items-center justify-between", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(UserPlus, { className: "w-5 h-5" }), _jsx("h2", { className: "text-base font-bold", children: "\u062B\u0628\u062A\u200C\u0646\u0627\u0645 \u0628\u06CC\u0645\u0627\u0631 \u062C\u062F\u06CC\u062F \u0648 \u062A\u0634\u06A9\u06CC\u0644 \u067E\u0631\u0648\u0646\u062F\u0647 \u0627\u0644\u06A9\u062A\u0631\u0648\u0646\u06CC\u06A9" })] }), _jsx("button", { onClick: () => setShowRegModal(false), className: "text-teal-100 hover:text-white p-1 rounded-lg", children: _jsx(X, { className: "w-5 h-5" }) })] }), _jsxs("form", { onSubmit: handleRegisterPatient, className: "p-6 space-y-4 max-h-[80vh] overflow-y-auto", children: [_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-semibold text-slate-700 mb-2", children: "\u0646\u0648\u0639 \u062A\u0627\u0628\u0639\u06CC\u062A / \u0647\u0648\u06CC\u062A\u06CC \u0628\u06CC\u0645\u0627\u0631:" }), _jsxs("div", { className: "grid grid-cols-3 gap-3 text-xs font-medium", children: [_jsx("button", { type: "button", onClick: () => {
                                                        setRegCategory('iranian');
                                                        setIdentityVerified(false);
                                                    }, className: `p-3 rounded-xl border text-center transition ${regCategory === 'iranian'
                                                        ? 'bg-teal-50 border-teal-500 text-teal-800 font-bold'
                                                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'}`, children: "\u0627\u06CC\u0631\u0627\u0646\u06CC (\u06A9\u062F \u0645\u0644\u06CC)" }), _jsx("button", { type: "button", onClick: () => {
                                                        setRegCategory('foreign');
                                                        setIdentityVerified(false);
                                                    }, className: `p-3 rounded-xl border text-center transition ${regCategory === 'foreign'
                                                        ? 'bg-teal-50 border-teal-500 text-teal-800 font-bold'
                                                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'}`, children: "\u0627\u062A\u0628\u0627\u0639 \u062E\u0627\u0631\u062C\u06CC (\u067E\u0627\u0633\u067E\u0648\u0631\u062A/\u0634\u0646\u0627\u0633\u0647)" }), _jsx("button", { type: "button", onClick: () => {
                                                        setRegCategory('unknown');
                                                        setIdentityVerified(false);
                                                    }, className: `p-3 rounded-xl border text-center transition ${regCategory === 'unknown'
                                                        ? 'bg-teal-50 border-teal-500 text-teal-800 font-bold'
                                                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'}`, children: "\u0645\u062C\u0647\u0648\u0644\u200C\u0627\u0644\u0647\u0648\u06CC\u0647 / \u0627\u0648\u0631\u0698\u0627\u0646\u0633" })] })] }), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-4", children: [regCategory === 'iranian' && (_jsxs("div", { children: [_jsxs("div", { className: "flex items-center justify-between mb-1", children: [_jsx("label", { className: "text-xs font-bold text-[#333333] dark:text-slate-200", children: "\u06A9\u062F \u0645\u0644\u06CC \u06F1\u06F0 \u0631\u0642\u0645\u06CC:" }), _jsx("span", { className: "text-[10px] bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded font-bold", children: "\u0627\u062C\u0628\u0627\u0631\u06CC" })] }), _jsx("div", { className: "relative", children: _jsx("input", { type: "text", maxLength: 10, placeholder: "\u0645\u062B\u0644\u0627\u064B \u06F3\u06F5\u06F2\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7", value: regNationalId, onChange: (e) => {
                                                            setRegNationalId(e.target.value.replace(/\D/g, ''));
                                                            setIdentityVerified(false);
                                                        }, className: `w-full text-sm border rounded-lg p-2.5 focus:ring-2 dir-ltr text-right ${regNationalId.length === 10
                                                            ? isValidIranianNationalId(regNationalId)
                                                                ? 'border-emerald-500 focus:ring-emerald-500'
                                                                : 'border-rose-500 focus:ring-rose-500'
                                                            : 'border-slate-300 focus:ring-teal-500'}`, required: regCategory === 'iranian' }) })] })), regCategory === 'foreign' && (_jsxs("div", { children: [_jsxs("div", { className: "flex items-center justify-between mb-1", children: [_jsx("label", { className: "text-xs font-bold text-[#333333] dark:text-slate-200", children: "\u0634\u0645\u0627\u0631\u0647 \u06AF\u0630\u0631\u0646\u0627\u0645\u0647 / \u0634\u0646\u0627\u0633\u0647 \u0627\u062E\u062A\u0635\u0627\u0635\u06CC:" }), _jsx("span", { className: "text-[10px] bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded font-bold", children: "\u0627\u062C\u0628\u0627\u0631\u06CC" })] }), _jsx("input", { type: "text", placeholder: "\u0645\u062B\u0644\u0627\u064B AFG-889900", value: regPassportNumber, onChange: (e) => setRegPassportNumber(e.target.value), className: "w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-teal-500", required: regCategory === 'foreign' })] })), _jsxs("div", { children: [_jsxs("div", { className: "flex items-center justify-between mb-1", children: [_jsx("label", { className: "text-xs font-bold text-[#333333] dark:text-slate-200", children: "\u0634\u0645\u0627\u0631\u0647 \u0647\u0645\u0631\u0627\u0647 (\u06F1\u06F1 \u0631\u0642\u0645\u06CC):" }), _jsx("span", { className: "text-[10px] bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded font-bold", children: "\u0627\u062C\u0628\u0627\u0631\u06CC" })] }), _jsx("input", { type: "text", maxLength: 11, placeholder: "\u06F0\u06F9\u06F1\u06F2\u06F3\u06F2\u06F6\u06F4\u06F6\u06F9\u06F9", value: regMobile, onChange: (e) => setRegMobile(e.target.value.replace(/\D/g, '')), className: "w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-teal-500 dir-ltr text-right", required: true })] }), regCategory === 'iranian' && (_jsx("div", { className: "sm:col-span-2 flex items-end", children: _jsxs("button", { type: "button", onClick: handleVerifyIdentity, disabled: verifyingIdentity || regNationalId.length !== 10, className: "w-full bg-slate-800 hover:bg-slate-900 disabled:bg-slate-300 text-white text-xs font-bold py-2.5 rounded-lg transition flex items-center justify-center gap-2", children: [_jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-400" }), verifyingIdentity ? 'درحال استعلام از ثبت احوال و شاهکار...' : 'استعلام آنلاین هویت بیمار از ثبت احوال'] }) })), identityError && (_jsx("div", { className: "sm:col-span-2 p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg text-xs font-medium", children: identityError })), identityVerified && (_jsxs("div", { className: "sm:col-span-2 space-y-2", children: [_jsxs("div", { className: "p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs font-medium flex items-center gap-2", children: [_jsx(CheckCircle2, { className: "w-4 h-4 text-emerald-600 shrink-0" }), _jsx("span", { children: "\u0647\u0648\u06CC\u062A \u0628\u06CC\u0645\u0627\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0627\u0632 \u062B\u0628\u062A \u0627\u062D\u0648\u0627\u0644 \u0627\u0633\u062A\u0639\u0644\u0627\u0645 \u0648 \u0627\u0646\u0637\u0628\u0627\u0642\u200C\u0633\u0646\u062C\u06CC \u0634\u062F." })] }), verifiedInsuranceRecord && (_jsxs("div", { className: "p-3 bg-teal-50 border border-teal-200 rounded-lg text-xs text-teal-900 space-y-1", children: [_jsxs("div", { className: "flex items-center justify-between font-bold text-teal-950 border-b border-teal-200/60 pb-1", children: [_jsxs("span", { className: "flex items-center gap-1.5", children: [_jsx(ShieldCheck, { className: "w-4 h-4 text-teal-700" }), "\u0627\u0633\u062A\u0639\u0644\u0627\u0645 \u0622\u0646\u06CC \u0627\u0633\u062A\u062D\u0642\u0627\u0642\u200C\u0633\u0646\u062C\u06CC \u0628\u06CC\u0645\u0647 (\u0633\u0627\u0632\u0645\u0627\u0646 \u0628\u06CC\u0645\u0647 \u0633\u0644\u0627\u0645\u062A / \u062A\u0623\u0645\u06CC\u0646 \u0627\u062C\u062A\u0645\u0627\u0639\u06CC)"] }), _jsxs("span", { className: "bg-teal-600 text-white px-2 py-0.5 rounded text-[10px]", children: ["\u067E\u0648\u0634\u0634 ", toPersianDigits(verifiedInsuranceRecord.coveragePercent), "\u066A"] })] }), _jsxs("div", { className: "grid grid-cols-2 gap-2 pt-1 font-medium text-[11px]", children: [_jsxs("div", { children: ["\u0635\u0646\u062F\u0648\u0642 \u0628\u06CC\u0645\u0647: ", _jsx("span", { className: "font-bold text-teal-950", children: verifiedInsuranceRecord.insuranceBoxName })] }), _jsxs("div", { children: ["\u0634\u0645\u0627\u0631\u0647 \u062F\u0641\u062A\u0631\u0686\u0647: ", _jsx("span", { className: "font-mono font-bold text-teal-950", children: verifiedInsuranceRecord.insuranceBookletNumber })] }), _jsxs("div", { className: "col-span-2", children: ["\u0648\u0636\u0639\u06CC\u062A \u0627\u0639\u062A\u0628\u0627\u0631: ", _jsxs("span", { className: "text-emerald-700 font-bold", children: [verifiedInsuranceRecord.statusMessage, " (\u0627\u0639\u062A\u0628\u0627\u0631 \u062A\u0627 ", verifiedInsuranceRecord.validUntilJalali, ")"] })] })] })] }))] })), _jsxs("div", { children: [_jsxs("div", { className: "flex items-center justify-between mb-1", children: [_jsx("label", { className: "text-xs font-bold text-[#333333] dark:text-slate-200", children: "\u0646\u0627\u0645 \u0628\u06CC\u0645\u0627\u0631:" }), _jsx("span", { className: "text-[10px] bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded font-bold", children: "\u0627\u062C\u0628\u0627\u0631\u06CC" })] }), _jsx("input", { type: "text", placeholder: "\u0645\u0631\u06CC\u0645", value: regFirstName, onChange: (e) => setRegFirstName(e.target.value), className: "w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-teal-500 font-bold text-slate-900", required: true })] }), _jsxs("div", { children: [_jsxs("div", { className: "flex items-center justify-between mb-1", children: [_jsx("label", { className: "text-xs font-bold text-[#333333] dark:text-slate-200", children: "\u0646\u0627\u0645 \u062E\u0627\u0646\u0648\u0627\u062F\u06AF\u06CC \u0628\u06CC\u0645\u0627\u0631:" }), _jsx("span", { className: "text-[10px] bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded font-bold", children: "\u0627\u062C\u0628\u0627\u0631\u06CC" })] }), _jsx("input", { type: "text", placeholder: "\u0646\u0627\u0645 \u062E\u0627\u0646\u0648\u0627\u062F\u06AF\u06CC", value: regLastName, onChange: (e) => setRegLastName(e.target.value), className: "w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-teal-500 font-bold text-slate-900", required: true })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-bold text-[#333333] dark:text-slate-200 mb-1", children: "\u0646\u0627\u0645 \u067E\u062F\u0631:" }), _jsx("input", { type: "text", placeholder: "\u062D\u0633\u06CC\u0646", value: regFatherName, onChange: (e) => setRegFatherName(e.target.value), className: "w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-teal-500 font-bold text-slate-900" })] }), _jsxs("div", { children: [_jsx("label", { className: "block text-xs font-bold text-[#333333] dark:text-slate-200 mb-1", children: "\u062C\u0646\u0633\u06CC\u062A:" }), _jsxs("select", { value: regGender, onChange: (e) => setRegGender(e.target.value), className: "w-full text-sm border border-slate-300 rounded-lg p-2.5 focus:ring-2 focus:ring-teal-500 font-bold", children: [_jsx("option", { value: "female", children: "\u0632\u0646" }), _jsx("option", { value: "male", children: "\u0645\u0631\u062F" })] })] }), _jsxs("div", { className: "sm:col-span-2 bg-teal-50/60 border border-teal-200/80 rounded-2xl p-3.5 space-y-3", children: [_jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2", children: [_jsxs("label", { className: "text-xs font-bold text-slate-800 flex items-center gap-1.5", children: [_jsx(Calendar, { className: "w-4 h-4 text-teal-600 shrink-0" }), _jsx("span", { children: "\u0633\u0646 \u0648 \u062A\u0627\u0631\u06CC\u062E \u062A\u0648\u0644\u062F \u0628\u06CC\u0645\u0627\u0631:" })] }), _jsxs("label", { className: "flex items-center gap-2 cursor-pointer text-xs font-semibold text-teal-900 bg-white px-2.5 py-1 rounded-xl border border-teal-300 hover:bg-teal-50 transition shadow-xs", children: [_jsx("input", { type: "checkbox", checked: regIsApproximateAge, onChange: (e) => {
                                                                        const checked = e.target.checked;
                                                                        setRegIsApproximateAge(checked);
                                                                        if (checked) {
                                                                            const calculated = calculateAgeFromJalali(regBirthDate);
                                                                            if (calculated !== undefined)
                                                                                setRegAge(String(calculated));
                                                                        }
                                                                        else {
                                                                            const ageNum = parseInt(regAge, 10);
                                                                            if (!isNaN(ageNum) && ageNum >= 0) {
                                                                                setRegBirthDate(calculateBirthYearFromAge(ageNum));
                                                                            }
                                                                        }
                                                                    }, className: "rounded text-teal-600 focus:ring-teal-500 w-4 h-4" }), _jsx("span", { children: "\u0633\u0646 \u062A\u0642\u0631\u06CC\u0628\u06CC (\u0648\u0631\u0648\u062F \u0645\u0633\u062A\u0642\u06CC\u0645 \u0639\u062F\u062F \u0633\u0646)" })] })] }), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3", children: [regIsApproximateAge ? (_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-bold text-slate-700 mb-1", children: "\u0633\u0646 \u062A\u0642\u0631\u06CC\u0628\u06CC \u0628\u06CC\u0645\u0627\u0631 (\u0633\u0627\u0644):" }), _jsxs("div", { className: "relative", children: [_jsx("input", { type: "number", min: 0, max: 120, placeholder: "\u0645\u062B\u0644\u0627\u064B \u06F3\u06F5", value: regAge, onChange: (e) => {
                                                                                const val = e.target.value;
                                                                                setRegAge(val);
                                                                                const num = parseInt(val, 10);
                                                                                if (!isNaN(num) && num >= 0) {
                                                                                    setRegBirthDate(calculateBirthYearFromAge(num));
                                                                                }
                                                                            }, className: "w-full text-sm border border-slate-300 rounded-lg p-2.5 font-bold font-mono text-slate-900 focus:ring-2 focus:ring-teal-500 bg-white" }), _jsx("span", { className: "absolute left-3 top-2.5 text-xs text-slate-500 font-bold", children: "\u0633\u0627\u0644" })] })] })) : (_jsxs("div", { children: [_jsx("label", { className: "block text-xs font-bold text-slate-700 mb-1", children: "\u062A\u0627\u0631\u06CC\u062E \u062A\u0648\u0644\u062F (\u0647\u062C\u0631\u06CC \u0634\u0645\u0633\u06CC):" }), _jsx("input", { type: "text", placeholder: "\u0645\u062B\u0644\u0627\u064B \u06F1\u06F3\u06F7\u06F0/\u06F0\u06F5/\u06F1\u06F2", value: regBirthDate, onChange: (e) => {
                                                                        const val = e.target.value;
                                                                        setRegBirthDate(val);
                                                                        const computedAge = calculateAgeFromJalali(val);
                                                                        if (computedAge !== undefined) {
                                                                            setRegAge(String(computedAge));
                                                                        }
                                                                    }, className: "w-full text-sm border border-slate-300 rounded-lg p-2.5 font-mono font-bold text-slate-900 focus:ring-2 focus:ring-teal-500 bg-white dir-ltr text-right" })] })), _jsx("div", { className: "flex flex-col justify-end", children: _jsxs("div", { className: "p-2.5 bg-white border border-teal-200/80 rounded-xl flex items-center justify-between text-xs text-slate-700 shadow-xs", children: [_jsx("span", { className: "text-slate-500 font-medium", children: "\u0633\u0646 \u062B\u0628\u062A\u200C\u0634\u062F\u0647:" }), _jsxs("span", { className: "font-bold font-mono text-sm text-teal-800", children: [regAge ? `${toPersianDigits(regAge)} سال` : 'نامشخص', regIsApproximateAge && regAge && _jsx("span", { className: "text-[10px] text-amber-600 mr-1 font-sans", children: "(\u062A\u0642\u0631\u06CC\u0628\u06CC)" })] })] }) })] })] })] }), hasModalSearchQuery && (_jsxs("div", { className: "bg-slate-900 text-slate-100 rounded-xl p-3.5 border border-slate-700 shadow-md space-y-2 mt-3 animate-in fade-in duration-150", children: [_jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-2 gap-1", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Search, { className: "w-4 h-4 text-teal-400 shrink-0" }), _jsxs("span", { className: "text-xs font-bold text-teal-300", children: ["\u0628\u06CC\u0645\u0627\u0631\u0627\u0646 \u0645\u0634\u0627\u0628\u0647 \u06CC\u0627\u0641\u062A\u200C\u0634\u062F\u0647 \u062F\u0631 \u0633\u06CC\u0633\u062A\u0645 (", toPersianDigits(modalMatchingPatients.length), " \u0645\u0648\u0631\u062F)"] })] }), _jsx("span", { className: "text-[10px] text-slate-400", children: "\u0628\u0627 \u062A\u0627\u06CC\u067E \u0628\u06CC\u0634\u062A\u0631 \u0639\u062F\u062F \u06A9\u062F \u0645\u0644\u06CC \u06CC\u0627 \u062D\u0631\u0648\u0641 \u0627\u0633\u0645\u060C \u0627\u06CC\u0646 \u0644\u06CC\u0633\u062A \u0641\u06CC\u0644\u062A\u0631 \u0634\u062F\u0647 \u0648 \u06A9\u0645\u062A\u0631 \u0645\u06CC\u200C\u0634\u0648\u062F." })] }), modalMatchingPatients.length > 0 ? (_jsx("div", { className: "max-h-48 overflow-y-auto divide-y divide-slate-800 rounded-lg bg-slate-950 p-1 custom-scrollbar", children: modalMatchingPatients.map((pat) => (_jsxs("div", { className: "p-2.5 hover:bg-slate-800 rounded-lg transition flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs", children: [_jsxs("div", { children: [_jsxs("div", { className: "font-bold text-white flex items-center gap-2", children: [_jsx("span", { children: pat.fullName }), _jsxs("span", { className: "text-[10px] bg-teal-900/80 text-teal-200 border border-teal-700/60 px-2 py-0.5 rounded font-mono", children: ["\u067E\u0631\u0648\u0646\u062F\u0647: ", pat.fileNumber] })] }), _jsxs("div", { className: "text-[11px] text-slate-400 flex flex-wrap items-center gap-3 mt-1", children: [pat.nationalId && (_jsxs("span", { children: ["\u06A9\u062F \u0645\u0644\u06CC: ", _jsx("strong", { className: "text-slate-200 font-mono", children: toPersianDigits(pat.nationalId) })] })), pat.mobilePhone && (_jsxs("span", { children: ["\u0647\u0645\u0631\u0627\u0647: ", _jsx("strong", { className: "text-slate-200 font-mono", children: toPersianDigits(pat.mobilePhone) })] })), pat.creditConfig?.currentDebt > 0 && (_jsx("span", { className: "text-[10px] bg-rose-900/80 text-rose-200 px-1.5 py-0.5 rounded font-bold", children: "\u0628\u062F\u0647\u06A9\u0627\u0631" }))] })] }), _jsxs("button", { type: "button", onClick: () => {
                                                            setSelectedPatient(pat);
                                                            setShowRegModal(false);
                                                            resetRegForm();
                                                        }, className: "bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-2 rounded-lg transition shadow flex items-center justify-center gap-1.5 shrink-0 min-h-[40px]", children: [_jsx(UserCheck, { className: "w-4 h-4" }), _jsx("span", { children: "\u0627\u0646\u062A\u062E\u0627\u0628 \u0648 \u0627\u062F\u0627\u0645\u0647 \u067E\u0630\u06CC\u0631\u0634" })] })] }, pat.id))) })) : (_jsx("div", { className: "p-3 text-center text-xs text-slate-400 bg-slate-950/60 rounded-lg border border-slate-800", children: "\u0647\u06CC\u0686 \u0628\u06CC\u0645\u0627\u0631 \u0645\u0634\u0627\u0628\u0647\u06CC \u0628\u0627 \u0627\u06CC\u0646 \u06A9\u062F \u0645\u0644\u06CC \u06CC\u0627 \u0646\u0627\u0645 \u062F\u0631 \u067E\u0631\u0648\u0646\u062F\u0647\u200C\u0647\u0627 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F. \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u06CC\u062F \u0641\u0631\u0645 \u0641\u0648\u0642 \u0631\u0627 \u062A\u06A9\u0645\u06CC\u0644 \u06A9\u0631\u062F\u0647 \u0648 \u062F\u06A9\u0645\u0647 \u00AB\u062B\u0628\u062A \u0628\u06CC\u0645\u0627\u0631 \u062C\u062F\u06CC\u062F \u0648 \u0627\u062F\u0627\u0645\u0647 \u067E\u0630\u06CC\u0631\u0634\u00BB \u0631\u0627 \u0628\u0632\u0646\u06CC\u062F." }))] })), _jsxs("div", { className: "pt-4 border-t border-slate-200 flex items-center justify-end gap-3", children: [_jsx("button", { type: "button", onClick: () => setShowRegModal(false), className: "px-4 py-2.5 border border-slate-300 text-slate-700 text-xs font-medium rounded-lg hover:bg-slate-100 transition min-h-[44px]", children: "\u0627\u0646\u0635\u0631\u0627\u0641" }), _jsxs("button", { type: "submit", className: "px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-lg transition shadow flex items-center gap-2 min-h-[44px]", children: [_jsx(UserPlus, { className: "w-4 h-4" }), _jsx("span", { children: "\u062B\u0628\u062A \u0628\u06CC\u0645\u0627\u0631 \u062C\u062F\u06CC\u062F \u0648 \u0627\u062F\u0627\u0645\u0647 \u067E\u0630\u06CC\u0631\u0634" })] })] })] })] }) })), showQuickSettleModal && selectedPatient && (_jsx("div", { className: "fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4", children: _jsxs("div", { className: "bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md p-6 space-y-4", children: [_jsxs("div", { className: "flex items-center justify-between border-b border-slate-100 pb-3", children: [_jsxs("h3", { className: "text-base font-bold text-slate-800 flex items-center gap-2", children: [_jsx(Coins, { className: "w-5 h-5 text-emerald-600" }), "\u062A\u0633\u0648\u06CC\u0647 \u0641\u0648\u0631\u06CC \u0628\u062F\u0647\u06CC \u0628\u06CC\u0645\u0627\u0631 ", selectedPatient.fullName] }), _jsx("button", { onClick: () => setShowQuickSettleModal(false), className: "text-slate-400 hover:text-slate-600 p-1 rounded-lg", children: _jsx(X, { className: "w-5 h-5" }) })] }), _jsxs("div", { className: "p-3 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs flex justify-between items-center", children: [_jsx("span", { children: "\u0645\u0627\u0646\u062F\u0647 \u0628\u062F\u0647\u06CC \u0641\u0639\u0644\u06CC:" }), _jsx("span", { className: "font-extrabold text-sm text-amber-800", children: formatCurrency(selectedPatient.creditConfig.currentDebt, settings.currencyUnit) })] }), _jsxs("div", { className: "space-y-3 text-xs", children: [_jsxs("div", { children: [_jsx("label", { className: "block font-semibold text-slate-700 mb-1", children: "\u0645\u0628\u0644\u063A \u062F\u0631\u06CC\u0627\u0641\u062A\u06CC \u062C\u0647\u062A \u062A\u0633\u0648\u06CC\u0647 (\u062A\u0648\u0645\u0627\u0646):" }), _jsx("input", { type: "number", value: settleAmount, onChange: (e) => setSettleAmount(Number(e.target.value)), className: "w-full p-2.5 text-sm border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500 font-bold" })] }), _jsxs("div", { children: [_jsx("label", { className: "block font-semibold text-slate-700 mb-1", children: "\u0631\u0648\u0634 \u067E\u0631\u062F\u0627\u062E\u062A:" }), _jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsxs("button", { type: "button", onClick: () => setSettleMethod('card'), className: `p-2.5 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-2 ${settleMethod === 'card'
                                                        ? 'bg-teal-50 border-teal-500 text-teal-800 shadow-sm'
                                                        : 'bg-slate-50 border-slate-200 text-slate-600'}`, children: [_jsx(CreditCard, { className: "w-4 h-4" }), "\u06A9\u0627\u0631\u062A\u062E\u0648\u0627\u0646 (POS)"] }), _jsxs("button", { type: "button", onClick: () => setSettleMethod('cash'), className: `p-2.5 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-2 ${settleMethod === 'cash'
                                                        ? 'bg-teal-50 border-teal-500 text-teal-800 shadow-sm'
                                                        : 'bg-slate-50 border-slate-200 text-slate-600'}`, children: [_jsx(DollarSign, { className: "w-4 h-4" }), "\u067E\u0631\u062F\u0627\u062E\u062A \u0646\u0642\u062F\u06CC"] })] })] }), settleMethod === 'card' && (_jsxs("div", { children: [_jsx("label", { className: "block font-semibold text-slate-700 mb-1", children: "\u0634\u0645\u0627\u0631\u0647 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u06A9\u0627\u0631\u062A\u062E\u0648\u0627\u0646 (RRN):" }), _jsx("input", { type: "text", placeholder: "\u0645\u062B\u0627\u0644: 98471203", value: settleRrn, onChange: (e) => setSettleRrn(e.target.value), className: "w-full p-2 text-xs border border-slate-300 rounded-xl dir-ltr text-right" })] }))] }), _jsxs("div", { className: "flex items-center justify-end gap-2 pt-3 border-t border-slate-100", children: [_jsx("button", { type: "button", onClick: () => setShowQuickSettleModal(false), className: "px-4 py-2 border border-slate-300 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50", children: "\u0627\u0646\u0635\u0631\u0627\u0641" }), _jsxs("button", { type: "button", onClick: () => {
                                        if (settleAmount <= 0) {
                                            alert('مبلغ وارد شده معتبر نیست.');
                                            return;
                                        }
                                        if (onSettleDebt) {
                                            onSettleDebt(selectedPatient.id, settleAmount, settleMethod, settleRrn);
                                        }
                                        const newDebt = Math.max(0, selectedPatient.creditConfig.currentDebt - settleAmount);
                                        const updatedPat = {
                                            ...selectedPatient,
                                            creditConfig: {
                                                ...selectedPatient.creditConfig,
                                                currentDebt: newDebt,
                                            },
                                        };
                                        onUpdatePatient(updatedPat);
                                        setSelectedPatient(updatedPat);
                                        setShowQuickSettleModal(false);
                                        alert(`تسویه بدهی بیمار ${selectedPatient.fullName} به مبلغ ${formatCurrency(settleAmount, settings.currencyUnit)} با موفقیت ثبت شد.`);
                                    }, className: "px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-1.5", children: [_jsx(CheckCircle2, { className: "w-4 h-4" }), "\u062A\u0627\u06CC\u06CC\u062F \u0648 \u062B\u0628\u062A \u062A\u0633\u0648\u06CC\u0647 \u0628\u062F\u0647\u06CC"] })] })] }) })), editingItem && (_jsx("div", { className: "fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4", children: _jsxs("div", { className: "bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 space-y-4 animate-in fade-in zoom-in duration-200", children: [_jsxs("div", { className: "flex items-center justify-between border-b border-slate-100 pb-3", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(Edit3, { className: "w-5 h-5 text-indigo-600" }), _jsxs("h3", { className: "text-base font-bold text-slate-800", children: ["\u0627\u0635\u0644\u0627\u062D \u0648 \u0648\u06CC\u0631\u0627\u06CC\u0634 \u0627\u0642\u0644\u0627\u0645 \u067E\u0631\u0648\u0646\u062F\u0647: ", editingItem.patientName, " (", editingItem.patientCode, ")"] })] }), _jsx("button", { onClick: () => setEditingItem(null), className: "text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100", children: _jsx(X, { className: "w-5 h-5" }) })] }), (editStatus === 'discharged' || editStatus === 'completed' || editingItem.status === 'discharged' || editingItem.status === 'completed') && (_jsxs("div", { className: "p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs", children: [_jsxs("div", { className: "flex items-center gap-2 text-rose-900 font-bold", children: [_jsx(AlertTriangle, { className: "w-5 h-5 text-rose-600 shrink-0" }), _jsx("span", { children: "\u0627\u06CC\u0646 \u0628\u06CC\u0645\u0627\u0631 \u062A\u0631\u062E\u06CC\u0635 \u0634\u062F\u0647 \u0627\u0633\u062A. \u062B\u0628\u062A\u060C \u062D\u0630\u0641 \u06CC\u0627 \u0648\u06CC\u0631\u0627\u06CC\u0634 \u062E\u062F\u0645\u0627\u062A \u0641\u0642\u0637 \u067E\u0633 \u0627\u0632 \u00AB\u0628\u0627\u0632\u06AF\u0631\u062F\u0627\u0646\u06CC \u0627\u0632 \u062A\u0631\u062E\u06CC\u0635\u00BB \u0627\u0645\u06A9\u0627\u0646\u200C\u067E\u0630\u06CC\u0631 \u0645\u06CC\u200C\u0628\u0627\u0634\u062F." })] }), _jsxs("button", { type: "button", onClick: () => {
                                        setEditStatus('ready_for_discharge');
                                        alert('وضعیت پرونده به «آماده ترخیص» تغییر یافت. اکنون می‌توانید خدمات را ویرایش، اضافه یا حذف نمایید.');
                                    }, className: "bg-amber-600 hover:bg-amber-700 text-white font-bold px-3 py-1.5 rounded-lg shrink-0 flex items-center gap-1 shadow-xs", children: [_jsx(RotateCcw, { className: "w-3.5 h-3.5" }), "\u0628\u0627\u0632\u06AF\u0631\u062F\u0627\u0646\u06CC \u0627\u0632 \u062A\u0631\u062E\u06CC\u0635 \u0648 \u0634\u0631\u0648\u0639 \u0648\u06CC\u0631\u0627\u06CC\u0634"] })] })), _jsxs("div", { className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs", children: [_jsxs("div", { children: [_jsx("label", { className: "block font-bold text-slate-700 mb-1", children: "\u067E\u0632\u0634\u06A9 \u0645\u0639\u0627\u0644\u062C:" }), _jsx("select", { value: editDoctorId, onChange: (e) => setEditDoctorId(e.target.value), className: "w-full p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500 font-medium", children: doctors.map((d) => (_jsxs("option", { value: d.id, children: [d.name, " - ", d.specialty] }, d.id))) })] }), _jsxs("div", { children: [_jsx("label", { className: "block font-bold text-slate-700 mb-1", children: "\u0645\u0631\u062D\u0644\u0647/\u0648\u0636\u0639\u06CC\u062A \u067E\u0631\u0648\u0646\u062F\u0647:" }), _jsxs("select", { value: editStatus, onChange: (e) => setEditStatus(e.target.value), className: "w-full p-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-teal-500 font-bold text-slate-800", children: [_jsx("option", { value: "waiting_doctor", children: "\u06F1. \u067E\u0630\u06CC\u0631\u0634 \u0634\u062F\u0647 (\u0645\u0646\u062A\u0638\u0631 \u0648\u06CC\u0632\u06CC\u062A)" }), _jsx("option", { value: "operating_room", children: "\u06F2. \u062F\u0631 \u0627\u062A\u0627\u0642 \u0639\u0645\u0644 / \u062C\u0631\u0627\u062D\u06CC" }), _jsx("option", { value: "ready_for_discharge", children: "\u06F3. \u0622\u0645\u0627\u062F\u0647 \u062A\u0631\u062E\u06CC\u0635 \u062F\u0631 \u0635\u0646\u062F\u0648\u0642" }), _jsx("option", { value: "completed", children: "\u062A\u06A9\u0645\u06CC\u0644 \u0648 \u062A\u0631\u062E\u06CC\u0635 \u0646\u0647\u0627\u06CC\u06CC" }), _jsx("option", { value: "cancelled", children: "\u0644\u063A\u0648 \u0634\u062F\u0647" })] })] })] }), _jsxs("div", { className: "space-y-2", children: [_jsx("label", { className: "block text-xs font-bold text-slate-700", children: "\u0644\u06CC\u0633\u062A \u062E\u062F\u0645\u0627\u062A \u0648 \u062A\u062C\u0647\u06CC\u0632\u0627\u062A \u0645\u0635\u0631\u0641\u06CC \u062B\u0628\u062A\u200C\u0634\u062F\u0647:" }), _jsx("div", { className: "border border-slate-200 rounded-xl divide-y divide-slate-100 max-h-48 overflow-y-auto bg-slate-50", children: editServices.length === 0 ? (_jsx("div", { className: "p-4 text-center text-xs text-slate-400", children: "\u0647\u06CC\u0686 \u062E\u062F\u0645\u062A \u06CC\u0627 \u0648\u0633\u06CC\u0644\u0647\u200C\u0627\u06CC \u0627\u0636\u0627\u0641\u0647 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." })) : (editServices.map((srv) => {
                                        const itemQty = srv.quantity || 1;
                                        return (_jsxs("div", { className: "p-2.5 flex items-center justify-between text-xs bg-white hover:bg-slate-50 transition-colors", children: [_jsxs("div", { className: "flex-1 min-w-0 pr-1", children: [_jsx("span", { className: "font-bold text-slate-800 block truncate", children: srv.title }), _jsx("span", { className: "text-[10px] text-slate-400 block", children: srv.category })] }), _jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [_jsxs("div", { className: "flex items-center gap-1 bg-slate-100 rounded-lg p-0.5 border border-slate-200", children: [_jsx("button", { type: "button", onClick: () => handleDecreaseServiceQty(srv.id), className: "w-5 h-5 flex items-center justify-center bg-white hover:bg-slate-200 active:scale-95 rounded text-slate-700 font-bold text-xs shadow-xs", title: "\u06A9\u0627\u0647\u0634 \u062A\u0639\u062F\u0627\u062F", children: "-" }), _jsx("span", { className: "px-1.5 font-mono text-xs font-bold text-slate-800", title: "\u062A\u0639\u062F\u0627\u062F", children: toPersianDigits(itemQty) }), _jsx("button", { type: "button", onClick: () => handleIncreaseServiceQty(srv.id), className: "w-5 h-5 flex items-center justify-center bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white rounded font-bold text-xs shadow-xs", title: "\u0627\u0641\u0632\u0627\u06CC\u0634 \u062A\u0639\u062F\u0627\u062F", children: "+" })] }), _jsxs("span", { className: "font-bold text-teal-700 font-mono text-[11px] min-w-[70px] text-left", children: [(srv.price ?? srv.tariffPrice ?? 0).toLocaleString('fa-IR'), " \u062A\u0648\u0645\u0627\u0646"] }), _jsx("button", { type: "button", onClick: () => handleRemoveServiceFromEdit(srv.id), className: "text-rose-500 hover:text-rose-700 p-1 hover:bg-rose-50 rounded", title: "\u062D\u0630\u0641 \u0627\u06CC\u0646 \u0622\u06CC\u062A\u0645", children: _jsx(Trash2, { className: "w-4 h-4" }) })] })] }, srv.id));
                                    })) })] }), _jsxs("div", { className: "p-3.5 bg-indigo-50/70 border border-indigo-200 rounded-2xl space-y-3 text-xs", children: [_jsx("span", { className: "font-bold text-indigo-950 block text-xs", children: "\u062C\u0633\u062A\u062C\u0648 \u0648 \u062B\u0628\u062A \u0622\u0646\u0644\u0627\u06CC\u0646 \u062E\u062F\u0645\u0627\u062A \u062F\u0631\u0645\u0627\u0646\u06CC \u06CC\u0627 \u0648\u0633\u0627\u06CC\u0644 \u0645\u0635\u0631\u0641\u06CC \u0627\u0646\u0628\u0627\u0631:" }), _jsx(SearchableItemSelector, { type: "service", items: searchableServicesForEdit, products: products, label: "\u06F1. \u062C\u0633\u062A\u062C\u0648 \u0648 \u0627\u0646\u062A\u062E\u0627\u0628 \u062E\u062F\u0645\u062A \u067E\u0632\u0634\u06A9\u06CC (\u062A\u0639\u0631\u0641\u0647):", placeholder: "\u0634\u0631\u0648\u0639 \u0628\u0647 \u062A\u0627\u06CC\u067E \u0627\u0633\u0645 \u06CC\u0627 \u06A9\u062F \u062E\u062F\u0645\u062A \u06CC\u0627 \u0627\u0633\u06A9\u0646 \u0628\u0627\u0631\u06A9\u062F...", onAddItem: handleAddServiceFromSearchToEdit }), _jsx(SearchableItemSelector, { type: "consumable", items: searchableProductsForEdit, products: products, label: "\u06F2. \u062C\u0633\u062A\u062C\u0648 \u0648 \u0627\u0646\u062A\u062E\u0627\u0628 \u0648\u0633\u0627\u06CC\u0644 \u0645\u0635\u0631\u0641\u06CC \u0648 \u062A\u062C\u0647\u06CC\u0632\u0627\u062A:", placeholder: "\u0634\u0631\u0648\u0639 \u0628\u0647 \u062A\u0627\u06CC\u067E \u0627\u0633\u0645 \u06CC\u0627 \u06A9\u062F \u0648\u0633\u06CC\u0644\u0647 \u0645\u0635\u0631\u0641\u06CC \u06CC\u0627 \u0627\u0633\u06A9\u0646 \u0628\u0627\u0631\u06A9\u062F...", onAddItem: handleAddProductFromSearchToEdit })] }), _jsxs("div", { className: "space-y-2 text-xs", children: [_jsxs("div", { children: [_jsx("label", { className: "block font-bold text-slate-700 mb-1", children: "\u062A\u0634\u062E\u06CC\u0635 \u0648 \u062A\u0648\u0636\u06CC\u062D\u0627\u062A \u062F\u0631\u0645\u0627\u0646:" }), _jsx("input", { type: "text", value: editDiagnosis, onChange: (e) => setEditDiagnosis(e.target.value), placeholder: "\u0645\u062B\u0627\u0644: \u062C\u0631\u0627\u062D\u06CC \u062A\u0631\u0645\u06CC\u0645\u06CC / \u062A\u0632\u0631\u06CC\u0642 \u0698\u0644", className: "w-full p-2 border border-slate-300 rounded-xl" })] }), _jsxs("div", { children: [_jsx("label", { className: "block font-bold text-slate-700 mb-1", children: "\u06CC\u0627\u062F\u062F\u0627\u0634\u062A \u062F\u0627\u062E\u0644\u06CC \u0645\u0646\u0634\u06CC / \u067E\u0632\u0634\u06A9:" }), _jsx("textarea", { rows: 2, value: editNotes, onChange: (e) => setEditNotes(e.target.value), className: "w-full p-2 border border-slate-300 rounded-xl" })] })] }), (() => {
                            const newTotal = editServices.reduce((sum, s) => sum + (s.price ?? s.tariffPrice ?? 0), 0);
                            const previousPaid = editingItem.paidAmount || 0;
                            const diff = newTotal - previousPaid;
                            return (_jsxs("div", { className: "p-3.5 bg-slate-900 text-white rounded-xl space-y-2 text-xs border border-slate-800 shadow-inner", children: [_jsxs("div", { className: "flex items-center justify-between", children: [_jsx("span", { className: "text-slate-300 font-medium", children: "\u0645\u0628\u0644\u063A \u06A9\u0644 \u062F\u0631\u06CC\u0627\u0641\u062A\u06CC \u0642\u0628\u0644\u06CC \u0628\u06CC\u0645\u0627\u0631:" }), _jsxs("span", { className: "font-mono text-amber-300 font-bold", children: [previousPaid.toLocaleString('fa-IR'), " \u062A\u0648\u0645\u0627\u0646"] })] }), _jsxs("div", { className: "flex items-center justify-between", children: [_jsx("span", { className: "text-slate-300 font-medium", children: "\u0645\u0628\u0644\u063A \u062C\u062F\u06CC\u062F \u06A9\u0644 \u062E\u062F\u0645\u0627\u062A \u067E\u0633 \u0627\u0632 \u0648\u06CC\u0631\u0627\u06CC\u0634:" }), _jsxs("span", { className: "font-mono text-cyan-300 font-bold", children: [newTotal.toLocaleString('fa-IR'), " \u062A\u0648\u0645\u0627\u0646"] })] }), _jsxs("div", { className: "pt-2 border-t border-slate-800 flex items-center justify-between font-bold", children: [_jsx("span", { children: "\u0648\u0636\u0639\u06CC\u062A \u0645\u0627\u0644\u06CC \u0645\u062D\u0627\u0633\u0628\u0647\u200C\u0634\u062F\u0647 \u0628\u06CC\u0645\u0627\u0631:" }), diff > 0 ? (_jsxs("span", { className: "text-rose-300 bg-rose-950/90 px-3 py-1 rounded-lg border border-rose-800 flex items-center gap-1.5 font-bold", children: [_jsx(AlertTriangle, { className: "w-4 h-4 text-rose-400" }), "\u0628\u062F\u0647\u06A9\u0627\u0631 \u0628\u0647 \u0645\u0628\u0644\u063A ", diff.toLocaleString('fa-IR'), " \u062A\u0648\u0645\u0627\u0646 (\u062F\u0631\u06CC\u0627\u0641\u062A \u0645\u0627\u0628\u0647\u200C\u0627\u0644\u062A\u0641\u0627\u0648\u062A \u062F\u0631 \u0635\u0646\u062F\u0648\u0642)"] })) : diff < 0 ? (_jsxs("span", { className: "text-emerald-300 bg-emerald-950/90 px-3 py-1 rounded-lg border border-emerald-800 flex items-center gap-1.5 font-bold", children: [_jsx(Coins, { className: "w-4 h-4 text-emerald-400" }), "\u0628\u0633\u062A\u0627\u0646\u06A9\u0627\u0631 \u0628\u0647 \u0645\u0628\u0644\u063A ", Math.abs(diff).toLocaleString('fa-IR'), " \u062A\u0648\u0645\u0627\u0646 (\u0627\u0636\u0627\u0641\u0647 \u062F\u0631\u06CC\u0627\u0641\u062A\u06CC - \u0639\u0648\u062F\u062A \u06CC\u0627 \u0630\u062E\u06CC\u0631\u0647)"] })) : (_jsx("span", { className: "text-blue-300 bg-blue-950/90 px-3 py-1 rounded-lg border border-blue-800 font-bold", children: "\u062A\u0633\u0648\u06CC\u0647 \u06A9\u0627\u0645\u0644 (\u0628\u062F\u0648\u0646 \u0628\u062F\u0647\u06CC/\u0628\u0633\u062A\u0627\u0646\u06A9\u0627\u0631\u06CC)" }))] })] }));
                        })(), _jsxs("div", { className: "flex items-center justify-end gap-2 pt-3 border-t border-slate-100", children: [_jsx("button", { type: "button", onClick: () => setEditingItem(null), className: "px-4 py-2.5 border border-slate-300 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50", children: "\u0627\u0646\u0635\u0631\u0627\u0641" }), _jsxs("button", { type: "button", onClick: handleSaveVisitEdits, className: "px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md transition flex items-center gap-1.5", children: [_jsx(CheckCircle2, { className: "w-4 h-4" }), "\u0630\u062E\u06CC\u0631\u0647 \u0627\u0635\u0644\u0627\u062D\u0627\u062A \u067E\u0631\u0648\u0646\u062F\u0647"] })] })] }) })), dischargingItem && (_jsx("div", { className: "fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4", children: _jsxs("div", { className: "bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg p-6 space-y-4 animate-in fade-in zoom-in duration-200", children: [_jsxs("div", { className: "flex items-center justify-between border-b border-slate-100 pb-3", children: [_jsxs("div", { className: "flex items-center gap-2", children: [_jsx(CreditCard, { className: "w-5 h-5 text-emerald-600" }), _jsxs("h3", { className: "text-base font-bold text-slate-800", children: ["\u0635\u0646\u062F\u0648\u0642 \u0648 \u062A\u0631\u062E\u06CC\u0635 \u0646\u0647\u0627\u06CC\u06CC: ", dischargingItem.patientName] })] }), _jsx("button", { onClick: () => setDischargingItem(null), className: "text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100", children: _jsx(X, { className: "w-5 h-5" }) })] }), _jsxs("div", { className: "space-y-2 text-xs", children: [_jsxs("div", { className: "flex items-center justify-between font-bold text-slate-700", children: [_jsx("span", { children: "\u0631\u06CC\u0632 \u0627\u0642\u0644\u0627\u0645 \u0648 \u062E\u062F\u0645\u0627\u062A \u0627\u0631\u0627\u0626\u0647 \u0634\u062F\u0647:" }), _jsxs("button", { type: "button", onClick: () => {
                                                const item = dischargingItem;
                                                setDischargingItem(null);
                                                handleOpenEditModal(item);
                                            }, className: "text-indigo-600 hover:underline text-[11px] font-bold flex items-center gap-1", children: [_jsx(Edit3, { className: "w-3.5 h-3.5" }), "\u0627\u0635\u0644\u0627\u062D \u06A9\u0645 \u0648 \u06A9\u0633\u0631 \u0627\u0642\u0644\u0627\u0645 \u0642\u0628\u0644 \u062A\u0631\u062E\u06CC\u0635"] })] }), _jsx("div", { className: "border border-slate-200 rounded-xl divide-y divide-slate-100 bg-slate-50 max-h-40 overflow-y-auto", children: dischargingItem.services.map((srv) => (_jsxs("div", { className: "p-2.5 flex justify-between items-center bg-white", children: [_jsx("span", { className: "font-medium text-slate-800", children: srv.title }), _jsxs("span", { className: "font-bold text-teal-700", children: [(srv.price ?? srv.tariffPrice ?? 0).toLocaleString('fa-IR'), " \u062A\u0648\u0645\u0627\u0646"] })] }, srv.id))) })] }), _jsxs("div", { className: "p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs font-extrabold text-emerald-900", children: [_jsx("span", { children: "\u0645\u0628\u0644\u063A \u06A9\u0644 \u0642\u0627\u0628\u0644 \u067E\u0631\u062F\u0627\u062E\u062A:" }), _jsxs("span", { className: "text-lg text-emerald-700", children: [(dischargingItem.totalCost ?? 0).toLocaleString('fa-IR'), " \u062A\u0648\u0645\u0627\u0646"] })] }), _jsxs("div", { className: "space-y-2 text-xs", children: [_jsx("label", { className: "block font-bold text-slate-700", children: "\u0631\u0648\u0634 \u067E\u0631\u062F\u0627\u062E\u062A \u0648 \u062A\u0633\u0648\u06CC\u0647:" }), _jsxs("div", { className: "grid grid-cols-2 gap-2", children: [_jsxs("button", { type: "button", onClick: () => setDischargePayMethod('card'), className: `p-2.5 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-2 ${dischargePayMethod === 'card'
                                                ? 'bg-teal-50 border-teal-500 text-teal-800 shadow-sm'
                                                : 'bg-slate-50 border-slate-200 text-slate-600'}`, children: [_jsx(CreditCard, { className: "w-4 h-4" }), "\u06A9\u0627\u0631\u062A\u062E\u0648\u0627\u0646 (POS)"] }), _jsxs("button", { type: "button", onClick: () => setDischargePayMethod('cash'), className: `p-2.5 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-2 ${dischargePayMethod === 'cash'
                                                ? 'bg-teal-50 border-teal-500 text-teal-800 shadow-sm'
                                                : 'bg-slate-50 border-slate-200 text-slate-600'}`, children: [_jsx(DollarSign, { className: "w-4 h-4" }), "\u067E\u0631\u062F\u0627\u062E\u062A \u0646\u0642\u062F\u06CC"] })] }), dischargePayMethod === 'card' && (_jsxs("div", { children: [_jsx("label", { className: "block font-semibold text-slate-700 mb-1", children: "\u0634\u0645\u0627\u0631\u0647 \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u062A\u0631\u0627\u06A9\u0646\u0634 (RRN):" }), _jsx("input", { type: "text", placeholder: "\u0645\u062B\u0627\u0644: 98124012", value: dischargeRrn, onChange: (e) => setDischargeRrn(e.target.value), className: "w-full p-2.5 border border-slate-300 rounded-xl dir-ltr text-right" })] }))] }), _jsxs("div", { className: "flex flex-col sm:flex-row items-center justify-end gap-2 pt-3 border-t border-slate-100", children: [_jsx("button", { type: "button", onClick: () => setDischargingItem(null), className: "w-full sm:w-auto px-4 py-2.5 border border-slate-300 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50", children: "\u0627\u0646\u0635\u0631\u0627\u0641" }), _jsxs("button", { type: "button", onClick: () => handleConfirmDischarge(false), className: "w-full sm:w-auto px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5", children: [_jsx(ShieldCheck, { className: "w-4 h-4 text-emerald-600" }), "\u062A\u0627\u06CC\u06CC\u062F \u062A\u0631\u062E\u06CC\u0635 (\u0628\u062F\u0648\u0646 \u0686\u0627\u067E \u0641\u0627\u06A9\u062A\u0648\u0631)"] }), _jsxs("button", { type: "button", onClick: () => handleConfirmDischarge(true), className: "w-full sm:w-auto px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-extrabold shadow-md transition flex items-center justify-center gap-1.5", children: [_jsx(Printer, { className: "w-4 h-4" }), "\u062A\u0627\u06CC\u06CC\u062F \u062A\u0633\u0648\u06CC\u0647 + \u0686\u0627\u067E \u0641\u0627\u06A9\u062A\u0648\u0631 (\u062D\u0631\u0627\u0631\u062A\u06CC / A4 / A5)"] })] })] }) })), settlementInvoiceItem && (_jsx(PatientSettlementInvoiceModal, { item: settlementInvoiceItem, settings: settings, currentUser: currentUser, onClose: () => setSettlementInvoiceItem(null) })), smsPatientItem && (_jsx(PatientSmsModal, { item: smsPatientItem, settings: settings, onClose: () => setSmsPatientItem(null) })), showSalamatModal && (_jsx(SalamatInsuranceModal, { isOpen: showSalamatModal, onClose: () => setShowSalamatModal(false), patient: selectedPatient, onSavePatientInsurance: handleSavePatientInsurance }))] }));
};
