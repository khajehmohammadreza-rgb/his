/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { NumberInput } from './NumberInput.js';
export { NumberInput };
export const CurrencyInput = NumberInput;
