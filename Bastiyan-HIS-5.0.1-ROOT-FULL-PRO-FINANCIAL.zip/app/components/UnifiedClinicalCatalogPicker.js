import React, { useEffect, useMemo, useRef, useState } from '../../vendor/react.js';
import { Search, X, Stethoscope, Package, Activity, Building2, CheckCircle2, Camera } from '../../vendor/lucide-react.js';
import { classifyService, catalogLabel } from '../utils/unifiedClinicalCatalog.js';
import { BarcodeCameraScanner } from './BarcodeCameraScanner.js?v=424';

const h = React.createElement;
const norm = (v) => String(v ?? '').toLowerCase().replace(/ي/g,'ی').replace(/ك/g,'ک').replace(/\s+/g,' ').trim();
const digits = (v) => String(v ?? '').replace(/[^0-9]/g,'');
const money = (v) => `${Number(v || 0).toLocaleString('fa-IR')} تومان`;

export function UnifiedClinicalCatalogPicker({ open=false, medicalServices=[], products=[], onSelect, onClose, allowedTypes=['visit','outpatient','hospital','product'], title='فهرست یکپارچه خدمات و کالا' }) {
  const [tab,setTab] = useState('all');
  const [query,setQuery] = useState('');
  const [scannerOpen,setScannerOpen] = useState(false);
  const [scanMessage,setScanMessage] = useState('');
  const inputRef = useRef(null);
  useEffect(() => {
    if (!open) return undefined;
    const first = allowedTypes.length===1 ? allowedTypes[0] : 'all';
    setTab(first); setQuery(''); setScannerOpen(false); setScanMessage('');
    const prev = document.body.style.overflow; document.body.style.overflow='hidden';
    const t=setTimeout(()=>inputRef.current?.focus(),30);
    const key=(e)=>{ if(e.key==='Escape'&&!scannerOpen) onClose?.(); };
    window.addEventListener('keydown',key);
    return ()=>{clearTimeout(t);window.removeEventListener('keydown',key);document.body.style.overflow=prev;};
  },[open]);
  const allRows = useMemo(() => {
    const list=[];
    for (const s of medicalServices || []) {
      if (!s || s.active === false) continue;
      const type=classifyService(s); if (!allowedTypes.includes(type)) continue;
      list.push({kind:'service',type,item:s,title:s.title||s.name||'خدمت',code:s.code||s.serviceCode||s.id||'',price:Number(s.tariffPrice??s.price??0)||0,stock:null});
    }
    if (allowedTypes.includes('product')) for (const p of products || []) {
      if (!p || p.active === false) continue;
      list.push({kind:'product',type:'product',item:p,title:p.name||p.title||'کالا',code:p.code||p.productCode||p.barcode||p.id||'',price:Number(p.salesPrice??p.price??p.unitPrice??0)||0,stock:Number(p.stockQuantity??p.stock??0)});
    }
    return list;
  },[medicalServices,products,allowedTypes]);
  const rows = useMemo(() => {
    const q=norm(query),qd=digits(query);
    const hasIntent=Boolean(q)||tab!=='all';
    if(!hasIntent)return [];
    return allRows.filter(r => tab==='all' || r.type===tab).filter(r => {
      if(!q)return true;
      const text=norm(`${r.title} ${r.code} ${r.item?.barcode||''} ${r.item?.category||''} ${r.item?.genericName||''} ${r.item?.brand||''} ${r.item?.unit||''}`);
      return text.includes(q)||(qd&&digits(`${r.code} ${r.item?.barcode||''}`).includes(qd));
    }).slice(0,500);
  },[allRows,tab,query]);
  if(!open) return null;
  const tabs=[['all','همه'],['visit','ویزیت'],['outpatient','سرپایی مرکز'],['hospital','بیمارستان / گنجی'],['product','کالا و دارو']].filter(([id])=>id==='all'||allowedTypes.includes(id));
  const icon=(type)=> type==='product'?Package:type==='hospital'?Building2:type==='outpatient'?Activity:Stethoscope;
  const handleBarcode=(raw)=>{
    const code=String(raw||'').trim(); setScannerOpen(false); if(!code)return;
    const match=allRows.find(r=>r.kind==='product'&&String(r.item?.barcode||r.code||'').trim()===code);
    if(match){setScanMessage(`شناسایی شد: ${match.title}`);onSelect?.(match);return;}
    setTab('product');setQuery(code);setScanMessage('بارکد خوانده شد اما کالای منطبق در فهرست فعال مرکز پیدا نشد.');
  };
  const productAvailable=allowedTypes.includes('product');
  return h('div',{className:'bhis-picker-overlay',dir:'rtl',role:'dialog','aria-modal':'true'},
    h('div',{className:'bhis-picker-panel bhis-unified-picker','data-testid':'unified-catalog-picker'},
      h('header',{className:'bhis-picker-header'},h('div',{className:'bhis-picker-kind'},h(Stethoscope,{className:'w-5 h-5'})),h('div',{className:'bhis-picker-heading'},h('h2',null,title),h('p',null,'جستجوی آنی بر اساس نام، کد، دسته و بارکد؛ یک کاتالوگ مشترک برای تمام نقش‌ها.')),h('button',{type:'button',onClick:onClose,className:'bhis-icon-button'},h(X,{className:'w-5 h-5'}))),
      h('div',{className:'bhis-picker-toolbar'},
        h('div',{className:'bhis-picker-searchbar'},h(Search,{className:'w-5 h-5'}),h('input',{'data-testid':'catalog-search',ref:inputRef,value:query,onChange:e=>{setQuery(e.target.value);setScanMessage('');},placeholder:tab==='product'?'نام کالا/دارو، کد یا بارکد...':'نام یا کد خدمت را تایپ کنید...',autoComplete:'off'}),query?h('button',{type:'button',onClick:()=>setQuery(''),className:'bhis-clear-search'},h(X,{className:'w-4 h-4'})):null),
        productAvailable?h('button',{type:'button','data-testid':'camera-barcode-button',className:'bhis-camera-scan-button',onClick:()=>{setTab('product');setScannerOpen(true);}},h(Camera,{className:'w-4 h-4'}),h('span',null,'اسکن بارکد با دوربین')):null
      ),
      scanMessage?h('div',{className:'bhis-picker-scan-message'},scanMessage):null,
      h('div',{className:'bhis-picker-categories'},...tabs.map(([id,label])=>h('button',{key:id,type:'button',className:tab===id?'active':'',onClick:()=>{setTab(id);setScanMessage('');}},label))),
      h('div',{className:'bhis-picker-result-meta'},h('span',null,`${rows.length.toLocaleString('fa-IR')} مورد قابل انتخاب`),h('span',null,tab==='product'?'موجودی، قیمت و بارکد در یک ردیف':'نتایج همزمان با تایپ به‌روزرسانی می‌شوند')),
      h('div',{'data-testid':'catalog-results',className:'bhis-picker-results'},rows.length===0?h('div',{className:'bhis-picker-empty'},h(Search,{className:'w-8 h-8'}),h('strong',null,'موردی پیدا نشد'),h('span',null,query?'عبارت جستجو یا بارکد را بررسی کنید.':tab==='all'?'نام، کد یا بارکد را تایپ کنید؛ یا یکی از دسته‌ها را انتخاب کنید.':'برای این دسته مورد فعالی وجود ندارد.')):rows.map((r,i)=>{const Icon=icon(r.type);return h('button',{key:`${r.kind}-${r.item.id||i}`,type:'button',className:'bhis-picker-row',onClick:()=>onSelect?.(r)},h('span',{className:`bhis-picker-row-icon ${r.kind==='product'?'product':'service'}`},h(Icon,{className:'w-4 h-4'})),h('span',{className:'bhis-picker-row-main'},h('strong',null,r.title),h('span',{className:'bhis-picker-row-sub'},h('em',null,catalogLabel(r.type)),r.code?h('em',null,`کد: ${r.code}`):null,r.item?.barcode?h('em',{className:'barcode'},`بارکد: ${r.item.barcode}`):null,r.item?.unit?h('em',null,`واحد: ${r.item.unit}`):null)),h('span',{className:'bhis-picker-row-aside'},r.type==='product'?h('span',{className:`bhis-stock ${r.stock<=0?'empty':r.stock<=5?'low':''}`},`موجودی ${Number(r.stock||0).toLocaleString('fa-IR')}`):null,h('strong',null,money(r.price)),h('span',{className:'bhis-select-mark'},h(CheckCircle2,{className:'w-3.5 h-3.5'}),'انتخاب')));}))
    ),
    h(BarcodeCameraScanner,{open:scannerOpen,onDetected:handleBarcode,onClose:()=>setScannerOpen(false)})
  );
}
