import React, { useMemo, useState } from '../../vendor/react.js';
import { UnifiedClinicalCatalogPicker } from './UnifiedClinicalCatalogPicker.js?v=424';
import {
  moveQueueItem, getUserDisplayName, userHasRole, calculateServiceCommission,
  calculateProductProfitCommission,
} from '../utils/clinicalWorkflow.js';
import {
  Search, User as UserRound, FileCheck as ClipboardCheck, CheckCircle2, Plus, Package, Stethoscope, AlertTriangle, Trash2, PackageMinus as Minus, Activity, Save, ChevronLeft, History, Clock as Clock3, Package as Boxes, Barcode as ScanLine, ChevronRight as ArrowRight
} from '../../vendor/lucide-react.js';

const h = React.createElement;
const nurseStatuses = new Set(['waiting_nurse', 'nursing_in_progress']);
const norm = (v) => String(v || '').toLowerCase().replace(/ي/g, 'ی').replace(/ك/g, 'ک').trim();
const money = (v) => `${Number(v || 0).toLocaleString('fa-IR')} تومان`;

function enrichUsers(users = [], staffAccounts = []) {
  const accounts = new Map((staffAccounts || []).map((a) => [a.userId, a]));
  return (users || []).map((u) => ({ ...u, financialAccount: accounts.get(u.id) || null }));
}
function lineTotal(x) { return Number(x?.unitPrice ?? x?.price ?? 0) * Math.max(1, Number(x?.quantity || 1)); }
function recompute(item, services, products) {
  const totalCost = [...services, ...products].reduce((s, x) => s + lineTotal(x), 0);
  return { ...item, services, products, totalCost, remainingDebt: Math.max(0, totalCost - Number(item.paidAmount || 0)) };
}

export function ProfessionalNurseWorkspace({
  visitQueue = [], users = [], staffAccounts = [], medicalServices = [], products = [], patients = [], currentUser,
  onUpdateQueueItem, onOpenPatientProfile,
}) {
  const enrichedUsers = useMemo(() => enrichUsers(users, staffAccounts), [users, staffAccounts]);
  const currentStaff = enrichedUsers.find((u) => u.id === currentUser?.id) || currentUser || {};
  const queue = useMemo(() => (visitQueue || []).filter((q) => nurseStatuses.has(q.status)).sort((a, b) => new Date(a.registeredAt || 0) - new Date(b.registeredAt || 0)), [visitQueue]);
  const [activeId, setActiveId] = useState('');
  const [queueQuery, setQueueQuery] = useState('');
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pendingItem, setPendingItem] = useState(null);
  const [pendingKind, setPendingKind] = useState('service');
  const [quantity, setQuantity] = useState(1);
  const [executionNotes, setExecutionNotes] = useState('');
  const active = queue.find((q) => q.id === activeId) || null;
  const patient = active ? (patients || []).find((p) => p.id === active.patientId) : null;

  const filteredQueue = useMemo(() => {
    const q = norm(queueQuery); if (!q) return queue;
    return queue.filter((x) => norm(`${x.patientName} ${x.patientCode} ${x.nationalId} ${x.turnNumber}`).includes(q));
  }, [queue, queueQuery]);

  const openPatient = (item) => {
    setActiveId(item.id);
    setExecutionNotes(item.nursingExecutionNotes || '');
    setPendingItem(null);
    if (item.status === 'waiting_nurse') onUpdateQueueItem?.(moveQueueItem(item, 'nursing_in_progress', 'پرستار/دستیار پرونده را از صف خدمات باز کرد', currentUser));
  };
  const baseNow = () => (visitQueue || []).find((q) => q.id === activeId) || active;
  const serviceById = (id) => (medicalServices || []).find((s) => String(s.id) === String(id));
  const productById = (id) => (products || []).find((p) => String(p.id) === String(id));

  const commit = (next, action = 'بروزرسانی اجرای خدمات') => {
    const base = baseNow(); if (!base) return;
    onUpdateQueueItem?.({ ...next, nursingExecutionNotes: executionNotes, lastNursingEditAt: new Date().toISOString(), lastNursingAction: action });
  };

  const executeOrder = (order) => {
    const base = baseNow(); if (!base) return;
    if ((base.services || []).some((x) => x.orderId === order.id)) return;
    const source = serviceById(order.serviceId);
    if (!source) { alert(`خدمت «${order.title}» در کاتالوگ فعال مرکز پیدا نشد.`); return; }
    const qty = 1;
    const unit = Number(source.tariffPrice ?? source.price ?? 0) || 0;
    const doctor = enrichedUsers.find((u) => u.id === base.doctorId) || { id: base.doctorId, name: base.doctorName };
    const commission = calculateServiceCommission(source, qty, doctor, currentStaff);
    const line = {
      id: `svc-${order.id}`,
      orderId: order.id,
      serviceId: source.id,
      title: source.title || source.name,
      category: source.category || order.category || '',
      quantity: qty, unitPrice: unit, price: unit * qty,
      status: 'performed_by_nurse',
      doctorId: base.doctorId || '', doctorName: base.doctorName || '',
      assistantId: currentStaff?.id || '', assistantName: getUserDisplayName(currentStaff),
      performedAt: new Date().toISOString(), performedByAssistantId: currentStaff?.id || '',
      ...commission,
    };
    const services = [...(base.services || []), line];
    const clinicalOrders = (base.clinicalOrders || []).map((o) => o.id === order.id ? { ...o, status: 'executed', executedAt: new Date().toISOString(), executedById: currentStaff?.id || '', executedByName: getUserDisplayName(currentStaff) } : o);
    commit({ ...recompute(base, services, base.products || []), clinicalOrders }, `اجرای دستور ${order.title}`);
  };

  const undoExecutedOrder = (order) => {
    const base = baseNow(); if (!base) return;
    const services = (base.services || []).filter((x) => x.orderId !== order.id);
    const clinicalOrders = (base.clinicalOrders || []).map((o) => o.id === order.id ? { ...o, status: 'ordered', executedAt: null, executedById: '', executedByName: '' } : o);
    commit({ ...recompute(base, services, base.products || []), clinicalOrders }, `لغو اجرای دستور ${order.title}`);
  };

  const pickCatalog = (row) => {
    setPickerOpen(false);
    setPendingKind(row.kind);
    setPendingItem(row.item);
    setQuantity(1);
  };
  const confirmAdditional = () => {
    const base = baseNow(); if (!base || !pendingItem) return;
    const qty = Math.max(1, Number(quantity || 1));
    if (pendingKind === 'service') {
      const source = pendingItem;
      const unit = Number(source.tariffPrice ?? source.price ?? 0) || 0;
      const doctor = enrichedUsers.find((u) => u.id === base.doctorId) || { id: base.doctorId, name: base.doctorName };
      const commission = calculateServiceCommission(source, qty, doctor, currentStaff);
      const line = {
        id: `svc-extra-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, serviceId: source.id,
        title: source.title || source.name, category: source.category || '', quantity: qty, unitPrice: unit, price: unit * qty,
        status: 'performed_by_nurse', addedByNurse: true, doctorId: base.doctorId || '', doctorName: base.doctorName || '',
        assistantId: currentStaff?.id || '', assistantName: getUserDisplayName(currentStaff), performedAt: new Date().toISOString(), ...commission,
      };
      commit(recompute(base, [...(base.services || []), line], base.products || []), `افزودن خدمت اجرایی ${line.title}`);
    } else {
      const source = pendingItem;
      const unit = Number(source.salesPrice ?? source.price ?? source.purchasePrice ?? 0) || 0;
      const commission = calculateProductProfitCommission(source, qty, currentStaff);
      const line = {
        id: `prd-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, productId: source.id,
        title: source.name || source.title, category: source.category || 'consumable', quantity: qty, unitPrice: unit, price: unit * qty,
        purchaseUnitPrice: Number(source.purchasePrice ?? source.costPrice ?? 0) || 0,
        itemType: 'product', status: 'used', unit: source.unit || 'عدد', barcode: source.barcode || '',
        performedAt: new Date().toISOString(), addedByNurse: true, ...commission,
      };
      commit(recompute(base, base.services || [], [...(base.products || []), line]), `ثبت کالای مصرفی ${line.title}`);
    }
    setPendingItem(null); setQuantity(1);
  };

  const removeLine = (kind, line) => {
    const base = baseNow(); if (!base) return;
    if (kind === 'service') {
      const services = (base.services || []).filter((x) => x.id !== line.id);
      let clinicalOrders = base.clinicalOrders || [];
      if (line.orderId) clinicalOrders = clinicalOrders.map((o) => o.id === line.orderId ? { ...o, status: 'ordered', executedAt: null } : o);
      commit({ ...recompute(base, services, base.products || []), clinicalOrders }, `حذف خدمت ${line.title}`);
    } else {
      commit(recompute(base, base.services || [], (base.products || []).filter((x) => x.id !== line.id)), `حذف کالا ${line.title}`);
    }
  };

  const finish = () => {
    const base = baseNow(); if (!base) return;
    const pendingToday = (base.clinicalOrders || []).filter((o) => o.target === 'center' && o.timing !== 'future' && o.status === 'ordered');
    if (pendingToday.length) {
      if (!confirm(`${pendingToday.length.toLocaleString('fa-IR')} دستور امروز هنوز اجرا نشده است. با این حال بیمار به صندوق منتقل شود؟`)) return;
    }
    onUpdateQueueItem?.(moveQueueItem(base, 'ready_for_discharge', 'خدمات اجرایی تکمیل و بیمار به صندوق/ترخیص منتقل شد', currentUser, { nursingExecutionNotes: executionNotes, nursingCompletedAt: new Date().toISOString() }));
    setActiveId('');
  };

  const orders = active ? (active.clinicalOrders || []).filter((o) => o.target === 'center' && o.timing !== 'future' && o.status !== 'cancelled') : [];
  const total = active ? [...(active.services || []), ...(active.products || [])].reduce((s, x) => s + lineTotal(x), 0) : 0;
  const debt = Number(patient?.creditConfig?.currentDebt || 0);

  return h('div', { className: 'bhis-role-workspace bhis-nurse-workspace', dir: 'rtl' },
    h('aside', { className: 'bhis-worklist' },
      h('div', { className: 'bhis-worklist-header' }, h('div', null, h('span', { className: 'bhis-eyebrow' }, 'صف خدمات پرستاری'), h('h2', null, 'خدمات در انتظار اجرا'), h('p', null, 'دستور پزشک و خدمات سرپایی امروز')), h('span', { className: 'bhis-worklist-count' }, queue.length.toLocaleString('fa-IR'))),
      h('label', { className: 'bhis-worklist-search' }, h(Search, { className: 'w-4 h-4' }), h('input', { value: queueQuery, onChange: (e) => setQueueQuery(e.target.value), placeholder: 'جستجوی بیمار...' })),
      h('div', { className: 'bhis-worklist-scroll' }, filteredQueue.length === 0 ? h('div', { className: 'bhis-worklist-empty' }, 'بیماری در صف خدمات پرستاری نیست.') : filteredQueue.map((item) => h('button', { key: item.id, type: 'button', onClick: () => openPatient(item), className: `bhis-patient-row ${activeId === item.id ? 'active' : ''}` },
        h('span', { className: 'bhis-patient-avatar nurse' }, h(Activity, { className: 'w-4 h-4' })),
        h('span', { className: 'bhis-patient-row-main' }, h('strong', null, item.patientName), h('small', null, `${(item.clinicalOrders || []).filter(o => o.target === 'center' && o.status === 'ordered').length.toLocaleString('fa-IR')} دستور باز • نوبت ${Number(item.turnNumber || 0).toLocaleString('fa-IR')}`)),
        h('span', { className: `bhis-status-dot ${item.status === 'nursing_in_progress' ? 'busy' : ''}` })
      )))
    ),
    h('main', { className: 'bhis-clinical-chart' },
      !active ? h('div', { className: 'bhis-chart-empty' }, h(Activity, { className: 'w-12 h-12' }), h('h2', null, 'پرونده‌ای را از صف خدمات انتخاب کنید'), h('p', null, 'اینجا محل اجرای دستورها، ثبت خدمت انجام‌شده و کالای مصرفی است.')) : h(React.Fragment, null,
        h('header', { className: 'bhis-patient-panel' },
          h('div', { className: 'bhis-patient-panel-main' }, h('span', { className: 'bhis-avatar large nurse' }, h(UserRound, { className: 'w-6 h-6' })), h('div', null, h('h1', null, active.patientName), h('div', { className: 'bhis-patient-meta' }, h('span', null, `پزشک: ${active.doctorName || '—'}`), h('span', null, `نوبت ${Number(active.turnNumber || 0).toLocaleString('fa-IR')}`), h('span', null, h(Clock3, { className: 'w-3.5 h-3.5' }), active.jalaliTime || '—')))),
          h('div', { className: 'bhis-patient-panel-actions' }, debt > 0 ? h('span', { className: 'bhis-alert-chip' }, h(AlertTriangle, { className: 'w-4 h-4' }), 'بدهی قبلی/جاری') : null, h('button', { type: 'button', onClick: () => onOpenPatientProfile?.(active.patientId), className: 'bhis-secondary-button' }, h(History, { className: 'w-4 h-4' }), 'سوابق'))
        ),
        h('div', { className: 'bhis-chart-scroll' },
          h('section', { className: 'bhis-clinical-section' },
            h('div', { className: 'bhis-clinical-section-title' }, h(ClipboardCheck, { className: 'w-5 h-5' }), h('div', null, h('h3', null, 'دستورات پزشک برای امروز'), h('p', null, 'هر دستور به‌صورت مستقل اجرا و ثبت می‌شود.'))),
            orders.length === 0 ? h('div', { className: 'bhis-order-empty' }, 'دستور اجرایی برای امروز وجود ندارد؛ در صورت نیاز خدمت یا کالا از بخش پایین ثبت شود.') : h('div', { className: 'bhis-execution-list' },
              ...orders.map((order) => {
                const executed = order.status === 'executed' || (active.services || []).some((x) => x.orderId === order.id);
                return h('div', { key: order.id, className: `bhis-execution-row ${executed ? 'done' : ''}` },
                  h('span', { className: 'bhis-execution-check' }, executed ? h(CheckCircle2, { className: 'w-5 h-5' }) : h(ClipboardCheck, { className: 'w-5 h-5' })),
                  h('div', { className: 'bhis-order-main' }, h('strong', null, order.title), h('div', null, order.instructions ? h('span', null, order.instructions) : h('span', null, 'بدون توضیح تکمیلی'))),
                  executed ? h('button', { type: 'button', onClick: () => undoExecutedOrder(order), className: 'bhis-secondary-button compact' }, 'برگشت اجرا') : h('button', { type: 'button', onClick: () => executeOrder(order), className: 'bhis-primary-button compact' }, h(CheckCircle2, { className: 'w-4 h-4' }), 'ثبت انجام')
                );
              })
            )
          ),
          h('section', { className: 'bhis-clinical-section' },
            h('div', { className: 'bhis-clinical-section-title with-action' },
              h('div', { className: 'flex items-center gap-2' }, h(Boxes, { className: 'w-5 h-5' }), h('div', null, h('h3', null, 'اقلام و خدمات انجام‌شده'), h('p', null, 'فقط موارد واقعاً انجام یا مصرف‌شده وارد صورتحساب می‌شوند.'))),
              h('div', { className: 'bhis-inline-actions' },
                h('button', { type: 'button', onClick: () => setPickerOpen(true), className: 'bhis-primary-button compact' }, h(Plus, { className: 'w-4 h-4' }), 'افزودن از فهرست یکپارچه')
              )
            ),
            ((active.services || []).length + (active.products || []).length) === 0 ? h('div', { className: 'bhis-order-empty' }, 'هنوز خدمت یا کالای انجام‌شده ثبت نشده است.') : h('div', { className: 'bhis-billing-lines' },
              ...(active.services || []).map((line) => h('div', { key: line.id, className: 'bhis-billing-line' }, h('span', { className: 'bhis-line-icon service' }, h(Stethoscope, { className: 'w-4 h-4' })), h('div', null, h('strong', null, line.title), h('small', null, `خدمت • تعداد ${Number(line.quantity || 1).toLocaleString('fa-IR')}`)), h('span', null, money(lineTotal(line))), h('button', { type: 'button', onClick: () => removeLine('service', line), className: 'bhis-danger-icon' }, h(Trash2, { className: 'w-4 h-4' })) )),
              ...(active.products || []).map((line) => h('div', { key: line.id, className: 'bhis-billing-line' }, h('span', { className: 'bhis-line-icon product' }, h(Package, { className: 'w-4 h-4' })), h('div', null, h('strong', null, line.title), h('small', null, `کالا • ${Number(line.quantity || 1).toLocaleString('fa-IR')} ${line.unit || 'عدد'}`)), h('span', null, money(lineTotal(line))), h('button', { type: 'button', onClick: () => removeLine('product', line), className: 'bhis-danger-icon' }, h(Trash2, { className: 'w-4 h-4' })) ))
            )
          ),
          pendingItem ? h('section', { className: 'bhis-add-item-sheet' },
            h('div', { className: 'bhis-add-item-main' }, h('span', { className: `bhis-line-icon ${pendingKind}` }, pendingKind === 'service' ? h(Stethoscope, { className: 'w-4 h-4' }) : h(Package, { className: 'w-4 h-4' })), h('div', null, h('strong', null, pendingItem.title || pendingItem.name), h('small', null, pendingKind === 'product' ? `موجودی ${Number(pendingItem.stockQuantity || 0).toLocaleString('fa-IR')}` : 'خدمت اجرایی'))),
            h('label', { className: 'bhis-quantity-field' }, h('span', null, 'تعداد'), h('div', null, h('button', { type: 'button', onClick: () => setQuantity((q) => Math.max(1, Number(q || 1) - 1)) }, h(Minus, { className: 'w-4 h-4' })), h('input', { type: 'number', min: 1, value: quantity, onChange: (e) => setQuantity(Math.max(1, Number(e.target.value) || 1)) }), h('button', { type: 'button', onClick: () => setQuantity((q) => Number(q || 1) + 1) }, h(Plus, { className: 'w-4 h-4' })) )),
            h('div', { className: 'bhis-inline-actions end' }, h('button', { type: 'button', onClick: () => setPendingItem(null), className: 'bhis-secondary-button' }, 'انصراف'), h('button', { type: 'button', onClick: confirmAdditional, className: 'bhis-primary-button' }, 'ثبت در پرونده'))
          ) : null,
          h('section', { className: 'bhis-clinical-section compact-section' }, h('label', { className: 'bhis-field bhis-field-full' }, h('span', null, 'یادداشت اجرای پرستاری / دستیار'), h('textarea', { rows: 3, value: executionNotes, onChange: (e) => setExecutionNotes(e.target.value), placeholder: 'توضیح اجرای خدمت، وضعیت بیمار یا نکته ضروری...' })), h('div', { className: 'bhis-inline-actions end' }, h('button', { type: 'button', onClick: () => { const base = baseNow(); if (base) commit(base, 'ذخیره یادداشت پرستاری'); }, className: 'bhis-secondary-button' }, h(Save, { className: 'w-4 h-4' }), 'ذخیره یادداشت')))
        ),
        h('footer', { className: 'bhis-chart-footer' }, h('div', null, h('span', null, 'جمع اقلام این مراجعه'), h('strong', null, money(total))), h('button', { type: 'button', onClick: finish, className: 'bhis-primary-button prominent' }, 'اتمام اجرا و ارسال به صندوق', h(ChevronLeft, { className: 'w-4 h-4' })) )
      )
    ),
    h(UnifiedClinicalCatalogPicker, { open: pickerOpen, medicalServices, products, onSelect: pickCatalog, onClose: () => setPickerOpen(false), title: 'فهرست یکپارچه خدمات، اعمال و کالا' })
  );
}
