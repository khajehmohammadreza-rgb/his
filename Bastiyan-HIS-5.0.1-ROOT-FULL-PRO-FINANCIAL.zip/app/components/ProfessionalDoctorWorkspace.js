import React, { useMemo, useState } from '../../vendor/react.js';
import { UnifiedClinicalCatalogPicker } from './UnifiedClinicalCatalogPicker.js?v=424';
import { PersianAppointmentCalendar, formatPersianAppointmentDate, todayIso } from './PersianAppointmentCalendar.js?v=424';
import { moveQueueItem, getUserDisplayName, userHasRole, isMedicalVisitService } from '../utils/clinicalWorkflow.js';
import { makeClinicalOrder, makeServiceLine, makeProductLine, makeAppointment, catalogLabel, resolveDoctorNextStatus } from '../utils/unifiedClinicalCatalog.js';
import {
  Search, Stethoscope, User as UserRound, Clock as Clock3, AlertTriangle, FileText, Plus, Trash2, Save,
  CheckCircle2, History, Activity, Package, Building2, ChevronLeft, Calendar, X, ArrowLeft, Receipt,
} from '../../vendor/lucide-react.js';

const h = React.createElement;
const activeStatuses = new Set(['waiting_doctor','under_treatment']);
const norm = (v) => String(v || '').toLowerCase().replace(/ي/g,'ی').replace(/ك/g,'ک').trim();
const money = (v) => `${Number(v || 0).toLocaleString('fa-IR')} تومان`;
const lineTotal = (x) => Number(x?.unitPrice ?? x?.price ?? 0) * Math.max(1, Number(x?.quantity || 1));

function canSee(item,user,doctors){
  if(!item || !activeStatuses.has(item.status)) return false;
  if(userHasRole(user,'admin')) return true;
  const display=getUserDisplayName(user);
  const rec=(doctors||[]).find(d=>d.id===user?.id||(d.medicalCouncilNumber&&d.medicalCouncilNumber===user?.medicalCouncilNumber));
  const ids=new Set([user?.id,rec?.id].filter(Boolean).map(String));
  if(!item.doctorId&&!item.doctorName) return true;
  return ids.has(String(item.doctorId||'')) || item.doctorName===display || item.doctorName===getUserDisplayName(rec);
}

export function ProfessionalDoctorWorkspace({visitQueue=[],doctors=[],medicalServices=[],products=[],patients=[],currentUser,onUpdateQueueItem,onOpenPatientProfile}){
  const queue=useMemo(()=>(visitQueue||[]).filter(q=>canSee(q,currentUser,doctors)).sort((a,b)=>new Date(a.registeredAt||0)-new Date(b.registeredAt||0)),[visitQueue,currentUser,doctors]);
  const [activeId,setActiveId]=useState('');
  const [query,setQuery]=useState('');
  const [pickerMode,setPickerMode]=useState('');
  const [chiefComplaint,setChiefComplaint]=useState('');
  const [diagnosis,setDiagnosis]=useState('');
  const [doctorNotes,setDoctorNotes]=useState('');
  const [prescription,setPrescription]=useState('');
  const [orders,setOrders]=useState([]);
  const [services,setServices]=useState([]);
  const [productLines,setProductLines]=useState([]);
  const [appointments,setAppointments]=useState([]);
  const [pendingSchedule,setPendingSchedule]=useState(null);
  const [calendarOpen,setCalendarOpen]=useState(false);

  const active=queue.find(q=>q.id===activeId)||null;
  const patient=active?(patients||[]).find(p=>String(p.id)===String(active.patientId)):null;
  const filtered=useMemo(()=>{const q=norm(query);return q?queue.filter(x=>norm(`${x.patientName} ${x.patientCode} ${x.nationalId} ${x.turnNumber}`).includes(q)):queue;},[queue,query]);
  const today=todayIso();

  const select=(item)=>{
    setActiveId(item.id);
    setChiefComplaint(item.chiefComplaint||item.receptionNotes||'');
    setDiagnosis(item.diagnosis||'');
    setDoctorNotes(item.doctorNotes||'');
    setPrescription(item.prescription||'');
    setOrders((item.clinicalOrders||[]).filter(o=>o.status!=='cancelled'));
    setServices([...(item.services||[])]);
    setProductLines([...(item.products||[])]);
    setAppointments([...(item.appointments||[])]);
    setPendingSchedule(null); setCalendarOpen(false); setPickerMode('');
    if(item.status==='waiting_doctor') onUpdateQueueItem?.(moveQueueItem(item,'under_treatment','پزشک پرونده را از صف ویزیت باز کرد',currentUser));
  };
  const baseNow=()=> (visitQueue||[]).find(q=>q.id===activeId)||active;
  const patch=(serviceRows=services)=>({
    chiefComplaint,diagnosis,doctorNotes,prescription,clinicalOrders:orders,services:serviceRows,products:productLines,appointments,
    totalCost:[...serviceRows,...productLines].reduce((s,x)=>s+lineTotal(x),0),lastDoctorEditAt:new Date().toISOString(),
  });
  const save=()=>{const b=baseNow();if(b)onUpdateQueueItem?.({...b,...patch()});};

  const startPick=(mode)=>{setPickerMode(mode);};
  const allowedTypes=pickerMode==='outpatient'?['outpatient']:pickerMode==='hospital'?['hospital']:pickerMode==='product'?['product']:[];
  const pickerTitle=pickerMode==='outpatient'?'انتخاب خدمت سرپایی مرکز':pickerMode==='hospital'?'انتخاب عمل / خدمت بیمارستان گنجی':pickerMode==='product'?'انتخاب کالا یا دارو':'انتخاب مورد';

  const addCatalog=(row)=>{
    setPickerMode('');
    if(!active)return;
    if(row.type==='product'){
      setProductLines(prev=>[...prev,makeProductLine(row.item,1,currentUser)]);
      return;
    }
    if(row.type==='outpatient'||row.type==='hospital'){
      setPendingSchedule(row);
      return;
    }
  };

  const commitScheduled=(row,{date=today,time=''})=>{
    if(!row?.item)return;
    const future=String(date)!==String(today);
    if(row.type==='outpatient'){
      const dup=orders.some(o=>o.serviceId===row.item.id&&o.status==='ordered'&&String(o.scheduledDate||'')===String(future?date:''));
      if(dup){alert('این خدمت سرپایی با همین زمان‌بندی قبلاً ثبت شده است.');return;}
    }else if(row.type==='hospital'){
      const dup=services.some(s=>s.serviceId===row.item.id&&s.status==='registered_hospital_service'&&String(s.scheduledDate||'')===String(future?date:''));
      if(dup){alert('این عمل / خدمت بیمارستانی با همین زمان‌بندی قبلاً ثبت شده است.');return;}
    }
    const appointment=future?makeAppointment({service:row.item,type:row.type,patient:patient||active,actor:currentUser,doctor:currentUser,date,time,sourceStage:'doctor'}):null;
    if(appointment)setAppointments(prev=>[...prev,appointment]);
    if(row.type==='outpatient'){
      const order={...makeClinicalOrder(row.item,currentUser,'doctor'),target:'center',timing:future?'future':'today',scheduledDate:future?date:'',scheduledTime:future?time:'',appointmentId:appointment?.id||''};
      setOrders(prev=>[...prev,order]);
    }else if(row.type==='hospital'){
      const line={...makeServiceLine(row.item,1,currentUser,currentUser,null,'registered_hospital_service'),timing:future?'future':'today',scheduledDate:future?date:'',scheduledTime:future?time:'',appointmentId:appointment?.id||''};
      setServices(prev=>[...prev,line]);
    }
    setPendingSchedule(null);setCalendarOpen(false);
  };

  const removeOrder=(id)=>{
    const row=orders.find(o=>o.id===id);
    if(row?.appointmentId)setAppointments(prev=>prev.filter(a=>a.id!==row.appointmentId));
    setOrders(prev=>prev.filter(o=>o.id!==id));
  };
  const removeService=(id)=>{
    const row=services.find(x=>x.id===id);
    if(row?.appointmentId)setAppointments(prev=>prev.filter(a=>a.id!==row.appointmentId));
    setServices(prev=>prev.filter(x=>x.id!==id));
  };
  const removeProduct=(id)=>setProductLines(prev=>prev.filter(x=>x.id!==id));

  const ensureVisitLine=()=>{
    let finalServices=[...services];
    const base=baseNow();
    if(base?.encounterRoute==='consultation'){
      const visit=(medicalServices||[]).find(s=>String(s.id)===String(base.selectedVisitServiceId))||(medicalServices||[]).find(s=>s&&s.active!==false&&isMedicalVisitService(s));
      if(visit&&!finalServices.some(x=>String(x.serviceId)===String(visit.id))) finalServices.push(makeServiceLine(visit,1,currentUser,currentUser,null,'performed_by_doctor'));
    }
    return finalServices;
  };

  const finish=(forceDischarge=false)=>{
    const base=baseNow();if(!base)return;
    const sameDayCenter=orders.filter(o=>o.target==='center'&&o.status==='ordered'&&o.timing!=='future');
    if(forceDischarge&&sameDayCenter.length){alert('برای امروز خدمت سرپایی ثبت شده است. ابتدا آن خدمت را حذف کنید یا بیمار را به پرستار/دستیار ارسال کنید.');return;}
    const finalServices=ensureVisitLine();
    const next=resolveDoctorNextStatus(orders,forceDischarge);
    const reasonText=forceDischarge?'پزشک معاینه را پایان داد و بیمار را مستقیم برای تسویه و ترخیص ارسال کرد':sameDayCenter.length?'پزشک خدمت سرپایی امروز ثبت کرد و بیمار را برای آماده‌سازی به پرستار/دستیار ارسال کرد':'پزشک بیمار را برای تایید نهایی و تسویه به پذیرش/صندوق ارسال کرد';
    const updated=moveQueueItem(base,next,reasonText,currentUser,{...patch(finalServices),services:finalServices,totalCost:[...finalServices,...productLines].reduce((s,x)=>s+lineTotal(x),0),doctorCompletedAt:new Date().toISOString()});
    onUpdateQueueItem?.(updated);setActiveId('');
  };

  const debt=Number(patient?.creditConfig?.currentDebt||0);
  const sameDayOutpatient=orders.filter(o=>o.target==='center'&&o.status==='ordered'&&o.timing!=='future');
  const futureCount=[...orders,...services].filter(x=>x.timing==='future'&&x.scheduledDate).length;
  const scheduleRow=pendingSchedule;

  return h('div',{className:'bhis-role-workspace bhis-doctor-workspace bhis-doctor-423',dir:'rtl'},
    h('aside',{className:'bhis-worklist'},
      h('div',{className:'bhis-worklist-header'},h('div',null,h('span',{className:'bhis-eyebrow'},'صف ویزیت پزشک'),h('h2',null,'بیماران منتظر ویزیت'),h('p',null,`${queue.length.toLocaleString('fa-IR')} بیمار`)),h('span',{className:'bhis-worklist-count'},queue.length.toLocaleString('fa-IR'))),
      h('label',{className:'bhis-worklist-search'},h(Search,{className:'w-4 h-4'}),h('input',{value:query,onChange:e=>setQuery(e.target.value),placeholder:'جستجوی بیمار...'})),
      h('div',{className:'bhis-worklist-scroll'},filtered.length===0?h('div',{className:'bhis-worklist-empty'},'بیماری در صف ویزیت نیست.'):filtered.map(item=>h('button',{key:item.id,type:'button',onClick:()=>select(item),className:`bhis-patient-row ${activeId===item.id?'active':''}`},h('span',{className:'bhis-patient-avatar'},h(UserRound,{className:'w-4 h-4'})),h('span',{className:'bhis-patient-row-main'},h('strong',null,item.patientName),h('small',null,`پرونده ${item.patientCode||'—'} • نوبت ${Number(item.turnNumber||0).toLocaleString('fa-IR')}`)),h('span',{className:`bhis-status-dot ${item.status==='under_treatment'?'busy':''}`}))))
    ),
    h('main',{className:'bhis-clinical-chart'},!active?h('div',{className:'bhis-chart-empty'},h(Stethoscope,{className:'w-12 h-12'}),h('h2',null,'یک بیمار را از صف ویزیت انتخاب کنید'),h('p',null,'بعد از معاینه فقط یکی از مسیرهای روشن پایین انتخاب می‌شود: ترخیص، خدمت سرپایی مرکز یا عمل بیمارستانی.')):h(React.Fragment,null,
      h('header',{className:'bhis-patient-panel'},
        h('div',{className:'bhis-patient-panel-main'},h('span',{className:'bhis-avatar large'},h(UserRound,{className:'w-6 h-6'})),h('div',null,h('h1',null,active.patientName),h('div',{className:'bhis-patient-meta'},h('span',null,`پرونده ${active.patientCode||'—'}`),h('span',null,`نوبت ${Number(active.turnNumber||0).toLocaleString('fa-IR')}`),h('span',null,h(Clock3,{className:'w-3.5 h-3.5'}),active.jalaliTime||'—')))),
        h('div',{className:'bhis-patient-panel-actions'},debt>0?h('span',{className:'bhis-alert-chip'},h(AlertTriangle,{className:'w-4 h-4'}),`بدهی ${money(debt)}`):null,h('button',{type:'button',onClick:()=>onOpenPatientProfile?.(active.patientId),className:'bhis-secondary-button'},h(History,{className:'w-4 h-4'}),'سوابق'))
      ),
      h('div',{className:'bhis-chart-scroll'},
        h('section',{className:'bhis-clinical-section bhis-doctor-decision-section'},
          h('div',{className:'bhis-clinical-section-title'},h(Stethoscope,{className:'w-5 h-5'}),h('div',null,h('h3',null,'تصمیم بعد از معاینه'),h('p',null,'کار پزشک از چهار اقدام مشخص تشکیل شده است؛ فروش و صندوق در این صفحه وجود ندارد.'))),
          h('div',{className:'bhis-doctor-action-grid'},
            h('button',{type:'button','data-testid':'doctor-discharge',className:'bhis-doctor-action discharge',onClick:()=>finish(true)},h(CheckCircle2,{className:'w-6 h-6'}),h('strong',null,'معاینه و ترخیص'),h('span',null,'بدون خدمت جدید؛ مستقیم به صندوق و ترخیص')),
            h('button',{type:'button','data-testid':'doctor-outpatient',className:'bhis-doctor-action outpatient',onClick:()=>startPick('outpatient')},h(Activity,{className:'w-6 h-6'}),h('strong',null,'خدمت سرپایی مرکز'),h('span',null,'امروز → پرستار • تاریخ دیگر → نوبت آینده')),
            h('button',{type:'button','data-testid':'doctor-hospital',className:'bhis-doctor-action hospital',onClick:()=>startPick('hospital')},h(Building2,{className:'w-6 h-6'}),h('strong',null,'عمل / خدمت بیمارستان گنجی'),h('span',null,'انتخاب عمل، تاریخ و ساعت؛ سپس صندوق')),
            h('button',{type:'button','data-testid':'doctor-product',className:'bhis-doctor-action product',onClick:()=>startPick('product')},h(Package,{className:'w-6 h-6'}),h('strong',null,'کالا / دارو'),h('span',null,'از همان کاتالوگ مشترک مرکز'))
          )
        ),
        h('section',{className:'bhis-clinical-section'},
          h('div',{className:'bhis-clinical-section-title'},h(FileText,{className:'w-5 h-5'}),h('div',null,h('h3',null,'شرح معاینه'),h('p',null,'اطلاعات بالینی و دستور پزشک'))),
          h('div',{className:'bhis-form-grid two'},h('label',{className:'bhis-field'},h('span',null,'علت مراجعه'),h('input',{value:chiefComplaint,onChange:e=>setChiefComplaint(e.target.value)})),h('label',{className:'bhis-field'},h('span',null,'تشخیص'),h('input',{value:diagnosis,onChange:e=>setDiagnosis(e.target.value)}))),
          h('label',{className:'bhis-field bhis-field-full'},h('span',null,'یادداشت پزشک'),h('textarea',{rows:3,value:doctorNotes,onChange:e=>setDoctorNotes(e.target.value)})),
          h('label',{className:'bhis-field bhis-field-full'},h('span',null,'نسخه / توصیه'),h('textarea',{rows:2,value:prescription,onChange:e=>setPrescription(e.target.value)})),
          h('div',{className:'bhis-inline-actions'},h('button',{type:'button',onClick:save,className:'bhis-secondary-button'},h(Save,{className:'w-4 h-4'}),'ذخیره یادداشت'))
        ),
        h('section',{className:'bhis-clinical-section'},
          h('div',{className:'bhis-clinical-section-title'},h(Calendar,{className:'w-5 h-5'}),h('div',null,h('h3',null,'دستورات و نوبت‌های این مراجعه'),h('p',null,'خدمت امروز یا تاریخ آینده؛ تقویم مشترک ظرفیت نوبت‌های ثبت‌شده را نشان می‌دهد.'))),
          (orders.length+services.length+productLines.length)===0?h('div',{className:'bhis-order-empty'},'هنوز خدمت، عمل یا کالای جدیدی ثبت نشده است.'):h('div',{className:'bhis-billing-lines'},
            ...orders.filter(o=>o.status==='ordered').map(o=>h('div',{key:o.id,className:'bhis-billing-line'},h('span',{className:'bhis-line-icon service'},h(Activity,{className:'w-4 h-4'})),h('div',null,h('strong',null,o.title),h('small',null,o.timing==='future'?`سرپایی • نوبت ${formatPersianAppointmentDate(o.scheduledDate)}${o.scheduledTime?` • ${o.scheduledTime}`:''}`:'سرپایی مرکز • امروز • منتظر پرستار')),h('span',null,o.timing==='future'?'نوبت آینده':'امروز'),h('button',{type:'button',onClick:()=>removeOrder(o.id),className:'bhis-danger-icon'},h(Trash2,{className:'w-4 h-4'})))),
            ...services.map(x=>h('div',{key:x.id,className:'bhis-billing-line'},h('span',{className:'bhis-line-icon service'},x.serviceType==='hospital'?h(Building2,{className:'w-4 h-4'}):h(Stethoscope,{className:'w-4 h-4'})),h('div',null,h('strong',null,x.title),h('small',null,x.timing==='future'?`${catalogLabel(x.serviceType||'outpatient')} • ${formatPersianAppointmentDate(x.scheduledDate)}${x.scheduledTime?` • ${x.scheduledTime}`:''}`:catalogLabel(x.serviceType||'outpatient'))),h('span',null,money(lineTotal(x))),h('button',{type:'button',onClick:()=>removeService(x.id),className:'bhis-danger-icon'},h(Trash2,{className:'w-4 h-4'})))),
            ...productLines.map(x=>h('div',{key:x.id,className:'bhis-billing-line'},h('span',{className:'bhis-line-icon product'},h(Package,{className:'w-4 h-4'})),h('div',null,h('strong',null,x.title),h('small',null,'کالا / دارو')),h('span',null,money(lineTotal(x))),h('button',{type:'button',onClick:()=>removeProduct(x.id),className:'bhis-danger-icon'},h(Trash2,{className:'w-4 h-4'}))))
          )
        )
      ),
      h('footer',{className:'bhis-chart-footer'},
        h('div',null,h('span',null,'وضعیت مسیر'),h('strong',null,sameDayOutpatient.length?'خدمت امروز ثبت شده → پرستار / دستیار':futureCount?'نوبت آینده ثبت شده → صندوق / پایان مراجعه':'بدون خدمت امروز → صندوق / ترخیص')),
        h('button',{type:'button','data-testid':'doctor-finish',onClick:()=>finish(false),className:'bhis-primary-button prominent'},sameDayOutpatient.length?h(Activity,{className:'w-5 h-5'}):h(Receipt,{className:'w-5 h-5'}),sameDayOutpatient.length?'ارسال به پرستار / دستیار':'ارسال به صندوق / ترخیص',h(ChevronLeft,{className:'w-4 h-4'}))
      )
    )),
    h(UnifiedClinicalCatalogPicker,{open:Boolean(pickerMode),medicalServices,products,allowedTypes,onSelect:addCatalog,onClose:()=>setPickerMode(''),title:pickerTitle}),
    pendingSchedule&&!calendarOpen?h('div',{className:'bhis-picker-overlay',dir:'rtl',role:'dialog','aria-modal':'true'},h('div',{className:'bhis-schedule-choice-panel'},
      h('header',null,h('div',null,h('span',{className:'bhis-eyebrow'},'زمان انجام خدمت'),h('h2',null,pendingSchedule.title),h('p',null,pendingSchedule.type==='outpatient'?'اگر امروز انجام شود بیمار به پرستار/دستیار می‌رود.':'خدمت بیمارستانی بعد از ثبت برای تسویه به صندوق می‌رود.')),h('button',{type:'button',className:'bhis-icon-button',onClick:()=>setPendingSchedule(null)},h(X,{className:'w-5 h-5'}))),
      h('div',{className:'bhis-schedule-choice-grid'},
        h('button',{type:'button','data-testid':'doctor-schedule-today',onClick:()=>commitScheduled(pendingSchedule,{date:today,time:''})},h(Clock3,{className:'w-6 h-6'}),h('strong',null,'امروز'),h('span',null,pendingSchedule.type==='outpatient'?'ارجاع برای اجرای خدمت در مرکز':'ثبت برای امروز و ارسال به صندوق')),
        h('button',{type:'button','data-testid':'doctor-schedule-future',onClick:()=>setCalendarOpen(true)},h(Calendar,{className:'w-6 h-6'}),h('strong',null,'تاریخ دیگر'),h('span',null,'باز کردن تقویم فارسی و مشاهده نوبت‌های قبلی'))
      ),
      h('button',{type:'button',className:'bhis-secondary-button',onClick:()=>setPendingSchedule(null)},h(ArrowLeft,{className:'w-4 h-4'}),'بازگشت')
    )):null,
    h(PersianAppointmentCalendar,{open:calendarOpen&&Boolean(scheduleRow),visitQueue,service:scheduleRow?.item,patient:patient||active,initialDate:'',initialTime:'09:00',title:scheduleRow?.type==='hospital'?'تعیین نوبت عمل / خدمت بیمارستان گنجی':'تعیین نوبت خدمت سرپایی مرکز',onConfirm:({date,time})=>commitScheduled(scheduleRow,{date,time}),onClose:()=>setCalendarOpen(false)})
  );
}
