import React, { useMemo, useState } from '../../vendor/react.js';
import { moveQueueItem } from '../utils/clinicalWorkflow.js';
import { UnifiedClinicalCatalogPicker } from './UnifiedClinicalCatalogPicker.js?v=424';
import { makeServiceLine, makeProductLine } from '../utils/unifiedClinicalCatalog.js';
import {
  Search, User as UserRound, CreditCard, DollarSign as Banknote, FileText, Stethoscope, Package, AlertTriangle, CheckCircle2, ChevronLeft, History, Receipt as ReceiptText, DollarSign as CircleDollarSign, Plus, Trash2
} from '../../vendor/lucide-react.js';

const h = React.createElement;
const statuses = new Set(['ready_for_discharge', 'waiting_payment']);
const norm = (v) => String(v || '').toLowerCase().replace(/ي/g, 'ی').replace(/ك/g, 'ک').trim();
const money = (v) => `${Number(v || 0).toLocaleString('fa-IR')} تومان`;
const lineTotal = (x) => Number(x?.unitPrice ?? x?.price ?? 0) * Math.max(1, Number(x?.quantity || 1));

export function ProfessionalDischargeWorkspace({ visitQueue = [], patients = [], medicalServices = [], products = [], currentUser, onUpdateQueueItem, onOpenPatientProfile }) {
  const queue = useMemo(() => (visitQueue || []).filter((q) => statuses.has(q.status)).sort((a, b) => new Date(a.registeredAt || 0) - new Date(b.registeredAt || 0)), [visitQueue]);
  const [activeId, setActiveId] = useState('');
  const [query, setQuery] = useState('');
  const [method, setMethod] = useState('card');
  const [amount, setAmount] = useState(0);
  const [rrn, setRrn] = useState('');
  const [pickerOpen, setPickerOpen] = useState(false);
  const active = queue.find((q) => q.id === activeId) || null;
  const patient = active ? (patients || []).find((p) => p.id === active.patientId) : null;

  const filtered = useMemo(() => {
    const q = norm(query); if (!q) return queue;
    return queue.filter((x) => norm(`${x.patientName} ${x.patientCode} ${x.nationalId} ${x.turnNumber}`).includes(q));
  }, [queue, query]);

  const total = active ? [...(active.services || []), ...(active.products || [])].reduce((s, x) => s + lineTotal(x), 0) : 0;
  const alreadyPaid = Number(active?.paidAmount || 0);
  const currentDue = Math.max(0, total - alreadyPaid);
  const patientDebt = Number(patient?.creditConfig?.currentDebt || 0);
  const previousDebt = Math.max(0, patientDebt - currentDue);

  const select = (item) => {
    setActiveId(item.id);
    const t = [...(item.services || []), ...(item.products || [])].reduce((s, x) => s + lineTotal(x), 0);
    const due = Math.max(0, t - Number(item.paidAmount || 0));
    setAmount(due);
    setMethod('card'); setRrn('');
    if (item.status === 'ready_for_discharge') onUpdateQueueItem?.(moveQueueItem(item, 'waiting_payment', 'پرونده در صندوق باز شد', currentUser));
  };
  const baseNow = () => (visitQueue || []).find((q) => q.id === activeId) || active;

  const addCatalogItem = (row) => {
    const base = baseNow(); if (!base) return;
    setPickerOpen(false);
    const nextServices = [...(base.services || [])];
    const nextProducts = [...(base.products || [])];
    if (row.kind === 'product') nextProducts.push(makeProductLine(row.item, 1, currentUser));
    else nextServices.push(makeServiceLine(row.item, 1, currentUser, null, null, 'registered_by_reception'));
    const nextTotal = [...nextServices, ...nextProducts].reduce((sum, line) => sum + lineTotal(line), 0);
    const updated = { ...base, services: nextServices, products: nextProducts, totalCost: nextTotal, lastCashierEditAt: new Date().toISOString() };
    onUpdateQueueItem?.(updated);
    setAmount(Math.max(0, nextTotal - Number(updated.paidAmount || 0)));
  };

  const removeBillingLine = (kind, id) => {
    const base = baseNow(); if (!base) return;
    if (!confirm('این مورد از صورتحساب و پرونده مراجعه حذف شود؟')) return;
    const nextServices = kind === 'service' ? (base.services || []).filter((x) => x.id !== id) : [...(base.services || [])];
    const nextProducts = kind === 'product' ? (base.products || []).filter((x) => x.id !== id) : [...(base.products || [])];
    const nextTotal = [...nextServices, ...nextProducts].reduce((sum, line) => sum + lineTotal(line), 0);
    const updated = { ...base, services: nextServices, products: nextProducts, totalCost: nextTotal, lastCashierEditAt: new Date().toISOString() };
    onUpdateQueueItem?.(updated);
    setAmount(Math.max(0, nextTotal - Number(updated.paidAmount || 0)));
  };

  const confirmDischarge = () => {
    const base = baseNow(); if (!base) return;
    const t = [...(base.services || []), ...(base.products || [])].reduce((s, x) => s + lineTotal(x), 0);
    const oldPaid = Number(base.paidAmount || 0);
    const due = Math.max(0, t - oldPaid);
    let paidNow = method === 'credit' ? 0 : Math.max(0, Math.min(due, Number(amount || 0)));
    if (method !== 'credit' && due > 0 && paidNow <= 0) { alert('مبلغ دریافتی را وارد کنید یا روش «ثبت به حساب بیمار» را انتخاب کنید.'); return; }
    if (method === 'card' && paidNow > 0 && !String(rrn || '').trim()) {
      if (!confirm('شماره پیگیری کارت وارد نشده است. پرداخت بدون RRN ثبت شود؟')) return;
    }
    const paidAmount = oldPaid + paidNow;
    const remainingDebt = Math.max(0, t - paidAmount);
    const updated = moveQueueItem(base, 'discharged', remainingDebt > 0 ? 'ترخیص با مانده بدهی ثبت شد' : 'تسویه و ترخیص نهایی ثبت شد', currentUser, {
      totalCost: t,
      paidAmount,
      remainingDebt,
      paymentMethod: method,
      posRrn: method === 'card' ? String(rrn || '').trim() : '',
      finalSettlementAt: new Date().toISOString(),
      dischargePayment: { method, paidNow, totalPaid: paidAmount, remainingDebt, at: new Date().toISOString() },
    });
    onUpdateQueueItem?.(updated);
    setActiveId('');
  };

  return h('div', { className: 'bhis-role-workspace bhis-discharge-workspace', dir: 'rtl' },
    h('aside', { className: 'bhis-worklist' },
      h('div', { className: 'bhis-worklist-header' }, h('div', null, h('span', { className: 'bhis-eyebrow' }, 'پذیرش / صندوق / ترخیص'), h('h2', null, 'آماده تسویه و ترخیص'), h('p', null, 'صورتحساب نهایی همین مراجعه بیمار')), h('span', { className: 'bhis-worklist-count' }, queue.length.toLocaleString('fa-IR'))),
      h('label', { className: 'bhis-worklist-search' }, h(Search, { className: 'w-4 h-4' }), h('input', { value: query, onChange: (e) => setQuery(e.target.value), placeholder: 'جستجوی بیمار...' })),
      h('div', { className: 'bhis-worklist-scroll' }, filtered.length === 0 ? h('div', { className: 'bhis-worklist-empty' }, 'بیماری منتظر تسویه نیست.') : filtered.map((item) => {
        const sum = [...(item.services || []), ...(item.products || [])].reduce((s, x) => s + lineTotal(x), 0);
        return h('button', { key: item.id, type: 'button', onClick: () => select(item), className: `bhis-patient-row ${activeId === item.id ? 'active' : ''}` },
          h('span', { className: 'bhis-patient-avatar cashier' }, h(ReceiptText, { className: 'w-4 h-4' })),
          h('span', { className: 'bhis-patient-row-main' }, h('strong', null, item.patientName), h('small', null, `نوبت ${Number(item.turnNumber || 0).toLocaleString('fa-IR')} • ${money(sum)}`)),
          h('span', { className: 'bhis-status-dot cashier' })
        );
      }))
    ),
    h('main', { className: 'bhis-clinical-chart' },
      !active ? h('div', { className: 'bhis-chart-empty' }, h(ReceiptText, { className: 'w-12 h-12' }), h('h2', null, 'یک بیمار را برای تسویه انتخاب کنید'), h('p', null, 'صندوق فقط اقلام انجام‌شده را می‌بیند؛ دستورهای اجرا نشده وارد صورتحساب نمی‌شوند.')) : h(React.Fragment, null,
        h('header', { className: 'bhis-patient-panel' },
          h('div', { className: 'bhis-patient-panel-main' }, h('span', { className: 'bhis-avatar large cashier' }, h(UserRound, { className: 'w-6 h-6' })), h('div', null, h('h1', null, active.patientName), h('div', { className: 'bhis-patient-meta' }, h('span', null, `پرونده ${active.patientCode || '—'}`), h('span', null, `پزشک ${active.doctorName || '—'}`), h('span', null, `نوبت ${Number(active.turnNumber || 0).toLocaleString('fa-IR')}`)))),
          h('div', { className: 'bhis-patient-panel-actions' }, h('button', { type: 'button', onClick: () => onOpenPatientProfile?.(active.patientId), className: 'bhis-secondary-button' }, h(History, { className: 'w-4 h-4' }), 'سوابق'))
        ),
        h('div', { className: 'bhis-chart-scroll' },
          h('section', { className: 'bhis-clinical-section' },
            h('div', { className: 'bhis-clinical-section-title with-action' },
              h('div', { className: 'flex items-center gap-2' }, h(FileText, { className: 'w-5 h-5' }), h('div', null, h('h3', null, 'ریز صورتحساب مراجعه'), h('p', null, 'پذیرش/صندوق هم از همان فهرست مشترک می‌تواند مورد جاافتاده را ثبت یا اصلاح کند.'))),
              h('button', { type: 'button', onClick: () => setPickerOpen(true), className: 'bhis-primary-button compact' }, h(Plus, { className: 'w-4 h-4' }), 'افزودن خدمت یا کالا')
            ),
            h('div', { className: 'bhis-invoice-table' },
              h('div', { className: 'bhis-invoice-head' }, h('span', null, 'شرح'), h('span', null, 'تعداد'), h('span', null, 'مبلغ')),
              ...(active.services || []).map((line) => h('div', { key: line.id, className: 'bhis-invoice-row' }, h('span', null, h(Stethoscope, { className: 'w-4 h-4' }), h('strong', null, line.title)), h('span', null, Number(line.quantity || 1).toLocaleString('fa-IR')), h('span', { className: 'bhis-invoice-amount-actions' }, h('span', null, money(lineTotal(line))), h('button', { type: 'button', className: 'bhis-danger-icon', title: 'حذف', onClick: () => removeBillingLine('service', line.id) }, h(Trash2, { className: 'w-4 h-4' }))))),
              ...(active.products || []).map((line) => h('div', { key: line.id, className: 'bhis-invoice-row' }, h('span', null, h(Package, { className: 'w-4 h-4' }), h('strong', null, line.title)), h('span', null, Number(line.quantity || 1).toLocaleString('fa-IR')), h('span', { className: 'bhis-invoice-amount-actions' }, h('span', null, money(lineTotal(line))), h('button', { type: 'button', className: 'bhis-danger-icon', title: 'حذف', onClick: () => removeBillingLine('product', line.id) }, h(Trash2, { className: 'w-4 h-4' }))))),
              ((active.services || []).length + (active.products || []).length) === 0 ? h('div', { className: 'bhis-invoice-empty' }, 'برای این مراجعه ردیف مالی ثبت نشده است.') : null
            )
          ),
          h('section', { className: 'bhis-financial-summary' },
            h('div', { className: 'bhis-summary-card primary' }, h('span', null, 'جمع این مراجعه'), h('strong', null, money(total))),
            h('div', { className: 'bhis-summary-card' }, h('span', null, 'پرداخت قبلی همین مراجعه'), h('strong', null, money(alreadyPaid))),
            h('div', { className: 'bhis-summary-card warning' }, h('span', null, 'مانده این مراجعه'), h('strong', null, money(currentDue))),
            h('div', { className: 'bhis-summary-card neutral' }, h('span', null, 'بدهی قدیمی قبل از این مراجعه'), h('strong', null, money(previousDebt)))
          ),
          h('section', { className: 'bhis-clinical-section' },
            h('div', { className: 'bhis-clinical-section-title' }, h(CircleDollarSign, { className: 'w-5 h-5' }), h('div', null, h('h3', null, 'ثبت دریافت'), h('p', null, 'تسویه این مراجعه؛ بدهی قبلی بیمار به‌صورت مستقل حفظ می‌شود.'))),
            h('div', { className: 'bhis-payment-methods' },
              h('button', { type: 'button', className: method === 'card' ? 'active' : '', onClick: () => { setMethod('card'); setAmount(currentDue); } }, h(CreditCard, { className: 'w-5 h-5' }), h('strong', null, 'کارتخوان'), h('small', null, 'POS / کارت')),
              h('button', { type: 'button', className: method === 'cash' ? 'active' : '', onClick: () => { setMethod('cash'); setAmount(currentDue); } }, h(Banknote, { className: 'w-5 h-5' }), h('strong', null, 'نقدی'), h('small', null, 'دریافت نقدی')),
              h('button', { type: 'button', className: method === 'credit' ? 'active credit' : '', onClick: () => { setMethod('credit'); setAmount(0); } }, h(AlertTriangle, { className: 'w-5 h-5' }), h('strong', null, 'ثبت به حساب بیمار'), h('small', null, 'ترخیص با مانده بدهی'))
            ),
            method !== 'credit' ? h('div', { className: 'bhis-form-grid two' },
              h('label', { className: 'bhis-field' }, h('span', null, 'مبلغ دریافتی'), h('input', { type: 'number', min: 0, max: currentDue, value: amount, onChange: (e) => setAmount(Number(e.target.value || 0)) })),
              method === 'card' ? h('label', { className: 'bhis-field' }, h('span', null, 'شماره پیگیری RRN'), h('input', { value: rrn, onChange: (e) => setRrn(e.target.value), placeholder: 'شماره پیگیری تراکنش...' })) : h('div')
            ) : h('div', { className: 'bhis-credit-notice' }, h(AlertTriangle, { className: 'w-5 h-5' }), h('div', null, h('strong', null, 'ترخیص اعتباری'), h('span', null, `${money(currentDue)} به مانده بدهی بیمار باقی می‌ماند.`)))
          )
        ),
        h('footer', { className: 'bhis-chart-footer' },
          h('div', null, h('span', null, method === 'credit' ? 'مانده پس از ترخیص' : 'مبلغ قابل دریافت'), h('strong', null, method === 'credit' ? money(currentDue) : money(Math.min(currentDue, Number(amount || 0))))),
          h('button', { type: 'button', onClick: confirmDischarge, className: 'bhis-primary-button prominent' }, h(CheckCircle2, { className: 'w-5 h-5' }), method === 'credit' ? 'ثبت بدهی و ترخیص' : 'ثبت پرداخت و ترخیص', h(ChevronLeft, { className: 'w-4 h-4' }))
        )
      )
    ),
    h(UnifiedClinicalCatalogPicker, { open: pickerOpen, medicalServices, products, onSelect: addCatalogItem, onClose: () => setPickerOpen(false), title: 'افزودن خدمت، عمل، کالا یا دارو در پذیرش/صندوق' })
  );
}
