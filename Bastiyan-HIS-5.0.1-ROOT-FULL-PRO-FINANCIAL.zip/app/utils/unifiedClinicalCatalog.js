import { getServiceCommissionCategory, isMedicalVisitService, calculateServiceCommission, calculateProductProfitCommission, getUserDisplayName } from './clinicalWorkflow.js';

export function classifyService(service = {}) {
  if (isMedicalVisitService(service)) return 'visit';
  if (getServiceCommissionCategory(service) === 'hospital') return 'hospital';
  return 'outpatient';
}

export function catalogLabel(type) {
  return ({ visit: 'ویزیت', outpatient: 'خدمت سرپایی مرکز', hospital: 'عمل / خدمت بیمارستانی', product: 'کالا / دارو' })[type] || 'مورد';
}

export function makeCatalogEntry(kind, item) {
  const type = kind === 'product' ? 'product' : classifyService(item);
  return {
    key: `${kind}:${String(item?.id || item?.code || item?.barcode || '')}`,
    kind,
    type,
    source: item,
    id: item?.id || '',
    title: item?.title || item?.name || catalogLabel(type),
    code: item?.code || item?.serviceCode || item?.productCode || item?.barcode || item?.id || '',
    price: Number(kind === 'product' ? (item?.salesPrice ?? item?.price ?? item?.unitPrice ?? 0) : (item?.tariffPrice ?? item?.price ?? item?.unitPrice ?? 0)) || 0,
  };
}

export function makeClinicalOrder(service, actor, sourceStage = 'reception') {
  const type = classifyService(service);
  return {
    id: `ord-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    serviceId: service.id,
    title: service.title || service.name || 'خدمت',
    category: service.category || '',
    serviceType: type,
    target: type === 'hospital' ? 'external' : (type === 'visit' ? 'doctor' : 'center'),
    timing: 'today',
    scheduledDate: '',
    instructions: '',
    status: 'ordered',
    sourceStage,
    requestedAt: new Date().toISOString(),
    requestedById: actor?.id || '',
    requestedByName: getUserDisplayName(actor),
    requestedByRole: actor?.role || '',
  };
}

export function makeServiceLine(service, quantity = 1, actor, doctor = null, assistant = null, status = 'registered') {
  const qty = Math.max(1, Number(quantity) || 1);
  const unitPrice = Number(service.tariffPrice ?? service.price ?? service.unitPrice ?? 0) || 0;
  const commission = calculateServiceCommission(service, qty, doctor, assistant);
  return {
    id: `srvline-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    serviceId: service.id,
    title: service.title || service.name || 'خدمت',
    category: service.category || '',
    serviceType: classifyService(service),
    quantity: qty,
    unitPrice,
    price: unitPrice * qty,
    status,
    registeredAt: new Date().toISOString(),
    registeredById: actor?.id || '',
    registeredByName: getUserDisplayName(actor),
    registeredByRole: actor?.role || '',
    originalData: service,
    ...commission,
  };
}

export function makeProductLine(product, quantity = 1, actor) {
  const qty = Math.max(1, Number(quantity) || 1);
  const unitPrice = Number(product.salesPrice ?? product.price ?? product.unitPrice ?? product.purchasePrice ?? 0) || 0;
  return {
    id: `prdline-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    productId: product.id,
    title: product.name || product.title || 'کالا',
    productName: product.name || product.title || 'کالا',
    quantity: qty,
    unitPrice,
    price: unitPrice * qty,
    unit: product.unit || 'عدد',
    barcode: product.barcode || '',
    status: 'registered',
    registeredAt: new Date().toISOString(),
    registeredById: actor?.id || '',
    registeredByName: getUserDisplayName(actor),
    registeredByRole: actor?.role || '',
    originalData: product,
    ...calculateProductProfitCommission(product, qty, actor),
  };
}

export function resolveNextStatus({ visit = false, outpatient = false }) {
  if (visit) return 'waiting_doctor';
  if (outpatient) return 'waiting_nurse';
  return 'ready_for_discharge';
}

export function resolveDoctorNextStatus(orders = [], forceDischarge = false) {
  if (forceDischarge) return 'ready_for_discharge';
  return (orders || []).some((o) => o?.target === 'center' && o?.status === 'ordered' && o?.timing !== 'future') ? 'waiting_nurse' : 'ready_for_discharge';
}

export function makeAppointment({service, type='', patient=null, actor=null, doctor=null, date='', time='', sourceStage='reception', note=''}) {
  const serviceType = type || classifyService(service || {});
  return {
    id: `apt-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,
    serviceId: service?.id || '',
    title: service?.title || service?.name || catalogLabel(serviceType),
    type: serviceType,
    date,
    time,
    patientId: patient?.id || patient?.patientId || '',
    patientName: patient?.fullName || patient?.patientName || '',
    doctorId: doctor?.id || '',
    doctorName: getUserDisplayName(doctor),
    status: 'scheduled',
    sourceStage,
    note,
    createdAt: new Date().toISOString(),
    createdById: actor?.id || '',
    createdByName: getUserDisplayName(actor),
  };
}
