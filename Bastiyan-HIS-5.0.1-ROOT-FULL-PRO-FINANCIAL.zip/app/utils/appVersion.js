export const APP_VERSION = '5.0.1';
export const APP_BUILD = 501;
export const APP_RELEASE = '20260912-501-professional';
export const APP_BUILD_NUMBER = APP_BUILD;
export const APP_RELEASE_DATE = '2026-09-12';
export function formatPersianAppVersion(version = APP_VERSION) {
  const digits = '۰۱۲۳۴۵۶۷۸۹';
  return String(version).replace(/\d/g, digit => digits[Number(digit)]);
}
