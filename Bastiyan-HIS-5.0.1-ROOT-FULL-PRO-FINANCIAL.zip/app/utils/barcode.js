/**
 * Bastiyan HIS barcode utilities - 4.5.7
 * Internal labels use CODE128 by default because it safely encodes clinic-owned IDs.
 */
import JsBarcode from '../../vendor/jsbarcode.js';

export function normalizeBarcode(value) {
  return String(value ?? '').trim().replace(/\s+/g, '');
}

export function isLikelyEAN13(value) {
  const code = normalizeBarcode(value);
  if (!/^\d{13}$/.test(code)) return false;
  const body = code.slice(0, 12);
  return generateEAN13CheckDigit(body) === code.slice(12);
}

export function renderBarcode(element, code, options = {}) {
  const value = normalizeBarcode(code);
  if (!element || !value) return false;
  try {
    const format = options.format || (isLikelyEAN13(value) ? 'EAN13' : 'CODE128');
    JsBarcode(element, value, {
      format,
      lineColor: '#0f172a',
      width: options.width || 2,
      height: options.height || 50,
      displayValue: options.displayValue !== false,
      fontSize: options.fontSize || 14,
      font: 'Vazir, Tahoma, sans-serif',
      margin: 5,
      flat: false,
    });
    return true;
  } catch (err) {
    console.error('[Bastiyan] Barcode rendering error:', err);
    return false;
  }
}

export function generateEAN13CheckDigit(first12) {
  const code = String(first12 ?? '').replace(/\D/g, '').slice(0, 12);
  if (code.length !== 12) return '';
  let sum = 0;
  for (let i = 0; i < 12; i++) sum += Number(code[i]) * (i % 2 === 0 ? 1 : 3);
  return String((10 - (sum % 10)) % 10);
}

export function generateUniqueClinicBarcode(products = [], prefix = '626') {
  const used = new Set((products || []).map(p => normalizeBarcode(p?.barcode)).filter(Boolean));
  for (let attempt = 0; attempt < 5000; attempt++) {
    const body = `${prefix}${Math.floor(100000000 + Math.random() * 900000000)}`; // 12 digits
    const code = body + generateEAN13CheckDigit(body);
    if (!used.has(code)) return code;
  }
  return `${prefix}${Date.now().toString().slice(-9)}`.slice(0, 13);
}

export function generateBarcodeSvgString(code, options = {}) {
  const value = normalizeBarcode(code);
  if (!value || typeof document === 'undefined') return '';
  const svgNode = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  renderBarcode(svgNode, value, { height: options.height || 40, width: options.width || 1.5, fontSize: options.fontSize || 12, format: options.format });
  return svgNode.outerHTML;
}
