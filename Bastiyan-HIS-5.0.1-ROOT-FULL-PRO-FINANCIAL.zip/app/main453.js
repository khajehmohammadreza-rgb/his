import '../vendor/react.js';
// Compatibility entry: Bastiyan HIS 4.5.7
export { default } from './main457-final.js';
