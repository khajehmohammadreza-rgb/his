const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, '../data/bastiyan_his.sqlite');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('[DB Error]', err.message);
    } else {
        console.log('[DB] Connected to SQLite Database.');
        initTables();
    }
});

function initTables() {
    db.serialize(() => {
        // Patients Table
        db.run(`CREATE TABLE IF NOT EXISTS patients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            national_code TEXT UNIQUE,
            full_name TEXT,
            phone TEXT,
            age INTEGER,
            gender TEXT,
            insurance_type TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // Admissions & Visits Table
        db.run(`CREATE TABLE IF NOT EXISTS admissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            admission_code TEXT UNIQUE,
            patient_id INTEGER,
            doctor_id INTEGER,
            department TEXT,
            service_title TEXT,
            service_fee REAL DEFAULT 0,
            status TEXT DEFAULT 'admitted', -- admitted, with_doctor, treatment, discharged
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (patient_id) REFERENCES patients(id)
        )`);

        // Financial & Payments (Interleaved Deposit and Discharge Balancing)
        db.run(`CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            admission_id INTEGER,
            patient_id INTEGER,
            amount REAL,
            method TEXT, -- cash, pos, card_to_card, insurance
            reference_code TEXT,
            discount_type TEXT DEFAULT 'fixed',
            discount_value REAL DEFAULT 0,
            note TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (admission_id) REFERENCES admissions(id)
        )`);

        // Print & Education Form Templates
        db.run(`CREATE TABLE IF NOT EXISTS templates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT,
            category TEXT, -- education, consent, receipt, invoice
            content TEXT,
            is_default INTEGER DEFAULT 0
        )`);

        // Insert Default Templates if empty
        db.get("SELECT COUNT(*) as count FROM templates", (err, row) => {
            if (row && row.count === 0) {
                const stmt = db.prepare("INSERT INTO templates (title, category, content, is_default) VALUES (?, ?, ?, ?)");
                stmt.run("فرم آموزش مراقبت در منزل زخم و جراحی", "education", "دستورات مراقبت در منزل: ۱- پانسمان را تا ۲۴ ساعت خشک نگه دارید. ۲- در صورت بروز تب یا ترشح غیرعادی با کلینیک تماس بگیرید. ۳- داروهای تجویزی را طبق دستور پزشک مصرف نمایید.", 1);
                stmt.run("برگه رضایت‌نامه اقدامات درمانی و بیهوشی موضعی", "consent", "اینجانب با آگاهی کامل از روند درمان، عوارض احتمالی و مراقبت‌های بعدی، رضایت خود را جهت انجام خدمت درمانی اعلام می‌دارم.", 1);
                stmt.finalize();
            }
        });
    });
}

module.exports = db;
