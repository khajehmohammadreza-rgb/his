export const APP_VERSION = '5.0.4';
export const APP_BUILD = 503;
export const APP_RELEASE = '20260914-503-kavenegar-webhook';
export const APP_BUILD_NUMBER = APP_BUILD;
export const APP_RELEASE_DATE = '2026-09-14';
export function formatPersianAppVersion(version = APP_VERSION) {
  const digits = '۰۱۲۳۴۵۶۷۸۹';
  return String(version).replace(/\d/g, digit => digits[Number(digit)]);
}
