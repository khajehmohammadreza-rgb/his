$ErrorActionPreference = 'Stop'

Write-Host "Bastiyan HIS - GitHub Transfer" -ForegroundColor Cyan
$repoUrl = Read-Host "GitHub repository URL (e.g. https://github.com/USERNAME/REPOSITORY.git)"
if ([string]::IsNullOrWhiteSpace($repoUrl)) { throw "Repository URL is required." }

if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw "Git is not installed or not in PATH." }

if (-not (Test-Path ".git")) {
    git init
}

git branch -M main

git add .

Write-Host "`nReviewing staged files..." -ForegroundColor Yellow
git status --short

$confirm = Read-Host "Commit and push these files to GitHub? (Y/N)"
if ($confirm -notmatch '^(Y|y)$') {
    Write-Host "Cancelled. Nothing was committed or pushed." -ForegroundColor Yellow
    exit 0
}

if (-not (git remote get-url origin 2>$null)) {
    git remote add origin $repoUrl
} else {
    git remote set-url origin $repoUrl
}

git commit -m "Initial Bastiyan HIS 5.1.0 source"
git push -u origin main

Write-Host "`nGitHub transfer completed." -ForegroundColor Green
