# انتقال به GitHub

در PowerShell داخل پوشه پروژه:

```powershell
git init
git branch -M main
git add .
git status
git commit -m "Initial Bastiyan HIS 5.1.0 source"
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```

قبل از `git push` حتماً `git status` را بررسی کنید و مطمئن شوید `.env` و `api/config.local.php` و فایل‌های `api/data` در لیست فایل‌های staged نیستند.

اگر repository از قبل روی GitHub ساخته شده، فقط URL واقعی همان repository را جایگزین `origin` کنید.
